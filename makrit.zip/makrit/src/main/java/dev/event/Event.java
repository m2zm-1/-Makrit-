package dev.event;

public class Event
{

    private boolean canCallOutOfGame;


    private boolean cancelled;
    private static Type type;

    public boolean isCancelled()
    {
        return this.cancelled;
    }

    public void setCancelled(boolean cancelled)
    {
        this.cancelled = cancelled;
    }

    public void cancel()
    {
        this.cancelled = true;
    }

    public static boolean isPre()
    {
        return type == Type.PRE;
    }

    public static boolean isPost()
    {
        return type == Type.POST;
    }

    public void setType(Type type)
    {
        this.type = type;
    }

    public enum Type
    {
        PRE, POST
    }
}
