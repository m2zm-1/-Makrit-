package dev.event.impl;


import com.craftrise.lv;
public class PacketSender {

    private lv<?> packet;

    private boolean cancelled;

    public void cancel()
    {
        this.cancelled = true;
    }

    public PacketSender(lv<?> packet)
    {
        this.packet = packet;
    }

    public lv<?> getPackets()
    {
        return packet;
    }

    public void setPacket(lv<?> packet)
    {
        this.packet = packet;
    }
}
