package dev.event.impl;

import cr.launcher.IChatComponent;
import dev.event.Event;

public class ChatReceivedEvent extends Event
{
    public final byte type;
    public IChatComponent message;

    public ChatReceivedEvent(byte type, IChatComponent message)
    {
        this.type = type;
        this.message = message;
    }
}
