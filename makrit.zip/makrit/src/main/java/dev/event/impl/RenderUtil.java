package dev.event.impl;

import java.awt.*;

public class RenderUtil {
  public static void renderText(Graphics g, String text, int x, int y, int color) {
    g.setColor(new Color(color));
    g.drawString(text, x, y);
  }
  
  public static void drawRect(Graphics g, int x, int y, int width, int height, Color color) {
    g.setColor(color);
    g.fillRect(x, y, width, height);
  }
}


/* Location:              C:\Users\Administrator\Downloads\libs.jar!\voidcr\craftrise\event\impl\RenderUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */