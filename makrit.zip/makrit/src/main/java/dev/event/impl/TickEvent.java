package dev.event.impl;

import dev.event.Event;

public class TickEvent extends Event {}


/* Location:              C:\Users\Administrator\Downloads\libs.jar!\voidcr\craftrise\event\impl\TickEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */