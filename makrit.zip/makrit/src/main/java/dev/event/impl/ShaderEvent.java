package dev.event.impl;

import dev.event.Event;

public class ShaderEvent extends Event
{
    public final boolean bloom;
    public ShaderEvent(boolean bloom)
    {
        this.bloom = bloom;
    }
}
