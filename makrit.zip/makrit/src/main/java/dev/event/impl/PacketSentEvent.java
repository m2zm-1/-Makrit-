package dev.event.impl;

import dev.event.Event;



public class PacketSentEvent extends Event {
  public Object packet;

  public PacketSentEvent(Object packet) {
    this.packet = packet;
  }

  public Object getPacket() {
    return this.packet;
  }

  public void setPacket(Object packet) {
    this.packet = packet;
  }
}


/* Location:              C:\Users\Administrator\Downloads\libs.jar!\voidcr\craftrise\event\impl\PacketSentEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */