package dev.event;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class EventBus {
    public static List<Subscriber> subscribers = new ArrayList<>();

    public static <T extends Event> void callEvent(T ev) {
        for (Subscriber subscriber : subscribers) {
            for (Method method : subscriber.methods) {
                if (method.getParameters()[0].getType().equals(ev.getClass())) {
                    method.setAccessible(true);
                    try {
                        method.invoke(subscriber.obj, new Object[] { ev });
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    public static void subscribe(Object obj) {
        try {
            List<Method> methods = new ArrayList<>();
            for (Method method : obj.getClass().getDeclaredMethods()) {
                if ((method.getParameters()).length == 1 && Arrays.<Annotation>stream(method.getAnnotations()).anyMatch(annotation -> (annotation.annotationType() == EventTarget.class)))
                    methods.add(method);
            }
            subscribers.add(new Subscriber(obj, methods));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void unSubscribe(Object obj) {
        Subscriber toUnsub = null;
        for (Subscriber subscriber : subscribers) {
            if (subscriber.obj == obj)
                toUnsub = subscriber;
        }
        if (toUnsub != null)
            subscribers.remove(toUnsub);
    }

    static class Subscriber {
        public Object obj;

        public List<Method> methods;

        public Subscriber(Object obj, List<Method> methods) {
            this.obj = obj;
            this.methods = methods;
        }
    }
}
