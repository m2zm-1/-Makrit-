package dev.client.tenacity.ui.notifications;

import today.makrit.utils.Renderer.Animation;
import today.makrit.utils.Renderer.DecelerateAnimation;
import today.makrit.utils.TimerUtil;
import today.makrit.utils.Renderer.FontUtil;
import today.makrit.utils.Renderer.RenderUtil;
import today.makrit.utils.Renderer.RoundedUtil;
import net.minecraft.client.gui.Gui;

import java.awt.*;

public class Notification {

    private final NotificationType notificationType;
    private final String title, description;
    private final float time;
    private final TimerUtil timerUtil;
    private final Animation animation;

    public Notification(NotificationType type, String title, String description) {
        this(type, title, description, NotificationManager.getToggleTime());
    }

    public Notification(NotificationType type, String title, String description, float time) {
        this.title = title;
        this.description = description;
        this.time = (long) (time * 1000);
        timerUtil = new TimerUtil();
        this.notificationType = type;
        animation = new DecelerateAnimation(250, 1);
    }

    public void drawExhi(float x, float y, float width, float height) {
        boolean lowerAlpha = false;
        Gui.drawRect2(x, y, width, height, new Color(0.1F, 0.1F, 0.1F, lowerAlpha ? 0.4F : .75f).getRGB());
        float percentage = Math.min((timerUtil.getTime() / getTime()), 1);

        switch (notificationType){
            case SUCCESS:
                Gui.drawRect2(x + (width * percentage), y + height - 1, width - (width * percentage), 1, new Color(20, 250, 90).getRGB());
                FontUtil.iconFont40.drawString(FontUtil.CHECKMARK, x + 3, (y + FontUtil.iconFont40.getMiddleOfBox(height) + 1), new Color(20, 250, 90).getRGB());
                FontUtil.tahoma17.drawString(getTitle(), x + 7 + FontUtil.iconFont40.getStringWidth(FontUtil.CHECKMARK), y + 4, Color.WHITE.getRGB());
                FontUtil.tahoma16.drawString(getDescription(), x + 7 + FontUtil.iconFont40.getStringWidth(FontUtil.CHECKMARK), y + 8.5f + FontUtil.tahoma17.getHeight(), Color.WHITE.getRGB());
                break;
            case DISABLE:
                Gui.drawRect2(x + (width * percentage), y + height - 1, width - (width * percentage), 1, new Color(255, 30, 30).getRGB());
                FontUtil.iconFont40.drawString(FontUtil.XMARK, x + 3, (y + FontUtil.iconFont40.getMiddleOfBox(height) + 1), new Color(255, 30, 30).getRGB());
                FontUtil.tahoma17.drawString(getTitle(), x + 7 + FontUtil.iconFont40.getStringWidth(FontUtil.XMARK), y + 4, Color.WHITE.getRGB());
                FontUtil.tahoma16.drawString(getDescription(), x + 7 + FontUtil.iconFont40.getStringWidth(FontUtil.XMARK), y + 8.5f + FontUtil.tahoma17.getHeight(), Color.WHITE.getRGB());
                break;
        }
    }

    float getTime() {
        return time;
    }

    String getDescription() {
        return description;
    }

    String getTitle() {
        return title;
    }

    private NotificationType getNotificationType() {
        return notificationType;
    }

    public void blurExhi(float x, float y, float width, float height) {
        Gui.drawRect2(x, y, width, height, Color.BLACK.getRGB());
        RenderUtil.resetColor();
    }
    public void blurSuicideX(float x, float y, float width, float height, float animation) {
        float heightVal = height * animation <= 6 ? 0 : height * animation;
        float yVal = (y + height) - heightVal;
        RoundedUtil.drawRound(x, yVal, width, heightVal, 4, Color.BLACK);
    }

    public Animation getAnimation() {
        return animation;
    }

    public TimerUtil getTimerUtil() {
        return timerUtil;
    }

    public enum NotificationType {
        SUCCESS, INFO, WARNING, DISABLE, ERROR;
    }
}
