package dev.client.tenacity.utils;

import net.minecraft.client.Minecraft;

public final class Wrapper
{
    private static final Minecraft mc = Minecraft.getMinecraft();
}
