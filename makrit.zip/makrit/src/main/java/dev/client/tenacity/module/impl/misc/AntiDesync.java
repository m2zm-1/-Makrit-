package dev.client.tenacity.module.impl.misc;

import com.craftrise.ai;

import cr.launcher.main.a;
import dev.client.tenacity.module.Category;
import dev.client.tenacity.module.Module;
import dev.event.EventListener;
import dev.event.impl.MotionEvent;
import dev.event.impl.PacketSender;
import dev.utils.network.PacketUtils;

@SuppressWarnings("unused")
public final class AntiDesync extends Module {

    private int slot;

    public AntiDesync() {
        super("AntiDesync", Category.MISC, "pervents desync client side");
    }

    private final EventListener<PacketSender> packetSendEventEventListener = event -> {
        if (event.getPackets() instanceof ai) {
            slot = ((ai) event.getPackets()).a();
        }
    };

    private final EventListener<MotionEvent> motionEventEventListener = event -> {
        if (slot != a.q.J.c && slot != -1) {
            PacketUtils.sendPacketNoEvent(new ai(a.q.J.c));
        }
    };

}
