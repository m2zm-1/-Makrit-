package dev.client.tenacity.module.impl.misc;

import cr.launcher.main.a;
import dev.client.tenacity.module.Category;
import dev.client.tenacity.module.Module;
import dev.event.EventListener;
import dev.settings.impl.BooleanSetting;
import dev.settings.impl.MultipleBoolSetting;
import dev.settings.impl.NumberSetting;
import dev.utils.misc.MathUtils;
import dev.utils.time.TimerUtil;
import dev.event.impl.MotionEvent;
public final class Spammer extends Module {
    private final NumberSetting delay = new NumberSetting("Delay", 100, 1000, 10, 1);
    private final MultipleBoolSetting settings = new MultipleBoolSetting("Settings",
            new BooleanSetting("AntiSpam", false),
            new BooleanSetting("Bypass", false));
    private final TimerUtil delayTimer = new TimerUtil();
    private final EventListener<MotionEvent> motionEventEventListener = event -> {
        String spammerText = ".gg/rakunrise ";

        if (spammerText != null && delayTimer.hasTimeElapsed(settings.getSetting("Bypass").isEnabled() ? 2000 : delay.getValue().longValue())) {

            if (settings.getSetting("AntiSpam").isEnabled()) {
                spammerText += " " + MathUtils.getRandomInRange(10, 100000);
            }

            a.q.b(spammerText,5L);
            delayTimer.reset();
        }
    };

    public Spammer() {
        super("Spammer", Category.MISC, "Spam the chat with a custom message");
        this.addSettings(delay, settings);
    }
}
