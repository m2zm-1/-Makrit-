package dev.client.tenacity.ui.notifications;

public enum NotificationType
{
    SUCCESS,
    DISABLE,
    INFO,
    WARNING
}
