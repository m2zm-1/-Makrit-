package dev.client.tenacity.ui;

public enum GuiEvents
{
    DRAW,
    CLICK,
    RELEASE

}
