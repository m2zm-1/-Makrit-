package dev.client.tenacity.config;

public class Configuration
{
    private final String name;

    public Configuration(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }
}
