package dev.client.tenacity.module.impl.misc;

import dev.client.tenacity.module.Category;
import dev.client.tenacity.module.Module;
import dev.event.EventListener;
import dev.event.impl.PacketSender;
import dev.event.impl.PacketReceiveEvent;
import dev.settings.impl.ModeSetting;
import com.craftrise.pT;

import cr.launcher.main.a;
import com.craftrise.pE;

public final class AntiFreeze extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Normal", "Normal", "Teleport");

    private final EventListener<PacketSender> packetReceiveEventEventListener = event -> {
        if (event.getPackets() instanceof pE) {
            event.cancel();
        } else if (event.getPackets() instanceof pT
                && ((pT) event.getPackets()).a().getUnformattedText().contains("frozen")) {
            if (mode.is("Teleport")) {
                a.q.aY = -999;
            }
            event.cancel();
        }
    };

    public AntiFreeze() {
        super("AntiFreeze", Category.MISC, "prevents server plugins from freezing you");
    }

}
