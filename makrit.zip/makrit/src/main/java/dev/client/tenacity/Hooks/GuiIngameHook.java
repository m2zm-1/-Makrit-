package dev.client.tenacity.Hooks;

import com.craftrise.client.dt;
import cr.launcher.Config;
import dev.client.tenacity.Tenacity;
import dev.client.tenacity.module.Module;
import dev.event.EventBus;
import dev.event.impl.RenderEvent;
import dev.event.impl.TickEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

public class GuiIngameHook extends dt
{
    public static ScaledResolution scaledresolution = new ScaledResolution(Minecraft.getMinecraft());
    public GuiIngameHook(dt OriginalGui)
    {
        super(Config.getMinecraft());
    }
    public void KeybindCheckEvent()
    {
    }
    public void a(float f, long l) {
        super.a(f, l);
        Tenacity.idk = l;
        EventBus.callEvent(new RenderEvent());
        Module.preRender2DEvent(f);
        Module.render2DEvent();
    }

    public void c(long l) {
        super.c(l);
        Tenacity.idk = l;
        EventBus.callEvent(new TickEvent());
    }
}
