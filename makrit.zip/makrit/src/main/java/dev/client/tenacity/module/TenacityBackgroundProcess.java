package dev.client.tenacity.module;


import cr.launcher.main.a;
import dev.client.tenacity.Tenacity;
import dev.event.EventListener;
import dev.event.impl.KeyPressEvent;
import dev.event.impl.ChatReceivedEvent;
import dev.utils.Utils;

import java.io.File;

public class TenacityBackgroundProcess implements Utils
{
    private final EventListener<KeyPressEvent> onKeyPress = e ->
            Tenacity.INSTANCE.getModuleCollection().getModules().stream()
            .filter(m -> m.getKeybind().getCode() == e.getKey()).forEach(Module::toggle);

    private final File dragData = new File(Tenacity.DIRECTORY, "Drag.json");


    private final EventListener<ChatReceivedEvent> onChatReceived = e ->
    {
        if (a.q == null)
        {
            return;
        }

     //   String message = StringUtils.stripControlCodes(e.message.getUnformattedText());
       
    };

}
