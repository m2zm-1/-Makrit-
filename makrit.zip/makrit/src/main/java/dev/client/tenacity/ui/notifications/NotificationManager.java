package dev.client.tenacity.ui.notifications;

import net.minecraft.client.Minecraft;
import today.makrit.utils.Renderer.Animation;
import today.makrit.utils.Renderer.Direction;
import today.makrit.utils.Renderer.FontUtil;
import today.makrit.module.ModuleManager;
import net.minecraft.client.gui.ScaledResolution;

import java.util.concurrent.CopyOnWriteArrayList;

public class NotificationManager {
    private static float toggleTime = 2;
    private static final CopyOnWriteArrayList<Notification> notifications = new CopyOnWriteArrayList<>();

    public static void post(Notification.NotificationType type, String title, String description) {
        post(new Notification(type, title, description));
    }

    public static void post(Notification.NotificationType type, String title, String description, float time) {
        post(new Notification(type, title, description, time));
    }

    private static void post(Notification notification) {
        if (ModuleManager.isEnabled("Hud")) {
            notifications.add(notification);
        }
    }

    public static float getToggleTime() {
        return toggleTime;
    }
    public static float setToggleTime(float toggleTime) {
        return NotificationManager.toggleTime = toggleTime;
    }
    public static void render() {
        float yOffset = 0;
        int notificationHeight = 0;
        int notificationWidth;
        int actualOffset = 0;
        ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());

        NotificationManager.setToggleTime(4);

        for (Notification notification : NotificationManager.getNotifications()) {
            Animation animation = notification.getAnimation();
            animation.setDirection(notification.getTimerUtil().hasTimeElapsed((long) notification.getTime()) ? Direction.BACKWARDS : Direction.FORWARDS);

            if (animation.finished(Direction.BACKWARDS)) {
                NotificationManager.getNotifications().remove(notification);
                continue;
            }

            float x, y;

            animation.setDuration(125);
            actualOffset = 3;
            notificationHeight = 25;
            notificationWidth = (int) Math.max(FontUtil.tahoma17.getStringWidth(notification.getTitle()), FontUtil.tahoma16.getStringWidth(notification.getDescription())) + 30;

            x = sr.getScaledWidth() - ((sr.getScaledWidth() / 2f + notificationWidth / 2f) * (float) animation.getOutput());
            y = sr.getScaledHeight() / 2f - notificationHeight / 2f + 40 + yOffset + 60;

            notification.drawExhi(x, y, notificationWidth, notificationHeight);


            yOffset += (notificationHeight);
        }
    }

    private static CopyOnWriteArrayList<Notification> getNotifications() {
        return notifications;
    }

}
