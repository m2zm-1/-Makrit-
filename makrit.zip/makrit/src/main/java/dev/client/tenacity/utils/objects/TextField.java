package dev.client.tenacity.utils.objects;

import net.minecraft.client.gui.Gui;

import java.awt.*;

public class TextField extends Gui
{
//   private final MinecraftFontRenderer fontRenderer;
    public int width;
    public Color bottomBar, textColor, cursorColor;
    public String placeholder;
    public boolean centeredPlaceholder;
}
