package dev.client.tenacity.utils.misc;

public class DiscordRP
{
}
