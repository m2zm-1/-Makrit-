package dev.client.tenacity.utils.player;

import cr.launcher.BlockPos;

import today.makrit.utils.mapper.Minecraft;

import java.util.ArrayList;
import java.util.List;

public class BlockHelper {
    public static int getX(final BlockPos pos) {
        return pos.c();
    }

    public static int getY(final BlockPos pos) {
        return pos.b();
    }

    public static int getZ(final BlockPos pos) {
        return pos.a();
    }

    public static List<BlockPos> getAdjacentBlockPositions(int n, int n2, int n3, char n4) {
        ArrayList<BlockPos> arrayList = new ArrayList<BlockPos>();
        int n5 = 1;
        while (n5 < n4) {
            int n6;
            int n7 = n6 = n5 * -1;
            while (n7 <= n5) {
                int n8 = n6;
                while (n8 <= n5) {
                    int n9 = n6;
                    while (n9 <= n5) {
                        if (Math.abs(n8) + Math.abs(n7) + Math.abs(n9) == n5 && n7 + n2 > 0) {
                            arrayList.add(new BlockPos(n + n8, n2 + n7, n3 + n9));
                        }
                        ++n9;
                    }
                    ++n8;
                }
                ++n7;
            }
            ++n5;
        }
        return arrayList;
    }

    public static List<BlockPos> getSurroundingBlockPositions(final int x, final int y, final int z, final char limit) {
        final ArrayList<BlockPos> positions = new ArrayList<BlockPos>();
        for (char c = '\u0001'; c < limit; ++c) {
            int i;
            for (int n = i = c * -1; i <= c; ++i) {
                for (int j = n; j <= c; ++j) {
                    for (int k = n; k <= c; ++k) {
                        if (Math.abs(j) + Math.abs(i) + Math.abs(k) == c && y + i > 0) {
                            positions.add(new BlockPos(x + j, y + i, z + k));
                        }
                    }
                }
            }
        }
        return positions;
    }

    public static List<BlockPos> getBlockPositions(final int x, final int y, final int z, final char limit) {
        final ArrayList<BlockPos> positions = new ArrayList<BlockPos>();
        for (char c = '\u0001'; c < limit; ++c) {
            int i;
            for (int n = i = c * -1; i <= c; ++i) {
                for (int j = n; j <= c; ++j) {
                    for (int k = n; k <= c; ++k) {
                        if (y + i > 0) {
                            positions.add(new BlockPos(x + j, y + i, z + k));
                        }
                    }
                }
            }
        }
        return positions;
    }

    public static int getIdFromBlock(com.craftrise.dN block) {
        try {
            return  com.craftrise.dN.a(block);
        } catch (Exception e) {
            Minecraft.addChatMessage(e.toString());
            return 333333;
        }
    }
}
