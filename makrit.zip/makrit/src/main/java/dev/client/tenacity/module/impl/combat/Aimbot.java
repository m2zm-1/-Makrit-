package dev.client.tenacity.module.impl.combat;

import com.craftrise.m9;
import com.craftrise.mj;
import dev.client.tenacity.module.Category;
import dev.client.tenacity.module.Module;
import dev.settings.impl.NumberSetting;

import today.makrit.utils.mapper.TheWorld;
import today.makrit.utils.mapper.ThePlayer;

import java.util.ArrayList;
import java.util.List;

public class Aimbot extends Module{
	private final NumberSetting Range = new NumberSetting("Range", 4, 6, 1, 0.1);
    public Aimbot() {
        super("Aimbot", Category.COMBAT, "Automatically attacks players");
        this.addSettings(Range);
    }
    private List<mj> getEntities() {
        List<com.craftrise.mj> entities = new ArrayList<>();

        for (final Object o : TheWorld.playerEntities()) {
            final com.craftrise.mj entity = (com.craftrise.mj) o;
            if (entity == null) continue;

            {
                entities.add(entity);
            }
        }

        return entities;
    }
    public static synchronized void faceEntity(mj entity) {
        final float[] rotations = getRotationsNeeded(entity);

        if (rotations != null) {
            ThePlayer.SetRotationYaw(rotations[0]);
            ThePlayer.SetRotationPitch(rotations[1] + 1.0F);
        }
    }

    public static float[] getRotationsNeeded(m9 entity) {
        double deltaX = entity.bE -ThePlayer.GetPosX();
        double deltaY = entity.aY - ThePlayer.GetPosY();
        double deltaZ = entity.bH - ThePlayer.GetPosZ();

        double distance = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);

        float yaw = (float) Math.toDegrees(-Math.atan2(deltaX, deltaZ));
        float pitch = (float) Math.toDegrees(-Math.atan2(deltaY, distance));

        return new float[]{yaw, pitch};
    }
}
