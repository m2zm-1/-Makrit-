package dev.client.tenacity.module.impl.misc;

import com.craftrise.gP;

import dev.client.tenacity.module.Category;
import dev.client.tenacity.module.Module;
import dev.client.tenacity.utils.player.ChatUtils;
import dev.event.EventListener;
import dev.event.impl.PacketSender;

public final class LightningTracker extends Module {

    public LightningTracker() {
        super("LightningTracker", Category.MISC, "detects lightning");
    }

    private final EventListener<PacketSender> onPacketReceive = e -> {
        if (e.getPackets() instanceof gP) {
            gP soundPacket = ((gP) e.getPackets());
            if (soundPacket.a().equals("ambient.weather.thunder")) {
                ChatUtils.print(String.format("Lightning detected at (%s, %s, %s)", (int) soundPacket.c(), (int) soundPacket.b(), (int) 0));
            }
        }
    };
}
