package dev.client.tenacity.utils.objects;

import dev.client.tenacity.utils.render.ShaderUtil;

public class Mask {

    private final ShaderUtil maskShader = new ShaderUtil("Tenacity/Shaders/mask.frag");

}