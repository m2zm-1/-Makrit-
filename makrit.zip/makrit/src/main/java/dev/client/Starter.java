package dev.client;

import dev.client.tenacity.Tenacity;

public class Starter {
	public static void startClient() {
		Tenacity.TenacityStart();
	}

}
