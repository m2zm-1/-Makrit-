package dev.client;

public enum ClientType
{
    TENACITY, ROSE
}
