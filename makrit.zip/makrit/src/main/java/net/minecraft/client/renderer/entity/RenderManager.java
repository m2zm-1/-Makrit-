package net.minecraft.client.renderer.entity;
import com.craftrise.client.g8;
import com.craftrise.client.gD;
import com.craftrise.client.p;
import net.minecraft.client.Minecraft;

public class RenderManager extends g8{
    public double viewerPosX = this.h;
    public double viewerPosY = this.n;
    public double viewerPosZ = this.g;
    public RenderManager(Minecraft Minecraft) {
        super(null,null);
    }
}
