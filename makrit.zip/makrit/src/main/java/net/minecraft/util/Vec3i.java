package net.minecraft.util;

public class Vec3i
{
}
