package today.makrit.notifications;

public enum NotificationType
{
    SUCCESS,
    DISABLE,
    INFO,
    WARNING
}
