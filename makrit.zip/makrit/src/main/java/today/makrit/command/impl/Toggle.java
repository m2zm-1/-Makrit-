package today.makrit.command.impl;

import today.makrit.command.Command;
import today.makrit.module.Module;
import today.makrit.module.ModuleManager;
import today.makrit.utils.mapper.Minecraft;

public class Toggle extends Command {
	
	public Toggle() {
		super("Toggle", "Toggles a module by name", "toggle <name>", "t");
	}

	@Override
	public void onCommand(String[] args, String command) {
		if(args.length > 0) {
			String moduleName = args[0];
			
			boolean foundModule = false;
			
			for(Module module : ModuleManager.all()) {
				if(module.name.equalsIgnoreCase(moduleName)) {
					module.toggle();
					
					Minecraft.addChatMessage((module.isToggled() ? "Enabled" : "Disabled") + " " + module.name);
					
					foundModule = true;
					break;
				}
			}
			
			if(!foundModule) {
				Minecraft.addChatMessage("Error : Could not find module " + moduleName + ".");
			}
			
		}
	}

}
