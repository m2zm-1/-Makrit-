package today.makrit.command.impl;

import com.craftrise.d3;
import today.makrit.command.Command;
import today.makrit.utils.mapper.Minecraft;

public class Say extends Command {
	
	public Say() {
		super("Say", "Says things in chat", "say", "s");
	}

	@Override
	public void onCommand(String[] args, String command) {
		Minecraft.GetPlayer().z.a(new d3(String.join(" ", args)),5L);
	}

}
