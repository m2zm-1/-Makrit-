package today.makrit.command;

import today.makrit.command.impl.Bind;
import today.makrit.command.impl.Say;
import today.makrit.command.impl.Toggle;
import today.makrit.event.impl.EventChat;
import today.makrit.utils.mapper.Minecraft;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CommandManager {

	public List<Command> commands = new ArrayList<Command>();
	public String prefix = ".";
	
	public CommandManager() {
		setup();
	}

	public void setup() {
		commands.add(new Toggle());
		commands.add(new Say());
		commands.add(new Bind());
	}
	public void handleChat(EventChat e) {
		String message = e.getMessage();
		
		if(!message.startsWith(prefix)) {
			return;
		}

		
		message = message.substring(prefix.length());
		
		boolean foundCommand = false;
		
		if(message.split(" ").length > 0) {
			String commandName = message.split(" ")[0];
			
			for(Command c : commands) {
				if(c.aliases.contains(commandName) || c.name.equalsIgnoreCase(commandName)) {
					c.onCommand(Arrays.copyOfRange(message.split(" "), 1, message.split(" ").length), message);
					foundCommand = true;
					break;
				}
			}
		}
		
		if(!foundCommand) {
			Minecraft.addChatMessage("Error : Could not find command.");
		}
		
	}
	
}
