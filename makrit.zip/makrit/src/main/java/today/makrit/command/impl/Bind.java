package today.makrit.command.impl;

import org.lwjgl.input.Keyboard;
import today.makrit.command.Command;
import today.makrit.module.Module;
import today.makrit.module.ModuleManager;
import today.makrit.utils.mapper.Minecraft;

public class Bind extends Command {

	public Bind() {
		super("Bind", "Binds a module by name", "bind <name> <key> | clear", "b");
	}
	private int getKeyCode(String keyName) {
		return Keyboard.getKeyIndex(keyName.toUpperCase());
	}
	@Override
	public void onCommand(String[] args, String command) {
		if(args.length == 2) {
			String moduleName = args[0];
			String keyName = args[1];

			boolean foundModule = false;

			String[] parts = command.split(".");
			if (parts.length >= 3) {
				Module module = ModuleManager.withName(parts[1]);
				if (module != null) {
					module.key = getKeyCode(parts[2]);
					Minecraft.addChatMessage(parts[1] + " key bind to: " + parts[2]);
				} else {
					Minecraft.addChatMessage("Module not found: " + parts[1]);
				}
			} else {
				Minecraft.addChatMessage("Invalid command format!");
			}
		}


		}
	}
