package today.makrit.gui;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.ModuleManager;
import today.makrit.module.setting.*;
import today.makrit.utils.Renderer.FontUtil;
import today.makrit.utils.Renderer.MinecraftFontRenderer;
import today.makrit.utils.Renderer.RenderUtil;
import today.makrit.utils.Renderer.RenderUtil3;

import java.awt.*;
import java.util.stream.Collectors;


public class Panel {
    public ModuleCategory cat;
    public int x, y;
    public int width = 100, height = 150;
    public boolean isHolding = false;
    public int holdX, holdY;
    public boolean waitForKey = false;
    public Module waitingForKey = null;
    public boolean isOnSetting = false;
    public Module settingMod = null;

    public Panel(int x, int y, ModuleCategory cat) {
        this.x = x + 20; // x'i aynı bırakabilirsiniz
        this.y = y + 40; // y'yi 20 piksel aşağı çekmek için artırdık
        this.cat = cat;
    }

    public void draw(int mx, int my) {
        if (isHolding) {
            x = mx - holdX;
            y = my - holdY;
        }

        int ekranGenisligi = Display.getWidth();
        int ekranYuksekligi = Display.getHeight();

        if (waitForKey) {
            GL11.glPushMatrix();
            GL11.glScalef(1f, 1f, 1f);
            RenderUtil.renderText("Bir Tuşa Basın", 5, 10, Color.white.getRGB(), false);
            GL11.glPopMatrix();
            return;
        }

        String kategoriIsmi = cat.name().toLowerCase();
        String ilkHarf = kategoriIsmi.substring(0, 1).toUpperCase();
        String duzenlenmisIsim = ilkHarf + kategoriIsmi.substring(1);


        // Kategorinin arka planını ekliyoruz
        Color kategoriBackground = new Color(0, 0, 0, 150);  // Siyah arka plan, %60 şeffaf
        RenderUtil.drawRoundedRect(x, y, x + width, y + height, 10, kategoriBackground.getRGB());

        Color glowColor = new Color(64, 255, 255, 180);
        RenderUtil3.drawGlowGradient(x, y, x + width, y + height, 5, glowColor, glowColor, glowColor, glowColor);

        // Kategori başlığı çiziliyor
        RenderUtil.drawRect(x, y + 15, x + width, y + 16, Color.white.getRGB());
        Color turkuaz = new Color(64, 255, 255, 55);
        RenderUtil.drawRoundedRect2(x, y, x + width, y + 15, 0, turkuaz.getRGB());

        MinecraftFontRenderer.drawTestColorsex("  " + duzenlenmisIsim, x + 4, y + 4, 1, Color.white, Color.white);

        // Modüller için arka plan
        int backgroundColor = new Color(0, 255, 255, 100).getRGB();
        RenderUtil.drawRect(x, y + 15, x + width, y + height, backgroundColor);

        int yy = y + 1;
        int kaydedilenY = 0;

        for (Module mod : ModuleManager.all().stream().filter(module -> module.cat == cat).collect(Collectors.toList())) {
            yy += 15;
            int modulRenk = mod.toggled ? Color.BLUE.getAlpha() : Color.BLUE.getAlpha();
            RenderUtil.drawRect(x, yy, x + width, yy + 15, modulRenk);

            String modulIsmi = mod.name;
            double textX = x + 4;
            float textY = yy + 3;

            if (mod.toggled) {
                MinecraftFontRenderer.drawFontedString4(modulIsmi, textX, textY);
            } else {
                FontUtil.tenacityFont22.drawStringWithShadow(modulIsmi, textX, textY, Color.white.getRGB());
            }

            String ok = "§f...";
            int okX = x + width - RenderUtil.getTextWidth(ok) - 3;
            int okY = yy + 3;
            FontUtil.tenacityFont22.drawStringWithShadow(ok, okX, okY, Color.white.getRGB());

            if (mod == settingMod) {
                kaydedilenY = yy;
            }
        }

        height = (yy - (y + 1)) + 15;

        if (isOnSetting) {
            int settingHeight = (settingMod.settings.size() * 15) + 5;
            RenderUtil.drawRoundedRect(x + width, kaydedilenY, x + (width * 2 + 50), kaydedilenY + settingHeight, 0, new Color(0, 255, 255, 100).getRGB());

            yy = kaydedilenY;

            for (Setting set : settingMod.settings) {
                // Ayarları çizme işlemi burada yapılabilir
            }
        }
        if(!isOnSetting)
            return;

        int settingHeight = (settingMod.settings.size() * 15) + 5;

        RenderUtil.drawRoundedRect(x + width, kaydedilenY, x + (width * 2 + 50), kaydedilenY + settingHeight, 0,new Color(0, 255, 255, 100).getRGB());

        yy = kaydedilenY;
        for (Setting set : settingMod.settings) {
            RenderUtil.renderText(set.name, x + (width + 5), yy + 6, -1, false);

            if (set instanceof BooleanSetting) {
                BooleanSetting bool = (BooleanSetting) set;
                int checkBoxWidth = 10;
                int checkBoxHeight = 10;
                int checkBoxX = x + (width * 2 + 50) - (checkBoxWidth + 5);
                int checkBoxY = yy + 5;

                int borderColor = new Color(33, 33, 33, 255).getRGB();
                int bgColor = bool.isToggled() ? new Color(0, 255, 255, 255).getRGB() : new Color(67, 255, 255, 255).getRGB();

                RenderUtil.drawRect(checkBoxX, checkBoxY, checkBoxX + checkBoxWidth, checkBoxY + checkBoxHeight, borderColor);
                RenderUtil.drawRect(checkBoxX + 1, checkBoxY + 1, checkBoxX + checkBoxWidth - 1, checkBoxY + checkBoxHeight - 1, bgColor);

                RenderUtil.renderText(bool.isToggled() ? "" : "", checkBoxX + checkBoxWidth + 2, yy + 6, -1, false);

                if (Mouse.getX() > checkBoxX && Mouse.getX() < checkBoxX + checkBoxWidth && Mouse.getY() > checkBoxY && Mouse.getY() < checkBoxY + checkBoxHeight) {
                    bool.toggle();
                }
            }

            if(set instanceof ModeSetting) {
                ModeSetting mode = (ModeSetting) set;
                String text = mode.getValue();
                RenderUtil.drawRect(x + (width * 2 + 50) - (RenderUtil.getTextWidth(text) + 10), yy + 5, x + (width * 2 + 50) - 5, yy + 16, new Color(0, 255, 255, 84).getRGB());
                RenderUtil.renderText(text, x + (width * 2 + 50) - (RenderUtil.getTextWidth(text) + 10) + 2, yy + 6, -1, false);
            }

            if(set instanceof NumberSetting) {
                NumberSetting number = (NumberSetting) set;
                RenderUtil.drawRect(x + (width * 2 + 50) - 55, yy + 5, x + (width * 2 + 50) - 45, yy + 15, new Color(0, 255, 255, 84).getRGB());
                RenderUtil.drawRect(x + (width * 2 + 50) - 40, yy + 5, x + (width * 2 + 50) - 20, yy + 15, new Color(0, 255, 255, 84).getRGB());
                RenderUtil.drawRect(x + (width * 2 + 50) - 15, yy + 5, x + (width * 2 + 50) - 5, yy + 15, new Color(0, 255, 255, 84).getRGB());

                RenderUtil.renderText("-", x + (width * 2 + 50) - 50 - (RenderUtil.getTextWidth("-") / 2), yy + 6, -1, false);
                RenderUtil.renderText("+", x + (width * 2 + 50) - 10 - (RenderUtil.getTextWidth("+") / 2), yy + 6, -1, false);
                RenderUtil.renderText(number.getNumber() + "", x + (width * 2 + 50) - 30 - (RenderUtil.getTextWidth(number.getNumber() + "") / 2), yy + 6, -1, false);
            }

            if(set instanceof DoubleSetting) {
                DoubleSetting number = (DoubleSetting) set;
                RenderUtil.drawRect(x + (width * 2 + 50) - 55, yy + 5, x + (width * 2 + 50) - 45, yy + 15, new Color(0, 255, 255, 84).getRGB());
                RenderUtil.drawRect(x + (width * 2 + 50) - 40, yy + 5, x + (width * 2 + 50) - 20, yy + 15, new Color(0, 255, 255, 84).getRGB());
                RenderUtil.drawRect(x + (width * 2 + 50) - 15, yy + 5, x + (width * 2 + 50) - 5, yy + 15, new Color(0, 255, 255, 84).getRGB());
                RenderUtil.renderText("-", x + (width * 2 + 50) - 50 - (RenderUtil.getTextWidth("-") / 2), yy + 6, -1, false);
                RenderUtil.renderText("+", x + (width * 2 + 50) - 10 - (RenderUtil.getTextWidth("+") / 2), yy + 6, -1, false);
                RenderUtil.renderText(number.getNumber() + "", x + (width * 2 + 50) - 30 - (RenderUtil.getTextWidth(number.getNumber() + "") / 2), yy + 6, -1, false);
            }

            yy+=15;
        }
    }

    public void mouse(int mx, int my, boolean state, int button) {
        if (waitForKey)
            return;

        if (button == 0 && isHovered(mx, my, x, y, x + width, y + 15)) {
            isHolding = state;

            holdX = mx - x;
            holdY = my - y;
        }

        int yy = y + 1;
        int savedY = 0;
        for (Module mod : ModuleManager.all().stream().filter(it -> it.cat == cat).collect(Collectors.toList())) {
            yy += 15;

            if (isHovered(mx, my, x, yy, x + width, yy + 15) && !state) {
                if (button == 0 && !Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)) {
                    mod.toggle();
                }

                if (button == 0 && Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)) {
                    waitForKey = true;
                    waitingForKey = mod;
                }

                if (button == 1) {
                    if (isOnSetting) {
                        isOnSetting = false;
                    } else {
                        isOnSetting = true;
                        settingMod = mod;
                    }
                }
            }

            if (settingMod == mod)
                savedY = yy;
        }

        if (!isOnSetting)
            return;

        yy = savedY;
        for (Setting set : settingMod.settings) {
            if (set instanceof BooleanSetting && state && button == 0) {
                BooleanSetting bool = (BooleanSetting) set;
                String text = bool.isToggled() ? "Enabled" : "Disabled";
                if (isHovered(mx, my, x + (width * 2 + 50) - (RenderUtil.getTextWidth(text) + 10), yy + 5, x + (width * 2 + 50) - 5, yy + 15)) {
                    bool.toggle();
                }
            }
            if (set instanceof ModeSetting && state && button == 0) {
                ModeSetting mode = (ModeSetting) set;
                String text = mode.getValue();
                if (isHovered(mx, my, x + (width * 2 + 50) - (RenderUtil.getTextWidth(text) + 10), yy + 5, x + (width * 2 + 50) - 5, yy + 15)) {
                    mode.toggle();
                }
            }
            if (set instanceof NumberSetting && state && button == 0) {
                NumberSetting number = (NumberSetting) set;
                if (isHovered(mx, my, x + (width * 2 + 50) - 55, yy + 5, x + (width * 2 + 50) - 45, yy + 15) && !(number.getNumber() == number.getMin())) {
                    number.setNumber(number.getNumber() - 1);
                }
                if (isHovered(mx, my, x + (width * 2 + 50) - 15, yy + 5, x + (width * 2 + 50) - 5, yy + 15) && !(number.getNumber() == number.getMax())) {
                    number.setNumber(number.getNumber() + 1);
                }
            }
            if (set instanceof DoubleSetting && state && button == 0) {
                DoubleSetting number = (DoubleSetting) set;
                if (isHovered(mx, my, x + (width * 2 + 50) - 55, yy + 5, x + (width * 2 + 50) - 45, yy + 15) && !(number.getNumber() == number.getMin())) {
                    number.setNumber((float) (number.getNumber() - 0.1));
                }
                if (isHovered(mx, my, x + (width * 2 + 50) - 15, yy + 5, x + (width * 2 + 50) - 5, yy + 15) && !(number.getNumber() == number.getMax())) {
                    number.setNumber((float) (number.getNumber() + 0.1));
                }
            }
            yy += 15;
        }
    }


    public boolean isHovered(int mouseX, int mouseY, int x, int y, int endX, int endY) {
        return (mouseX >= x & mouseY >= y & mouseX < endX & mouseY < endY);
    }

    public void key(int key) {
        if(key == Keyboard.KEY_ESCAPE && waitingForKey != null && waitForKey) {
            waitForKey = false;
            waitingForKey.key = 0;
            return;
        }

        if(waitForKey && waitingForKey != null) {
            waitingForKey.key = Keyboard.getEventKey();
        }

        waitForKey = false;
    }
}