package today.makrit.gui;

import cr.launcher.Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import today.makrit.Main;
import today.makrit.event.EventBus;
import today.makrit.event.impl.RenderEvent;
import today.makrit.event.impl.TickEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleManager;
import today.makrit.module.setting.ModeSetting;
import today.makrit.module.setting.Setting;
import today.makrit.utils.Renderer.FontUtil;
import today.makrit.utils.Renderer.MinecraftFontRenderer;
import org.lwjgl.opengl.GL11;
import today.makrit.utils.Renderer.RenderUtil;

import java.awt.*;
import java.util.Collections;

import static today.makrit.utils.Renderer.RenderUtil.getTextWidth;
import static today.makrit.utils.Renderer.RenderUtil3.drawGlowGradient2;

public class GuiHook extends com.craftrise.client.dt {
    public GuiHook(com.craftrise.client.dt dt2) {
        super(Config.getMinecraft());
    }

    public static int customGetRainbow(int speed, int offset) {
        float hue = (System.currentTimeMillis() + (long) offset) % (long) speed;
        return Color.getHSBColor(hue /= (float) speed, 0.2f, 1.2f).getRGB();
    }

    @Override
    public void a(float f, long l) {
        super.a(f, l);
        Main.idk = l;
        EventBus.callEvent(new RenderEvent());
        Module.preRender2DEvent(f);
        Module.render2DEvent();
    }

    @Override
    public void c(long l) {
        super.c(l);

        Main.idk = l;
        EventBus.callEvent(new TickEvent());
    }

    public static void drawArrayList() {
        java.util.List<Module> modules = ModuleManager.enabled();
        int count = 0;

        // Modülleri genişliklerine göre sırala
        Collections.sort(modules, (module1, module2) -> {
            String drawStr1 = module1.name;
            String drawStr2 = module2.name;

            int textWidth1 = getTextWidth(drawStr1);
            int textWidth2 = getTextWidth(drawStr2);

            return Integer.compare(textWidth2, textWidth1);
        });

        float y = 32;
        int padding = 5;
        int backgroundColor = new Color(30, 30, 30, 150).getRGB();
        int xPosition = 9;
        double xPosition2 = 9;

        for (int i = 0; i < modules.size(); i++) {
            Module module = modules.get(i);
            String drawStr = module.name;

            int textWidth = getTextWidth(drawStr);


            MinecraftFontRenderer.drawBackground(xPosition, (int) y, textWidth + padding, 11, backgroundColor);


            int color = MinecraftFontRenderer.babalar31(3500, y, i);
            drawSmoothRainbowLine(xPosition - 2, y, xPosition - 2, y + 11, 1.5f, color);


            MinecraftFontRenderer.drawFontedString2(drawStr, xPosition2, y);

            count++;
            y += 11;
        }
    }

    public static void DrawMethod5() {
        MinecraftFontRenderer fr = FontUtil.neverlose;
        ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
        java.util.List<Module> moduleList = ModuleManager.enabled();

        try {
            moduleList.sort((m1, m2) -> (int) (Math.round((fr.getStringWidth(m1.name) * 2) - Math.round(fr.getStringWidth(m2.name) * 2))));
        } catch(Exception e) {
            e.printStackTrace();
            return;
        }

        Collections.reverse(moduleList);

        int offsetY = 6;
        for(Module m : moduleList) {
            String displayName = m.name;
            double nameLength = fr.getStringWidth(displayName);

            // Glow için geçiş ve şeffaflık ayarı (radius ile belirleniyor)
            int glowRadius = 25; // Örneğin bir glow radius
            int color1 = rainbowColorWithAlpha(2, (int) (offsetY * 1.3), glowRadius);
            int color2 = rainbowColorWithAlpha(2, (int) ((offsetY + 10) * 1.3), glowRadius); // Glow radius ile alfa değeri ayarlanıyor

            // Glow çizimi
            drawGlowGradient2((float) (sr.getScaledWidth() - nameLength - 12), offsetY, (float) (nameLength + 8), 12, glowRadius, color1, color2);

            // Normal yazı çizimi
            fr.drawStringWithShadow(displayName, sr.getScaledWidth() - nameLength - 8, offsetY + 1.5F, astolfoColors(2, (int) (offsetY * 1.3)));
            offsetY += 9;
        }
    }

    public static int rainbowColorWithAlpha(int speed, int offset, int radius) {
        float hue = (float)((System.currentTimeMillis() + offset) % (speed * 1000)) / (speed * 1000); // Rainbow hesaplama
        int alpha = Math.max(20, 255 - (radius * 15)); // Şeffaflık radius ile orantılı
        return Color.HSBtoRGB(hue, 0.8f, 1.0f) & 0x00FFFFFF | (alpha << 24); // RGB ile alfa birleşimi
    }

    public static void DrawMethod2() {
        MinecraftFontRenderer fr = FontUtil.neverlose;
        ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());

        java.util.List<Module> moduleList = ModuleManager.enabled();

        try {
            moduleList.sort((m1, m2) -> (int) (Math.round((fr.getStringWidth(m1.name) * 2) - Math.round(fr.getStringWidth(m2.name) * 2))));
        } catch(Exception e) {
            e.printStackTrace();
            return;
        }

        Collections.reverse(moduleList);

        int offsetY = 6;

        for(Module m : moduleList) {
            String displayName = m.name;
            double nameLength = fr.getStringWidth(displayName);

            RenderUtil.drawRect(sr.getScaledWidth() - nameLength - 10, offsetY - 1, sr.getScaledWidth() - 8, offsetY + 9, 0x80000000);

            for(int i = 0; i < 11; i++) {
                Gui.drawRect(sr.getScaledWidth() - 5, offsetY + i, sr.getScaledWidth() - 2, offsetY + i + 1, astolfoColors(2, (int) ((offsetY + i - 1) * 1.3)));
            }

            fr.drawStringWithShadow(displayName, sr.getScaledWidth() - nameLength - 8, offsetY + 1.5F, astolfoColors(2, (int) (offsetY * 1.3)));
            offsetY += 9;
        }
    }

    public static void drawSmoothRectWithGlow(double x, double y, double width, double height, double radius, Color color, float glowRadius) {
        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        for (int i = 0; i < glowRadius; i++) {
            float glowAlpha = (float) (color.getAlpha() * (1.0f - (float) i / glowRadius)) / 255.0f;
            double expansion = i * 0.25;
            GL11.glColor4f(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, glowAlpha);

            RenderUtil.drawRoundedRect(x - expansion, y - expansion, width + 2 * expansion, height + 2 * expansion, radius + expansion,
                    new Color(color.getRed(), color.getGreen(), color.getBlue(), (int) (glowAlpha * 255)).getRGB());
        }
        GL11.glColor4f(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f);
        RenderUtil.drawRoundedRect(x, y, width, height, radius, color.getRGB());

        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glPopMatrix();
    }


    public static void DrawMethod3() {
        MinecraftFontRenderer fr = FontUtil.rise;
        ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
        java.util.List<Module> moduleList = ModuleManager.enabled();
        moduleList.sort((m1, m2) -> {
            StringBuilder details1 = new StringBuilder();
            StringBuilder details2 = new StringBuilder();
            for (Setting setting : m1.settings) {
                if (setting instanceof ModeSetting) {
                    ModeSetting modeSetting = (ModeSetting) setting;
                    details1.append(" §7").append(modeSetting.getValue()).append("§7");
                }
            }
            for (Setting setting : m2.settings) {
                if (setting instanceof ModeSetting) {
                    ModeSetting modeSetting = (ModeSetting) setting;
                    details2.append(" §7").append(modeSetting.getValue()).append("§7");
                }
            }
            int lengthComparison = Integer.compare(details2.length(), details1.length());
            if (lengthComparison == 0) {
                return Integer.compare((int) fr.getStringWidth(m2.name), (int) fr.getStringWidth(m1.name));
            }
            return lengthComparison;
        });
        int offsetY = 16;
        for (Module m : moduleList) {
            String displayName = m.name;
            double nameLength = fr.getStringWidth(displayName);
            StringBuilder settingsDetails = new StringBuilder();
            for (Setting setting : m.settings) {
                if (setting instanceof ModeSetting) {
                    ModeSetting modeSetting = (ModeSetting) setting;
                    settingsDetails.append(" §7").append(modeSetting.getValue()).append("§7");
                }
            }
            double detailsLength = fr.getStringWidth(settingsDetails.toString());
            RenderUtil.drawRect(4, offsetY - 1, (float) (nameLength + detailsLength + 8), offsetY + 9, new Color(0, 0, 0, 70).getRGB());
            for (int i = 0; i < 11; i++) {
                Gui.drawRect(2, offsetY + i, 3, offsetY + i + 1, new Color(190, 190, 190, 255).getRGB());
            }
            fr.drawStringWithShadow(displayName, 6, offsetY + 1.5F, new Color(240, 240, 240, 200).getRGB());
            if (settingsDetails.length() > 0) {
                fr.drawStringWithShadow(settingsDetails.toString(), (float) (6 + nameLength), offsetY + 1.5F, new Color(192, 192, 192, 200).getRGB());
            }
            offsetY += 11;
        }
    }

    public static void DrawMethod4() {
        MinecraftFontRenderer fr = FontUtil.rise;
        ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
        java.util.List<Module> moduleList = ModuleManager.enabled();
        moduleList.sort((m1, m2) -> {
            StringBuilder details1 = new StringBuilder();
            StringBuilder details2 = new StringBuilder();
            for (Setting setting : m1.settings) {
                if (setting instanceof ModeSetting) {
                    ModeSetting modeSetting = (ModeSetting) setting;
                    details1.append(" §7").append(modeSetting.getValue()).append("§7");
                }
            }
            for (Setting setting : m2.settings) {
                if (setting instanceof ModeSetting) {
                    ModeSetting modeSetting = (ModeSetting) setting;
                    details2.append(" §7").append(modeSetting.getValue()).append("§7");
                }
            }
            int lengthComparison = Integer.compare(details2.length(), details1.length());
            if (lengthComparison == 0) {
                return Integer.compare((int) fr.getStringWidth(m2.name), (int) fr.getStringWidth(m1.name));
            }
            return lengthComparison;
        });

        int offsetY = 16;


        for (Module m : moduleList) {
            String displayName = m.name;
            double nameLength = fr.getStringWidth(displayName);
            StringBuilder settingsDetails = new StringBuilder();
            for (Setting setting : m.settings) {
                if (setting instanceof ModeSetting) {
                    ModeSetting modeSetting = (ModeSetting) setting;
                    settingsDetails.append(" §7").append(modeSetting.getValue()).append("§7");
                }
            }
            double detailsLength = fr.getStringWidth(settingsDetails.toString());

          for (int i = 0; i < 11; i++) {
                Gui.drawRect(2, offsetY + i, 3, offsetY + i + 1, new Color(190, 190, 190, 255).getRGB());
            }

            fr.drawStringWithShadow(displayName, 6, offsetY + 1.5F, new Color(240, 240, 240, 200).getRGB());
            if (settingsDetails.length() > 0) {
                fr.drawStringWithShadow(settingsDetails.toString(), (float) (6 + nameLength), offsetY + 1.5F, new Color(192, 192, 192, 200).getRGB());
            }
            offsetY += 11;
        }
    }

    public static int astolfoColors(int yOffset, int yTotal) {
        float speed = 4500.0F; // Hızı biraz yavaşlattık.

        float hue;
        for(hue = (float)(System.currentTimeMillis() % (long)((int)speed)) + (float)((yTotal - yOffset) * 7); hue > speed; hue -= speed) {
        }

        hue /= speed;

        // Mavi ve turkuaz arasında kalması için hue aralığını belirleyelim.
        // Mavi yaklaşık 0.5, turkuaz ise 0.66 civarındadır.
        float minHue = 0.5F;  // Mavi
        float maxHue = 0.66F; // Turkuaz

        hue = minHue + (hue * (maxHue - minHue));

        return Color.HSBtoRGB(hue, 0.64F, 1.0F); // Hue ile mavi-turkuaz döngüsü.
    }



    public static void drawSmoothRainbowLine(float x1, float y1, float x2, float y2, float thickness, int color) {
        GL11.glPushMatrix();
        GL11.glLineWidth(thickness);


        float red = (color >> 16 & 255) / 255.0f;
        float green = (color >> 8 & 255) / 255.0f;
        float blue = (color & 255) / 255.0f;
        float alpha = (color >> 24 & 255) / 255.0f;

        GL11.glBegin(GL11.GL_LINES);


        GL11.glColor4f(red, green, blue, alpha);


        GL11.glVertex2f(x1, y1);
        GL11.glVertex2f(x2, y2);

        GL11.glEnd();
        GL11.glPopMatrix();
    }
}