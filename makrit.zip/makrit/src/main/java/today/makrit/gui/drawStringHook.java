package today.makrit.gui;

import today.makrit.module.ModuleManager;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.proutils;
import com.craftrise.client.cz;
import com.craftrise.client.gD;
import cr.launcher.ResourceLocation;

import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;

public class drawStringHook extends com.craftrise.client.d0 {
    static String name = Minecraft.getEntityDisplayName(Minecraft.GetPlayer()).replace("§0", "").replace("§1", "").replace("§2", "").replace("§3", "").replace("§4", "").replace("§5", "").replace("§6", "").replace("§7", "").replace("§8", "").replace("§9", "").replace("§a", "").replace("§b", "").replace("§c", "").replace("§d", "").replace("§e", "").replace("§f", "").replace("§k", "").replace("§l", "").replace("§m", "").replace("§n", "").replace("§o", "").replace("§r", "");
    public static Map<String, String> toReplace = new HashMap<String, String>() {{

        put("VIP, Kutular, Skin ve daha fazlası için: §awww.craftrise.com.tr", "");
        put("%50 indirim » www.craftrise.com", "");

        put("§g", "§f");
    }};
    private static final String CHARACTERS = "ABCDEFGKJGKTIGJDKJNMVO";

    public static String generateRandomString(int length) {
        if (ModuleManager.isEnabled("NameProtect")) {
            SecureRandom random = new SecureRandom();
            StringBuilder sb = new StringBuilder(length);

            for (int i = 0; i < length; i++) {
                int randomIndex = random.nextInt(CHARACTERS.length());
                char randomChar = CHARACTERS.charAt(randomIndex);
                sb.append(randomChar);
            }

            return sb.toString();
        } else {
            return name;
        }
    }

    private String replace(String text) {
        for (Map.Entry<String, String> entry : toReplace.entrySet()) {
            text = text.replace(entry.getKey(), entry.getValue());
        }
        return text;
    }

    public drawStringHook(cz var1, ResourceLocation var2, gD var3, boolean var4) {
        super(var1, var2, var3, var4);
        proutils.copy(this, Minecraft.GetFontRendererObj(), com.craftrise.client.d0.class);
    }

    @Override
    public int a(String text, float x, float y, int color, long xor) {
        if (ModuleManager.isEnabled("AntiBot") && ModuleManager.isEnabled("NameProtect")) {
            return super.a(replace(text.replace(name, "§4Void§r")), x, y, color, xor);
        } else {
            return super.a(text, x, y, color, xor);
        }
    }

    @Override
    public int a(String var1, float var2, float var3, int var4, boolean var5, long var6) {
        if (ModuleManager.isEnabled("AntiBot") && ModuleManager.isEnabled("NameProtect")) {
            return super.a(replace(var1.replace(name, "§4Void§r")), var2, var3, var4, var5, var6);
        } else {
            return super.a(var1, var2, var3, var4, var5, var6);
        }
    }

    @Override
    public int b(String text, float x, float y, int color, boolean dropShadow, boolean fo, long xor) {
        if (ModuleManager.isEnabled("AntiBot") && ModuleManager.isEnabled("NameProtect")) {
            return super.b(replace(text.replace(name, "§4Void§r")), x, y, color, dropShadow, fo, xor);
        } else {
            return super.b(text, x, y, color, dropShadow, fo, xor);
        }
    }
}