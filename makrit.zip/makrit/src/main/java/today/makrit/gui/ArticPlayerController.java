package today.makrit.gui;

import today.makrit.utils.ReflectFields;
import today.makrit.utils.mapper.Minecraft;
import cr.launcher.BlockPos;

public class ArticPlayerController extends com.craftrise.client.ez {
    public ArticPlayerController(final com.craftrise.client.ez playerControllerMP) {
        super(null, null);
        ReflectFields.copyNonStaticField(this, playerControllerMP);
    }

    public boolean onPlayerRightClickPlayer(final com.craftrise.gM itemStack, final BlockPos blockPos, final com.craftrise.lG enumFacing, final com.craftrise.k3 vec3) {
        return super.onPlayerRightClick(Minecraft.GetPlayer(), Minecraft.GetWorld(), itemStack, blockPos, enumFacing, vec3);
    }

    public static boolean onPlayerRightClick(final com.craftrise.gM itemStack, final BlockPos blockPos, final com.craftrise.lG enumFacing, final com.craftrise.k3 vec3) {
        final com.craftrise.client.ez playerController = Minecraft.getPlayerController2();

        if (playerController instanceof ArticPlayerController) {
            return ((ArticPlayerController) playerController).onPlayerRightClickPlayer(itemStack, blockPos, enumFacing, vec3);
        }
        return playerController.onPlayerRightClick(Minecraft.GetPlayer(), Minecraft.GetWorld(), itemStack, blockPos, enumFacing, vec3);
    }
}
