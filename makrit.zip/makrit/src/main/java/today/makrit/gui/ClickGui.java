package today.makrit.gui;

import today.makrit.module.ModuleCategory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ClickGui extends com.craftrise.client.dG {
    public List<Panel> panels = new ArrayList<>();
    public ClickGui() {
        int x = 10;
        for (ModuleCategory category : ModuleCategory.values()) {
            panels.add(new Panel(x, 10, category));
            x+=120;
        }
    }

    @Override
    public void drawScreen(int i, int i1, float v) {
        for (Panel panel : panels) {
            panel.draw(i, i1);
        }

        super.drawScreen(i, i1, v);
    }

    @Override
    protected void mouseClicked(int i, int i1, int i2) throws IOException {
        for (Panel panel : panels) {
            panel.mouse(i, i1, true, i2);
        }

        super.mouseClicked(i, i1, i2);
    }

    @Override
    protected void a(int i, int i1, int i2) {
        for (Panel panel : panels) {
            panel.mouse(i, i1, false, i2);
        }

        super.a(i, i1, i2);
    }

    @Override
    protected void a(char c, int i) throws IOException {
        for (Panel panel : panels) {
            panel.key(i);
        }

        super.a(c, i);
    }
}
