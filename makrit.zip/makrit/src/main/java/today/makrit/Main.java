package today.makrit;

import com.google.common.eventbus.Subscribe;
import dev.client.tenacity.ui.clickguis.dropdown.DropdownClickGui;
import dev.client.tenacity.ui.notifications.Notification;
import dev.client.tenacity.ui.notifications.NotificationManager;
import cr.launcher.Config;
import cr.launcher.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import today.makrit.event.EventBus;
import today.makrit.event.impl.PacketSentEvent;
import today.makrit.event.impl.RenderEvent;
import today.makrit.event.impl.TickEvent;
import today.makrit.gui.ArticPlayerController;
import today.makrit.gui.ClickGui;
import today.makrit.gui.GuiHook;
import today.makrit.gui.drawStringHook;
import today.makrit.management.PacketSent;
import today.makrit.module.ModuleManager;
import today.makrit.module.impl.Packets;
import today.makrit.module.impl.render.*;
import today.makrit.utils.Renderer.*;
import today.makrit.utils.mapper.Minecraft;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

///       Made BY MAKRIT XD
///        discord : realxdev
///               İyi oyunlar!
///
///       {26.09.2024 - 20:09}




public class Main {
    public static List<String> friends = new ArrayList<>();
    public static List<String> admins = new ArrayList<>();
    public static Color CLIENT_COLOR = new Color(29, 75, 204);
    public static Color CLIENT_COLOR2 = new Color(51, 51, 122);
    DropdownClickGui gui3 = new DropdownClickGui();
    public static List<String> names = new ArrayList<>();
    public static long idk = 0;
    public static int screenWidth2 = 0;
    public static Main instance = new Main();
    ClickGui gui = new ClickGui();
    public static long lastModuleOpen = 0;
    static boolean connected = true;
    static ResourceLocation c = new ResourceLocation("1337");

    public static void copyHardwareId()
    {
        StringSelection selection = new StringSelection(getHardwareSerial());

        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();

        clipboard.setContents(selection, null);
    }

    public static void Main() throws IOException {
        copyHardwareId();

        connected = true;

        if (connected)
        {
            Config.log("Loaded Selamun Alekum!");
            Minecraft.setInGameGui(new GuiHook(Minecraft.InGameGui()));
            Minecraft.drawStrHook(new drawStringHook(Config.getGameSettings(), c, Config.getTextureManager(), true));
            Minecraft.setEffectRenderer(new ArticEffectRenderer(Minecraft.GetMinecraft().V));
            Minecraft.setPlayerController(new ArticPlayerController(Minecraft.getPlayerController2()));
            EventBus.subscribe(instance);
            Map<String, Font> locationMap = new HashMap<>();
            FontUtil.tenacityBoldFont40_ = FontUtil.getFont(locationMap, "tenacitybold.ttf", 40);
            FontUtil.tahoma16 = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "tahoma.ttf", 16), true, true);
            FontUtil.tahoma17 = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "tahoma.ttf", 17), true, true);
            FontUtil.wentra1 = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "tenacity.ttf", 27), true, true);
            FontUtil.wentra2 = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "tenacity.ttf", 16), true, true);
            FontUtil.tenacityFont14 = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "tenacity.ttf", 14), true, true);
            FontUtil.tenacityFont16 = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "tenacity.ttf", 16), true, true);
            FontUtil.tenacityFont17 = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "tenacity.ttf", 17), true, true);
            FontUtil.tenacityFont18 = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "tenacity.ttf", 18), true, true);
            FontUtil.tff = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "SF.ttf", 22), true, true);
            FontUtil.arialbd = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "arialbd.ttf", 26), true, true);
            FontUtil.arialbd2 = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "arialbd.ttf", 16), true, true);
            FontUtil.tenacityFont20 = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "tenacity.ttf", 20), true, true);
            FontUtil.tenacityBoldFont20 = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "tenacitybold.ttf", 20), true, true);
            FontUtil.tenacityFont40 = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "tenacity.ttf", 40), true, true);
            FontUtil.tenacityFont24 = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "tenacity.ttf", 24), true, true);
            FontUtil.tenacityBoldFont26 = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "tenacity.ttf", 26), true, true);
            FontUtil.tenacityBoldFont32 = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "tenacitybold.ttf", 24), true, true);
            FontUtil.tenacityBoldFont22 = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "tenacitybold.ttf", 22), true, true);
            FontUtil.rise = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "fontrise.ttf", 18), true, true);
            FontUtil.tenacityFont22 = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "tenacity.ttf", 22), true, true);
            FontUtil.neverlose = new MinecraftFontRenderer(FontUtil.getFont(locationMap, "neverlose.ttf", 20), true, true);
            ModuleManager.registerModules();
            Packets.getChannel().pipeline().addAfter("encoder", "packet_sent", new PacketSent());
        }
        else {
            Config.log("fakir");
        }
        Config.log("Connected Null Value: " + String.valueOf(connected));
    }

    private boolean preventGuiOpen = false;
    public final Color getClientColor() {
        return new Color(147, 112, 219, 255);
    }

    public final Color getAlternateClientColor() {
        return new Color(102, 46, 217, 255);
    }

    @Subscribe
    public void render(RenderEvent event) throws ParseException {
        if(Config.gameSettings.am == 60)
            Config.gameSettings.am = 9000;
        if (connected == false) return;
        lastModuleOpen = System.currentTimeMillis();

        if (Keyboard.isKeyDown(Keyboard.KEY_RSHIFT)) {
            if (!preventGuiOpen) {
                if (Minecraft.getCurrentScreen() == null) {

                    Minecraft.GetMinecraft().a(gui, 2L);
                }
            }
        } else if (Keyboard.isKeyDown(Keyboard.KEY_ESCAPE)) {
            preventGuiOpen = false;
            if (Keyboard.isKeyDown(Keyboard.KEY_T)) {
                preventGuiOpen = true;
            }
        } else if (Keyboard.isKeyDown(Keyboard.KEY_RETURN)) {
            preventGuiOpen = false;
            if (Keyboard.isKeyDown(Keyboard.KEY_T)) {
                preventGuiOpen = true;
            }
        }

        NotificationManager.post(Notification.NotificationType.SUCCESS, "Mitamers", "Everything done,have fun.");
        Packets.start();
        Packets.getChannel().pipeline().addAfter("encoder", "packet_sent", new PacketSent());
    }


    private void setColor(Color color) {
        float red = color.getRed() / 255.0f;
        float green = color.getGreen() / 255.0f;
        float blue = color.getBlue() / 255.0f;
        float alpha = color.getAlpha() / 255.0f;

        GL11.glColor4f(red, green, blue, alpha);
    }

    public Color[] getClientColors() {
        Color firstColor;
        Color secondColor;
        firstColor = mixColors(instance.getClientColor(), instance.getAlternateClientColor());
        secondColor = mixColors(instance.getAlternateClientColor(), instance.getClientColor());
        return new Color[]{firstColor, secondColor};
    }

    @Subscribe
    public void tickEvent(TickEvent ev) {
        ModuleManager.checkForKeyBind();
        screenWidth2 = Minecraft.getScreenWidth();

        ClassLoader.class.getSuperclass();
    }

    private Color mixColors(Color color1, Color color2) {
        if (Hud.movingColors.isToggled()) {
            return ColorUtil.interpolateColorsBackAndForth(15, 1, color1, color2, Hud.hueInterpolation.isToggled());
        } else {
            return ColorUtil.interpolateColorC(color1, color2, 0);
        }
    }

    @Subscribe
    public void packetEvent(PacketSentEvent event) throws InvocationTargetException, NoSuchMethodException, IllegalAccessException {
        //Minecraft.addChatMessage("PacketSendEvent Working.");
        if (event.getPacket().toString().contains("com.craftrise.lE@")) {
            //Minecraft.addChatMessage("C03 Packet Handle");
        } else if (event.getPacket().toString().contains("com.craftrise.lE$a@")) {
            //Minecraft.addChatMessage("C04 Packet Handle");
        } else if (event.getPacket().toString().contains("com.craftrise.lE$b@")) {
            //Minecraft.addChatMessage("C05 Packet Handle");
        } else if (event.getPacket().toString().contains("com.craftrise.lE$c@")) {
            //Minecraft.addChatMessage("C06 Packet Handle");
        }

    }
    public static String getHardwareSerial() {
        String cpuSerial = executeCommand("wmic cpu get ProcessorId");
        String biosSerial = executeCommand("wmic bios get SerialNumber");

        if (cpuSerial == null || biosSerial == null) {
            return "";
        }

        // Boşlukları sil ve "ProcessorId" ve "SerialNumber" kelimelerini de sil
        cpuSerial = cpuSerial.trim().replaceAll("\\s+", "").replaceAll("ProcessorId", "");
        biosSerial = biosSerial.trim().replaceAll("\\s+", "").replaceAll("SerialNumber", "");

        return cpuSerial + biosSerial;
    }

    private static String executeCommand(String command) {
        StringBuilder output = new StringBuilder();

        try {
            Process process = Runtime.getRuntime().exec(command);
            process.waitFor();

            BufferedReader reader =
                    new BufferedReader(new InputStreamReader(process.getInputStream()));

            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        return output.toString();
    }
    private int getKeyCode(String keyName) {
        return Keyboard.getKeyIndex(keyName.toUpperCase());
    }

}