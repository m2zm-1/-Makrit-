package today.makrit.management;

import today.makrit.event.EventBus;
import today.makrit.event.impl.PacketSentEvent;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelOutboundHandlerAdapter;
import io.netty.channel.ChannelPromise;

public class PacketSent extends ChannelOutboundHandlerAdapter {

    @Override
    public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
        PacketSentEvent packetSentEvent = new PacketSentEvent(msg);
        EventBus.callEvent(packetSentEvent);

        if(packetSentEvent.cancelled)
        {
            return;
        }

        super.write(ctx, packetSentEvent.getPacket(), promise);
    }
}