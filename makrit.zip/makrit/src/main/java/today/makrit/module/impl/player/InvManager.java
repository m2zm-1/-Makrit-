package today.makrit.module.impl.player;

import today.makrit.module.ModuleCategory;
import today.makrit.module.impl.SimpleModule;
import today.makrit.module.impl.combat.AutoArmor;
import today.makrit.module.setting.BooleanSetting;
import today.makrit.module.setting.ModeSetting;
import today.makrit.utils.Helper.InventoryHelper;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import com.craftrise.b3;
import com.craftrise.gM;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Method;

import static today.makrit.utils.proutils.filterMethodFromReturnTypeAndParams;

public class InvManager extends SimpleModule {

    public static int[] mainArmorItems;
    public static int[] offHandItems;
    public static int[] blocks;
    public static int[] foodItems;
    public static InvManagerStruct[][] e;
    public static String moduleName;
    public static BooleanSetting clickSetting;
    public static BooleanSetting inventory;
    public static ModeSetting typeSetting;
    public static boolean[] slotFilled;
    public byte currentItemIndex;
    public static int[] blackList = new int[]{1, 3, 4, 5, 35, 159};

    static {

        InvManager.mainArmorItems = new int[]{472, 276, 267, 473, 279, 283, 272, 258, 268, 275};
        InvManager.offHandItems = new int[]{322, 364, 396, 320, 424, 366};
        InvManager.blocks = new int[]{368, 385, 344, 35, 1, 5, 4, 345};
        InvManager.foodItems = new int[]{373, 30, 264, 266, 265, 280};
        InvManager.e = new InvManagerStruct[][]{
                {new InvManagerStruct(-1, InvManager.mainArmorItems), new InvManagerStruct(-1, 346),
                        new InvManagerStruct(2, blackList), new InvManagerStruct(2, InvManager.offHandItems),
                        new InvManagerStruct(1, 326, 325), new InvManagerStruct(InvManager.blocks.length - 1, InvManager.blocks),
                        new InvManagerStruct(InvManager.foodItems.length - 1, InvManager.foodItems),
                        new InvManagerStruct(-1, 474, 278, 257, 285, 274, 270), new InvManagerStruct(-1, 345),
                        new InvManagerStruct(-1, 262), new InvManagerStruct(0, AutoArmor.helmetItems),
                        new InvManagerStruct(0, AutoArmor.chestplateItems), new InvManagerStruct(0, AutoArmor.leggingsItems),
                        new InvManagerStruct(0, AutoArmor.bootsItems)},
                {new InvManagerStruct(1, InvManager.mainArmorItems), new InvManagerStruct(0, 30),
                        new InvManagerStruct(2, InvManager.offHandItems), new InvManagerStruct(0, InvManager.blocks), null, null,
                        null, null, new InvManagerStruct(0, 261), new InvManagerStruct(-1, 262),
                        new InvManagerStruct(0, AutoArmor.helmetItems), new InvManagerStruct(0, AutoArmor.chestplateItems),
                        new InvManagerStruct(0, AutoArmor.leggingsItems), new InvManagerStruct(0, AutoArmor.bootsItems)},
                {new InvManagerStruct(0, 346).setLimit(2), new InvManagerStruct(0, 496)}
        };
        InvManager.moduleName = "Manager";
        InvManager.clickSetting = new BooleanSetting("Click " + InvManager.moduleName, false);
        InvManager.typeSetting = new ModeSetting("Type", "Default", "Default", "Ametist", "Fish");
        InvManager.slotFilled = new boolean[36];
    }

    public InvManager() {
        super("InvManager", ModuleCategory.PLAYER, 0, 0);
        settings.add(clickSetting);
        settings.add(typeSetting);
    }

    @Override
    public void onEnable() {
        this.currentItemIndex = -1;
        super.onEnable();
    }

    public static String getStackTraceAsString(Exception exception) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        exception.printStackTrace(pw);
        return sw.toString();
    }

    @Override
    public void updateDelay() {
        if (this.isToggled()) {
            try {
                int selectedIndex = 0;
                if (typeSetting.getValue().equals("Default")) {
                    selectedIndex = 1;
                } else if (typeSetting.getValue().equals("Ametist")) {
                    selectedIndex = 2;
                } else if (typeSetting.getValue().equals("Fish")) {
                    selectedIndex = 3;
                }

                    if (Minecraft.getCurrentScreen() == null) {
                        byte b = 0;
                        ++this.currentItemIndex;
                        if (this.currentItemIndex == 0) {
                            InvManagerStruct[] array;
                            for (int length = (array = InvManager.e[selectedIndex]).length, i = 0; i < length; ++i) {
                                final InvManagerStruct invManagerStruct = array[i];
                                if (invManagerStruct != null) {
                                    invManagerStruct.currentSlot = -1;
                                }
                            }
                            for (int j = 0; j < 36; j = (byte) (j + 1)) {
                                InvManager.slotFilled[j] = false;
                            }
                        }
                        if (this.currentItemIndex < InvManager.e[selectedIndex].length) {
                            if (InvManager.e[selectedIndex][this.currentItemIndex] != null) {
                                int n = 0;
                                for (byte integer = 0; integer < 36; ++integer) {
                                    final com.craftrise.gM mainInventorySlot = InventoryHelper.getMainInventorySlot(integer);
                                    b3 itemobjj;
                                    int maxdamage = 0;

                                    if (mainInventorySlot != null) {
                                        int a = 0;
                                        try {
                                            Method getItem = filterMethodFromReturnTypeAndParams(b3.class, gM.class);
                                            Method getItemId = filterMethodFromReturnTypeAndParams(int.class, b3.class, b3.class);
                                            Method getMaxDamage = filterMethodFromReturnTypeAndParams(int.class, b3.class);

                                            itemobjj = (b3) getItem.invoke(mainInventorySlot);
                                            int id = (int) getItemId.invoke(null, itemobjj);
                                            a = id;

                                            maxdamage = (int) getMaxDamage.invoke(itemobjj);

                                        } catch (Exception e) {
                                            Minecraft.addChatMessage(getStackTraceAsString(e));
                                        }

                                        byte currentSlot = 0;
                                        while (currentSlot < InvManager.e[selectedIndex][this.currentItemIndex].itemIDs.length) {
                                            if (InvManager.e[selectedIndex][this.currentItemIndex].itemIDs[currentSlot] == a) {
                                                final boolean booleanValue = mainInventorySlot.h(31);
//                                            }
                                                break;
                                            } else {
                                                ++currentSlot;
                                            }
                                        }
                                        if (InvManager.e[selectedIndex][this.currentItemIndex].currentSlot == 0 && n != 0) {
                                            break;
                                        }
                                    }
                                }
                                if (InvManager.e[selectedIndex][this.currentItemIndex].currentSlot > -1) {
                                    if (this.currentItemIndex < 9) {
                                        if (b != this.currentItemIndex) {
                                            Minecraft.GetPlayerControllerMp().a(ThePlayer.getInventoryContainer().i, (b < 9) ? (b + 36) : b, this.currentItemIndex, 2, Minecraft.GetPlayer(), 30);
                                            super.updateDelay();
                                        }
                                        InvManager.slotFilled[this.currentItemIndex] = true;
                                    } else {
                                        InvManager.slotFilled[b] = true;
                                    }
                                } else if (InventoryHelper.getMainInventorySlot(this.currentItemIndex) == null) {
                                    InvManager.slotFilled[this.currentItemIndex] = true;
                                }
                            } else {
                                InvManager.slotFilled[this.currentItemIndex] = true;
                            }
                        } else {
                            final byte integer2 = (byte) (this.currentItemIndex - InvManager.e[selectedIndex].length);
                            if (integer2 == 36) {
                                this.currentItemIndex = -1;
                                if (InvManager.clickSetting.isToggled()) {
                                    this.onDisable();
                                }
                                return;
                            }
                            if (!InvManager.slotFilled[integer2]) {
                                final com.craftrise.gM mainInventorySlot2 = InventoryHelper.getMainInventorySlot(integer2);
                                if (mainInventorySlot2 != null) {
                                    int a2 = 0;
                                    b3 itemobj;
                                    int maxdamage2 = 0;

                                    try {
                                        Method getItem = filterMethodFromReturnTypeAndParams(b3.class, gM.class);
                                        Method getMaxDamage = filterMethodFromReturnTypeAndParams(int.class, b3.class);
                                        Method getItemId = filterMethodFromReturnTypeAndParams(int.class, b3.class, b3.class);

                                        itemobj = (b3) getItem.invoke(mainInventorySlot2);
                                        int id = (int) getItemId.invoke(null, itemobj);
                                        a2 = id;
                                        maxdamage2 = (int) getMaxDamage.invoke(itemobj);
                                    } catch (Exception e) {
                                        Minecraft.addChatMessage(getStackTraceAsString(e));
                                    }

                                    for (int k = 0; k < InvManager.e[selectedIndex].length; k = (byte) (k + 1)) {
                                        if (InvManager.e[selectedIndex][k] != null) {
                                            for (int l = 0; l < InvManager.e[selectedIndex][k].itemIDs.length; l = (byte) (l + 1)) {
                                                if (a2 == InvManager.e[selectedIndex][k].itemIDs[l]) {
//                                                if (l > InvManager.e[selectedIndex][k].currentSlot + InvManager.e[selectedIndex][k].mode || (int) maxdamage2 - (int) mainInventorySlot2.b() <= InvManager.e[selectedIndex][k].limit) {
//                                                    Minecraft.GetPlayerControllerMp().a(ThePlayer.getInventoryContainer().i, (integer2 < 9) ? (integer2 + 36) : integer2, 1, 4, Minecraft.GetPlayer(), 0);
//                                                    super.updateDelay();
//                                                }
                                                    return;
                                                }
                                            }
                                        }
                                    }
                                    Minecraft.GetPlayerControllerMp().a(ThePlayer.getInventoryContainer().i, (integer2 < 9) ? (integer2 + 36) : integer2, 1, 4, Minecraft.GetPlayer(), 0);
                                    super.updateDelay();
                                }
                            }
                        }
                    } else {
                        this.currentItemIndex = -1;
                    }
            } catch (Exception e) {
                Minecraft.addToSendQueue(getStackTraceAsString(e));
            }
        }
    }
}
