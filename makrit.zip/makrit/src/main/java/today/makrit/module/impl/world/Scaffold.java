package today.makrit.module.impl.world;

import com.craftrise.dR;
import cr.launcher.BlockPos;
import cr.launcher.Config;
import cr.launcher.main.a;
import org.lwjgl.input.Keyboard;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.impl.player.InvManager;
import today.makrit.module.setting.BooleanSetting;
import today.makrit.module.setting.ModeSetting;
import today.makrit.module.setting.NumberSetting;
import today.makrit.utils.Helper.BlockHelper;
import today.makrit.utils.Helper.InventoryHelper;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import static today.makrit.gui.ArticPlayerController.onPlayerRightClick;
import static today.makrit.module.impl.combat.AutoArmor.getStackTraceAsString;

public class Scaffold extends Module {
    private Timer timer = new Timer();
    public static BooleanSetting tower = new BooleanSetting("Tower", false);
    private final ModeSetting towermode = new ModeSetting("Mode", "Rise", "Rise");
    public static BooleanSetting sprint = new BooleanSetting("Sprint", false);
    public static BooleanSetting itemSpoof = new BooleanSetting("Item Spoof", true);
    public static BooleanSetting debug = new BooleanSetting("Debug", false);
    public static BooleanSetting swing = new BooleanSetting("Swing", true);
    public static NumberSetting blockRange = new NumberSetting("Range", 4, 1, 8);
    public static BooleanSetting rotation = new BooleanSetting("Rotation", false);
    public static int[] blackList = new int[]{1, 3, 4, 5, 35, 159};

    private long lastPlacementTime = 0;
    private long delay = 0;

    public Scaffold() {
        super("Scaffold", ModuleCategory.WORLD, Keyboard.KEY_X);
        settings.add(itemSpoof);
        settings.add(sprint);
    }


    public boolean checkAdjacentAndPerformAction(final com.craftrise.gM itemStack, final int x, final int y, final int z) throws InterruptedException {
        for (int i = 0; i < 6; ++i) {
            int newX = x;
            int newY = y;
            int newZ = z;
            if (i == 0) {
                ++newY;
            } else if (i == 1) {
                --newY;
            } else if (i == 2) {
                ++newZ;
            } else if (i == 3) {
                --newZ;
            } else if (i == 4) {
                ++newX;
            } else {
                --newX;
            }
            final BlockPos blockPos = new BlockPos(newX, newY, newZ);

            if (Minecraft.getBlockID(blockPos) != 0) {
                scheduler.schedule(() -> {
                    try {
                        TimeUnit.MILLISECONDS.sleep(delay);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }, delay, TimeUnit.MILLISECONDS);
                if (rotation.isToggled()) {
                    Minecraft.addToSendQueue(Minecraft.C05PacketPlayerLook(ThePlayer.GetrotationYaw() - 180, 83, false));
                }
                if (onPlayerRightClick(itemStack, blockPos, com.craftrise.lG.values()[i], new com.craftrise.k3((double) newX, (double) newY, (double) newZ))) {
                    if (swing.isToggled()) {
                        Minecraft.sendSwing();
                    }
                    long currentTime = System.currentTimeMillis();
                    long elapsedTime = currentTime - lastPlacementTime;

                    if (elapsedTime < delay) {
                        long remainingTime = delay - elapsedTime;
                        Thread.sleep(remainingTime);
                    }

                    lastPlacementTime = System.currentTimeMillis();
                }
                return true;
            }
        }
        return false;
    }

    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    public static void setSpeed(double moveSpeed, float yaw, double strafe, double forward) {
        if (forward != 0.0D) {
            if (strafe > 0.0D) {
                yaw += ((forward > 0.0D) ? -45 : 45);
            } else if (strafe < 0.0D) {
                yaw += ((forward > 0.0D) ? 45 : -45);
            }
            strafe = 0.0D;
            if (forward > 0.0D) {
                forward = 1.0D;
            } else if (forward < 0.0D) {
                forward = -1.0D;
            }
        }
        if (strafe > 0.0D) {
            strafe = 1.0D;
        } else if (strafe < 0.0D) {
            strafe = -1.0D;
        }
        double mx = Math.cos(Math.toRadians((yaw + 90.0F)));
        double mz = Math.sin(Math.toRadians((yaw + 90.0F)));
        a.q.bh = new dR(forward * moveSpeed * mx + strafe * moveSpeed * mz);
        a.q.bf = new dR(forward * moveSpeed * mz - strafe * moveSpeed * mx);
    }

    public static double getBaseMoveSpeed() {
        double baseSpeed = a.q.S.b(5L) * 2.873;
        return baseSpeed;
    }

    public static void setSpeed(double moveSpeed) {
        setSpeed(moveSpeed, a.q.bL, a.q.l.c.a(5L), a.q.l.b.a(5L));
    }

    public static float facingToAngel(com.craftrise.lG facing) {
        float angle = 0;
        if (facing.equals(facing.NORTH))
            angle = 350;
        else if (facing.equals(facing.EAST))
            angle = -280;
        else if (facing.equals(facing.SOUTH))
            angle = 180;
        else if (facing.equals(facing.WEST))
            angle = 280;

        return angle;
    }
    public int t;

    @Override
    public void onRender2DEvent() {
        if (timer.hasTimeElapsed(35, true)) {
            if (isToggled()) {
                try {
                    final BlockPos blockPos = new BlockPos(ThePlayer.GetPosX(), ThePlayer.GetPosY(), ThePlayer.GetprevPosZ());
                    if (Minecraft.getBlockID(blockPos) == 0) {
                        if (tower.isToggled()) {
                            if (Objects.equals(towermode.getValue(), "AAC3") && Keyboard.isKeyDown(Keyboard.KEY_SPACE) && this.isToggled() && !ThePlayer.onGround() && System.currentTimeMillis() - this.lastJumpTime > 50L) {
                                ThePlayer.scaffoldjump();
                                this.lastJumpTime = System.currentTimeMillis();
                            }
                            if (Objects.equals(towermode.getValue(), "AAC3Old")) {
                                if (Keyboard.isKeyDown(Keyboard.KEY_SPACE)) {
                                        ThePlayer.SetMotionY(0.4195464);
                                        ThePlayer.setPosition_mid(ThePlayer.GetPosX() + 0.035, ThePlayer.GetPosY(), ThePlayer.GetPosZ());
                                        ThePlayer.SetMotionY(-0.5);
                                        ThePlayer.setPosition_mid(ThePlayer.GetPosX() + 0.035, ThePlayer.GetPosY(), ThePlayer.GetPosZ());
                                }
                            }
                            t++;
                            if (Objects.equals(towermode.getValue(), "Rise")) {
                                if(Keyboard.isKeyDown(Keyboard.KEY_SPACE) && ThePlayer.GetMotionX() == 0 && ThePlayer.GetMotionZ() == 0)
                                {
                                    if (t % 4 == 1) {
                                        ThePlayer.setPosition_mid(ThePlayer.GetPosX() - 0.035, ThePlayer.GetPosY(), ThePlayer.GetPosZ());
                                        ThePlayer.SetMotionY(0.4195464);
                                    } else if (t % 4 == 0) {
                                        ThePlayer.SetMotionY(-0.5);
                                        ThePlayer.setPosition_mid(ThePlayer.GetPosX() + 0.035, ThePlayer.GetPosY(), ThePlayer.GetPosZ());
                                    }
                                }
                            }
                        }
                        if (sprint.isToggled()) {
                            a.q.c(true);
                        } else {
                            a.q.c(false);
                        }
                        final int itemInInventory = InventoryHelper.findItemInInventory(Scaffold.blackList);
                        final int currentItemSlot = InventoryHelper.getCurrentItemSlot();

                        if (itemInInventory > -1) {
                            final com.craftrise.gM mainInventorySlot = InventoryHelper.getMainInventorySlot(itemInInventory);
                            if (currentItemSlot != itemInInventory) {
                                InventoryHelper.setCurrentItemSlot(itemInInventory);
                            }
                            final List<BlockPos> adjacentBlockPositions = BlockHelper.getAdjacentBlockPositions(BlockHelper.getX(blockPos), BlockHelper.getY(blockPos), BlockHelper.getZ(blockPos), (char) blockRange.getNumber());
                            for (final BlockPos adjacentPos : adjacentBlockPositions) {
                                if (debug.isToggled()) {
                                    Minecraft.addChatMessage("Placed Block at " + BlockHelper.getX(adjacentPos) + " " + BlockHelper.getY(adjacentPos) + " " + BlockHelper.getZ(adjacentPos));
                                }

                                if (checkAdjacentAndPerformAction(mainInventorySlot, BlockHelper.getX(adjacentPos), BlockHelper.getY(adjacentPos), BlockHelper.getZ(adjacentPos))) {
                                    break;
                                }
                            }

                            if (currentItemSlot != itemInInventory && Scaffold.itemSpoof.isToggled()) {
                                InventoryHelper.setCurrentItemSlot(itemInInventory);
                                InventoryHelper.setCurrentItemSlot(currentItemSlot);
                            }
                        }
                    }
                } catch (Exception e) {
                    InvManager.getStackTraceAsString(e);
                    Config.warn(getStackTraceAsString(e));
                }
            }
        }
    }
    private long lastJumpTime = System.currentTimeMillis();
}