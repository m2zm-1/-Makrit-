package today.makrit.module.impl.world;

import today.makrit.module.ModuleCategory;
import today.makrit.module.impl.SimpleModule;
import today.makrit.utils.mapper.ThePlayer;

public class AutoJump extends SimpleModule {

    public AutoJump() {
        super("AutoJump", ModuleCategory.WORLD, 1000, 10000);
    }

    @Override
    public void updateDelay() {
        if (this.toggled) {
            if (ThePlayer.onGround()) {
                ThePlayer.jump();
            }
        }
    }
}
