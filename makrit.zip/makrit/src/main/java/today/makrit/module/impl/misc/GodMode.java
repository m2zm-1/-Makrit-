package today.makrit.module.impl.misc;

import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.utils.mapper.ThePlayer;

public class GodMode extends Module {

    public GodMode() {
        super("GodMode", ModuleCategory.MISC, 0);
    }

    @Override
    public void onEnable() {
        ThePlayer.SetisDead(true);
    }

    @Override
    public void onDisable() {
        ThePlayer.SetisDead(false);
    }}
