package today.makrit.module.setting;

public class BooleanSetting extends Setting {
   private boolean toggled;

   public BooleanSetting(String name, boolean value) {
      super(name);
      this.toggled = value;
   }

   public boolean isToggled() {
      return this.toggled;
   }

   public void toggle() {
      this.toggled = !this.toggled;
   }
}
