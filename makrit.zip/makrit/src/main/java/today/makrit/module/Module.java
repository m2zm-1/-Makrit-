package today.makrit.module;

import dev.client.tenacity.ui.notifications.Notification;
import dev.client.tenacity.ui.notifications.NotificationManager;
import today.makrit.event.EventBus;
import today.makrit.module.setting.Setting;
import today.makrit.utils.Renderer.Animation;
import today.makrit.utils.Renderer.DecelerateAnimation;

import java.util.ArrayList;
import java.util.List;

public class Module {
    public ModuleCategory cat;
    public boolean toggled = false;
    public final Animation animation = new DecelerateAnimation(250, 1);
    public static boolean shouldToggle = false;
    public boolean wasKeyPressed;
    public int key;
    public List<Setting> settings = new ArrayList<>();
    public String name;
    public int y;

    private boolean keyIsPressed = false;

    public void onRender2DEvent() {
    }

    public void onRender2DEvent(float partialTicks) {
    }


    public static void preRender2DEvent(float partialTicks) {
        for (Module module : ModuleManager.all()) {
            module.onRender2DEvent(partialTicks);
        }
    }


    public void onRender3DEvent(float partialTicks) {
    }

    public boolean onDrawOutlinedBoundingBoxEvent(com.craftrise.ah axisAlignedBB, int integer2, int integer3, int integer4, int integer5) {
        return false;
    }

    public static boolean drawOutlinedBoundingBoxEvent(com.craftrise.ah axisAlignedBB, int integer2, int integer3, int integer4, int integer5) {
        for (Module module : ModuleManager.all()) {
            if (module.onDrawOutlinedBoundingBoxEvent(axisAlignedBB, integer2, integer3, integer4, integer5)) {
                return true;
            }
        }
        return false;
    }

    public static void renderParticlesEvent(float partialTicks) {
        for (Module module : ModuleManager.all()) {
            module.onRender3DEvent(partialTicks);
        }
    }

    public static void render2DEvent() {
        for (Module module : ModuleManager.all()) {
            module.onRender2DEvent();
        }
    }

    public Module(String name, ModuleCategory cat, int key) {
        this.name = name;
        this.cat = cat;
        this.key = key;

    }

    public void onEnable() {}

    public void onDisable() {}

    public boolean unToggled() {
        return this.toggled = false;
    }

    public void onKeyPress() {
        if (!keyIsPressed) {
            toggle();
            keyIsPressed = true;
        }
    }

    public void onKeyRelease() {
        keyIsPressed = false;
    }

    public void toggle() {
        String titleToggle = "Module toggled";
        String descriptionToggleOn = name + " was " + "§aenabled\r";
        String descriptionToggleOff = name + " was " + "§cdisabled\r";
        toggled = !toggled;
        if (toggled) {
            onEnable();
            EventBus.subscribe(this);
            NotificationManager.post(Notification.NotificationType.SUCCESS, titleToggle, descriptionToggleOn);
        } else {
            onDisable();
            EventBus.unSubscribe(this);
            NotificationManager.post(Notification.NotificationType.DISABLE, titleToggle, descriptionToggleOff);
        }
    }

    public boolean isToggled() {
        return toggled;
    }

}
