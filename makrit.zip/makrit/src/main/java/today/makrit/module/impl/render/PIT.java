package today.makrit.module.impl.render;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.BooleanSetting;
import today.makrit.module.setting.NumberSetting;
import today.makrit.utils.Renderer.FontUtil;
import today.makrit.utils.Renderer.RenderUtil;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.TheWorld;
import com.craftrise.mg;

import java.awt.*;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class PIT extends Module {
    private String targetName;
    public Timer timer = new Timer();
    public static NumberSetting range = new NumberSetting("Range", 310, 2, 500);
    public static BooleanSetting bedwars = new BooleanSetting("BedTP", true);

    public PIT() {
        super("PIT", ModuleCategory.RENDER, 0);
    }

    @Subscribe
    public void render(RenderEvent re) {
        List<mg> playerList = TheWorld.playerEntities();
        mg closestPlayer = null;
        double closestDistance = Double.MAX_VALUE;

        for (mg player : playerList) {
            if (player != Minecraft.GetPlayer()) {
                float distance = GetDistanceToEntity(player);

                if (distance < closestDistance) {
                    closestPlayer = player;
                    closestDistance = distance;
                }
            }
        }

        if (closestPlayer != null) {
            this.targetName = Minecraft.getEntityDisplayName(closestPlayer);

            List<mg> targets = TheWorld.playerEntities()
                    .stream()
                    .filter(e -> GetDistanceToEntity(e) < (bedwars.isToggled() ? 9999 : range.getNumber()) && e != Minecraft.GetPlayer())
                    .sorted(Comparator.comparingDouble(entity -> GetDistanceToEntity(entity)))
                    .collect(Collectors.toList());

            if (!targets.isEmpty()) {
                mg target = targets.get(0);
                float targetHealth = Minecraft.getEntityHealth(target);

                if (!this.targetName.contains("[CR]") && Minecraft.getEntityHealth(target) != 1.0) {
                    int distanceInBlocks = GetDistanceToEntityInBlocks(target);
                    String nameWithColors = Minecraft.getEntityDisplayName(target);
                    String nameWithoutColors = nameWithColors.replaceAll("§[0-9a-fA-Fk-oK-OrRgG]", "");
                    String displayText = String.format("%s %d blok %.1fhp", nameWithoutColors, distanceInBlocks, targetHealth);
                    FontUtil.tenacityFont18.drawStringWithShadow(displayText, Minecraft.getScreenWidth() / 2 - RenderUtil.getTextWidth(this.targetName) / 2, 3, Color.WHITE.getRGB());
                    //RenderUtil.renderText(displayText, Minecraft.getScreenWidth() / 2 - RenderUtil.getTextWidth(this.targetName) / 2, 3, Color.WHITE.getRGB(), false);
                    timer.reset();
                }
            }
        }
    }

    public static float GetDistanceToEntity(mg entity) {
        try {
            float f = (float) (Minecraft.GetPlayer().bE - entity.bE);
            float f2 = (float) (Minecraft.GetPlayer().aY - entity.aY);
            float f3 = (float) (Minecraft.GetPlayer().bH - entity.bH);
            return (float) Math.sqrt(f * f + f2 * f2 + f3 * f3);
        } catch (Exception exception) {
            Minecraft.addChatMessage("Distance error: " + exception.toString());
            return -1.0f;
        }
    }

    public static int GetDistanceToEntityInBlocks(mg entity) {
        try {
            float distance = GetDistanceToEntity(entity);
            float metersPerBlock = 1.0f; // Bu değeri ihtiyacınıza göre ayarlayın.
            return Math.round(distance / metersPerBlock);
        } catch (Exception exception) {
            Minecraft.addChatMessage("Distance error: " + exception.toString());
            return -1;
        }
    }
}
