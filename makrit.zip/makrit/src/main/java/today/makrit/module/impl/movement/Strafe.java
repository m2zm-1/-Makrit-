package today.makrit.module.impl.movement;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;

public class Strafe extends Module {
    float degreesToRadians(float degrees) {
        return degrees * (3.14159265358979323846f / 180.0f);
    }
    public Strafe() {
        super("Strafe", ModuleCategory.MOVEMENT, 0);
    }
    public Timer timer = new Timer();
    @Subscribe
    public void render(RenderEvent re) {
        double x = ThePlayer.GetMotionX();
        double z = ThePlayer.GetMotionZ();
        double shotSpeed = Math.sqrt(x * x + z * z);
        float rotationYaw = ThePlayer.GetrotationYaw();
        //float strafing = get_movestrafe(thePlayer_obj, env);
        //float forwarding = get_moveforward(thePlayer_obj, env);

        if (Minecraft.GetPlayer().l.b.a(5L) < 0.0f) {
            rotationYaw += 180.0f;
        }
        float f2 = 1.0f;
        if (Minecraft.GetPlayer().l.b.a(5L) < 0.0f) {
            f2 = -0.5f;
        } else if (Minecraft.GetPlayer().l.b.a(5L) > 0.0f) {
            f2 = 0.5f;
        }
        if (Minecraft.GetPlayer().l.c.a(5L) > 0.0f) {
            rotationYaw -= 90.0f * f2;
        }
        if (Minecraft.GetPlayer().l.c.a(5L) < 0.0f) {
            rotationYaw += 90.0f * f2;
        }
        double direction = degreesToRadians(rotationYaw);

        ThePlayer.SetMotionX(-Math.sin(direction) * shotSpeed);
        ThePlayer.SetMotionZ(Math.cos(direction) * shotSpeed);
    }
}
