package today.makrit.module.impl.misc;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.ModeSetting;
import today.makrit.utils.Helper.InventoryHelper;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import com.craftrise.qd;
import org.lwjgl.input.Mouse;

public class Disconnect extends Module {
    private ModeSetting mode = new ModeSetting("Mode", "AAC", "AAC");
    public static int[] blackList = new int[]{267, 268, 272, 276, 283, 322, 364};

    public Disconnect() {
        super("Disconnect", ModuleCategory.MOVEMENT, 0);
        settings.add(mode);
    }

    public Timer timer = new Timer();

    @Override
    public void onEnable() {
        Minecraft.addChatMessage("Press Right Click for Disconnect");
    }

    @Subscribe
    public void render(RenderEvent re) {
        if (timer.hasTimeElapsed(1000 / 50, true)) {
            if (this.toggled) {
                final int itemInInventory = InventoryHelper.findItemInInventory(blackList);
                final int currentItemSlot = InventoryHelper.getCurrentItemSlot();
                if (Mouse.isButtonDown(1)) {
                    if (ThePlayer.GetticksExisted % 8 == 0) {
                        qd C08PacketPlayerBlockPlacement = (new qd());
                        Minecraft.addToSendQueue(C08PacketPlayerBlockPlacement);
                    }
                }
            }
        }
    }
}