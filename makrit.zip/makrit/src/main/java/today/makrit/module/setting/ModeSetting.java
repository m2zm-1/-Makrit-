package today.makrit.module.setting;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ModeSetting extends Setting {
   private String value;
   public List<String> values;

   public ModeSetting(String name, String value, String... values) {
      super(name);
      this.value = value;
      this.values = new ArrayList(Arrays.asList(values));
   }

   public String getValue() {
      return this.value;
   }

   public void toggle() {
      if (this.values.indexOf(this.value) + 1 >= this.values.size()) {
         this.value = (String)this.values.get(0);
      } else {
         this.value = (String)this.values.get(this.values.indexOf(this.value) + 1);
      }

   }
}
