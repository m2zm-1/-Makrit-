package today.makrit.module.impl.misc;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.ModeSetting;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import today.makrit.utils.mapper.TheWorld;
import com.craftrise.lE;
import com.craftrise.lv;
import com.craftrise.mg;
import cr.launcher.main.a;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

public class NoRotate extends Module {
    private ModeSetting mode = new ModeSetting("Mode", "Shit", "Shit");

    public NoRotate() {
        super("NoRotate", ModuleCategory.MISC, 0);
        settings.add(mode);
    }
    public Timer timer1 = new Timer();

    public static void sendPacket(lv<?> packet, boolean silent)
    {
        if (a.q != null)
        {
        }
    }
    public static void sendPacketNoEvent(lv packet)
    {
        sendPacket(packet, true);
    }

    public static void sendPacket(lv packet)
    {
        sendPacket(packet, false);
    }
    public Timer timer = new Timer();

    @Subscribe
    public void render(RenderEvent event) throws InvocationTargetException, NoSuchMethodException, IllegalAccessException {
        if (timer1.hasTimeElapsed(5000, true)) {
            List<mg> targets = TheWorld.playerEntities();
            for (int i = 0; i < targets.size(); i++) {
                ThePlayer.rotationYawHead(ThePlayer.GetrotationYaw());
                ThePlayer.renderYawOffset(ThePlayer.GetrotationYaw());
                Minecraft.addToSendQueue(new lE.c(a.q.bE,
                        a.q.aY,
                        a.q.bH,
                        a.q.bL,
                        a.q.N,
                        a.q.s.a(5L)));
            }
        }
    }
}
