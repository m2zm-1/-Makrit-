package today.makrit.module.impl.misc;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.PacketSentEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.ModeSetting;
import com.craftrise.pE;
import com.craftrise.pT;
import cr.launcher.main.a;

public class AntiFrozen extends Module {

    public AntiFrozen() {
        super("AntiFrozen", ModuleCategory.MISC, 0);
        settings.add(mode);
    }
    private final ModeSetting mode = new ModeSetting("Mode", "Normal", "Normal", "Teleport");
    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscribe
    public void onTick(PacketSentEvent ev) {
        if (ev.getPacket() instanceof pE) {
            ev.cancel();
        } else if (ev.getPacket() instanceof pT
                && ((pT) ev.getPacket()).a().getUnformattedText().contains("frozen")) {
            if (mode.name == "Teleport") {
                a.q.aY = -999;
            }
            ev.cancel();
        }
    }
}
