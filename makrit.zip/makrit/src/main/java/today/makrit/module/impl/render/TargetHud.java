package today.makrit.module.impl.render;

import store.intent.intentguard.annotation.Exclude;
import store.intent.intentguard.annotation.Strategy;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.DoubleSetting;
import today.makrit.module.setting.ModeSetting;

public class TargetHud extends Module {
    public static ModeSetting mode = new ModeSetting("Mode", "Exhibition", "Rise");

    public static DoubleSetting y = new DoubleSetting("Y", 200, 1, 2500);
    public static DoubleSetting x = new DoubleSetting("X", 285, 1, 2500);

    public TargetHud() {
        super("TargetHud", ModuleCategory.RENDER, 0);
        this.toggle();
        settings.add(x);
        settings.add(y);
    }
    private static float absorptionAmount;

    @Exclude(Strategy.NAME_REMAPPING)
    public static float getAbsorptionAmount() {
        return absorptionAmount;
    }

    public static float getMaxHealth() {
        return 20f;
    }
    private static float widthh;
    private static float heighht;

    public static void setWidth(float width) {
        widthh = width;
    }

    public static void setHeight(float height) {
        heighht = height;
    }

    public static float getWidth() {
        return widthh;
    }

    public static float getHeight() {
        return heighht;
    }
}
