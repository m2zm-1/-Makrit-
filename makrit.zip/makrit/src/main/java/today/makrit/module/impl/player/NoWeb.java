package today.makrit.module.impl.player;

import com.google.common.eventbus.Subscribe;
import cr.launcher.Config;
import org.lwjgl.input.Keyboard;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.ModeSetting;
import today.makrit.utils.mapper.ThePlayer;

import java.util.Objects;

public class NoWeb extends Module {
    private ModeSetting mode = new ModeSetting("Mode", "OldAAC", "OldAAC", "Normal", "FastFall");

    public NoWeb() {
        super("NoWeb", ModuleCategory.PLAYER, 0);
        settings.add(mode);
    }

    public static com.craftrise.client.gR keybindSneak = Config.getGameSettings().a4;

    private static boolean isKeyPressed(int keyCode) {
        return Keyboard.isKeyDown(keyCode);
    }


    @Subscribe
    public void onTick(RenderEvent e) {
        if (isToggled()) {
            if (Objects.equals(mode.getValue(), "OldAAC")) {
                if (ThePlayer.GetisInWeb()) {
                    ThePlayer.jumpMovementFactor(0.59f);
                    if (!Config.getGameSettings().a(keybindSneak)) {
                        ThePlayer.SetMotionY(0);
                    }
                }
            }
            if (Objects.equals(mode.getValue(), "Normal")) {
                ThePlayer.SetisInWeb(false);
            }
            if (Objects.equals(mode.getValue(), "FastFall")) {
                if (ThePlayer.GetisInWeb()) {
                    if (ThePlayer.onGround()) ThePlayer.jump();
                    if (ThePlayer.GetMotionY() > 0f) {
                        ThePlayer.SetMotionY(ThePlayer.GetMotionY() * 2);
                    }
                }
            }
        }
    }
}