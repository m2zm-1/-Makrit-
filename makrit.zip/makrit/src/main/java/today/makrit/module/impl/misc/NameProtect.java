package today.makrit.module.impl.misc;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;

public class NameProtect extends Module {

    public NameProtect() {
        super("NameProtect", ModuleCategory.MISC, 0);
        this.toggle();
    }

    @Subscribe
    public void onTick(RenderEvent e) {


    }
}
