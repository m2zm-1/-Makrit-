package today.makrit.module.setting;

public class DelaySetting extends Setting {
   private int range;
   private int width;
   private int height = 0;
   public boolean dragging = false;

   public DelaySetting(int integer1, int integer2) {
      super("AllahinAmi");
      this.range = integer2;
      this.width = integer1;
   }

   public int getSelectedDelay() {
      return this.width;
   }
}
