package today.makrit.module.impl.movement;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.ThePlayer;

public class Step extends Module {

    public Step() {
        super("Step", ModuleCategory.MOVEMENT, 0);
    }

    public Timer timer = new Timer();
    private boolean isAACStep = false;

    @Subscribe
    public void render(RenderEvent re) {
        if (timer.hasTimeElapsed(50, true)) {
            if (ThePlayer.isCollidedHorizontally() && ThePlayer.onGround()) {
                ThePlayer.jump();
            }
        }
    }
}