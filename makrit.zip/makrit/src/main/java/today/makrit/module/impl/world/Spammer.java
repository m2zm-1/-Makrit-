package today.makrit.module.impl.world;

import today.makrit.module.ModuleCategory;
import today.makrit.module.impl.SimpleModule;
import today.makrit.module.setting.NumberSetting;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.ThePlayer;

import java.security.SecureRandom;

public class Spammer extends SimpleModule {
    private static final NumberSetting delay = new NumberSetting("Delay Second", 10, 1, 32);
    public Timer timer = new Timer();
    public Spammer() {
        super("Spammer", ModuleCategory.WORLD, 0, 0);
        settings.add(delay);
        this.toggle();
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.toggle();
    }

    @Override
    public void updateDelay() {
        if(this.isToggled() && timer.hasTimeElapsed((1000 * delay.getNumber()), true)) {
            ThePlayer.sendMessage("Mitamers gg/mitamershub " + generateRandomString(8));
        }
        super.updateDelay();
    }

    private static final String CHARACTERS = "abcdefgkjlsdljfweLKSJDFJWRNBNWRKj";

    public static String generateRandomString(int length) {
        SecureRandom random = new SecureRandom();
        StringBuilder sb = new StringBuilder(length);

        for (int i = 0; i < length; i++) {
            int randomIndex = random.nextInt(CHARACTERS.length());
            char randomChar = CHARACTERS.charAt(randomIndex);
            sb.append(randomChar);
        }

        return sb.toString();
    }
}
