package today.makrit.module.impl.render;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.utils.Renderer.Animation;
import today.makrit.utils.Renderer.Direction;
import today.makrit.utils.Renderer.DecelerateAnimation;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.TheWorld;
import today.makrit.utils.mapper.GlStateManager;

import java.awt.*;


public class Tracers extends Module {

    public Tracers(){
        super("Tracers", ModuleCategory.RENDER, 0);
    }
    private final Animation auraESPAnim = new DecelerateAnimation(300, 1);

    public void render(RenderEvent event)
    {
        if (Minecraft.getCurrentScreen() == null)
        {
            GlStateManager.pushMatrix();
            for(Object o : TheWorld.loadedEntityList())
            {
                com.craftrise.m9 ent = (com.craftrise.m9) o;
                if (ent == Minecraft.GetPlayer() && Minecraft.getEntityHealth(ent) != 1.0)
                {
                    continue;
                }
                auraESPAnim.setDirection(ent != null ? Direction.FORWARDS : Direction.BACKWARDS);
                if (!(ent instanceof com.craftrise.m9))
                {
                    continue;
                }
                Color color = Color.WHITE;
                //drawTracerLine(ent,4f,Color.BLACK,auraESPAnim.getOutput());
                //drawTracerLine(ent,2.5f, color, auraESPAnim.getOutput());
            }
        }
    }


}