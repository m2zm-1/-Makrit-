package today.makrit.module.impl.player;

class InvManagerStruct {
    public byte mode;
    public byte currentSlot;
    public int limit;
    public int[] itemIDs;

    public InvManagerStruct(final int integer, final int... arr) {
        this.mode = (byte) integer;
        this.limit = Integer.MIN_VALUE;
        this.itemIDs = arr;
        this.currentSlot = -1;
    }

    public InvManagerStruct setLimit(final int integer) {
        this.limit = integer;
        return this;
    }
}
