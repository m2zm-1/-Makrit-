package today.makrit.module.impl.world;

import cr.launcher.CustomGuis;
import cr.launcher.ResourceLocation;
import cr.launcher.SpecialCapeTypes;
import org.lwjgl.opengl.GL11;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.net.minecraft.client.Minecraft;
import today.net.minecraft.client.gui.Gui;
import today.net.minecraft.client.gui.ScaledResolution;
import today.net.minecraft.client.renderer.GlStateManager;

public class Reporter extends Module {
    public Reporter() {
        super("Test", ModuleCategory.WORLD, 0);
    }

    public static void renderSteveModelTexture(final double x, final double y, final float u, final float v, final int uWidth, final int vHeight, final int width, final int height, final float tileWidth, final float tileHeight) {
        final ResourceLocation skin = new ResourceLocation("minecraft", "textures/rise/frame_texture.png");
        GlStateManager.bindTexture2(skin);
        GL11.glEnable(GL11.GL_BLEND);
        Gui.drawScaledCustomSizeModalRect((int) x, (int) y, u, v, uWidth, vHeight, width, height, tileWidth, tileHeight);
        GL11.glDisable(GL11.GL_BLEND);
    }
    public static ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());

    @Override
    public void onEnable() {
        final ResourceLocation skin = new ResourceLocation("minecraft", "textures/entity/steve.png");
        cr.launcher.DefaultPlayerSkin.isDefaultSkin(skin);
        SpecialCapeTypes.RAUFAI_CAPE.setRendered(true);
        SpecialCapeTypes.RAUFAI_CAPE.renderCape();
        SpecialCapeTypes.CAPES_IS_BYPASSED = false;
        cr.launcher.TextureManager.createFrameTexture(SpecialCapeTypes.RAUFAI_CAPE);
        CustomGuis.isChristmas = true;
    }

    //    @Override
//    public void onRender2DEvent(float partialTicks) {
//        if(this.toggled) {
//            renderSteveModelTexture(((sr.getScaledWidth() - 146)) / 2f, (sr.getScaledHeight() / 2F + 167) - 60, 3, 3, 3, 3, 36, 36, 24, 24);
//            renderSteveModelTexture(((sr.getScaledWidth() - 146)) / 2f, (sr.getScaledHeight() / 2F + 167) - 60, 15, 3, 3, 3, 36, 36, 24, 24);
//        }
//    }
}