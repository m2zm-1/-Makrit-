package today.makrit.module.setting;

import exela.craftrise.module.setting.interfaces.IRunnable;

public class RunnableSetting extends Setting {
   public String name;
   private final IRunnable runnable;

   public RunnableSetting(String string, IRunnable iRunnable, Setting setting) {
      super(string);
      this.name = string;
      this.runnable = iRunnable;
   }

   public RunnableSetting(String string, IRunnable iRunnable) {
      this(string, iRunnable, (Setting)null);
   }
}
