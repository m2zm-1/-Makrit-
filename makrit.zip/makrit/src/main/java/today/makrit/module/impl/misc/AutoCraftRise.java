package today.makrit.module.impl.misc;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.utils.Helper.InventoryHelper;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.ThePlayer;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class AutoCraftRise extends Module {

    public AutoCraftRise() {
        super("AutoCraftRise", ModuleCategory.MISC, 0);
    }

    public static int[] blackList = new int[]{339};

    public Timer timer = new Timer();
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    @Subscribe
    public void onTick(RenderEvent re) {
        if (timer.hasTimeElapsed(1000, true)) {
            final int itemInInventory = InventoryHelper.findItemInInventory(blackList);
            final int currentItemSlot = InventoryHelper.getCurrentItemSlot();

            if (itemInInventory > -1) {
                final com.craftrise.gM mainInventorySlot = InventoryHelper.getMainInventorySlot(itemInInventory);
                if (currentItemSlot != itemInInventory) {
                    ThePlayer.sendMessage("/müso");
                }
            }
        }
    }
}