package today.makrit.module.impl.render;

import com.google.common.eventbus.Subscribe;
import cr.launcher.ResourceLocation;
import net.minecraft.client.gui.Gui;
import org.lwjgl.opengl.GL11;
import today.makrit.event.impl.RenderEvent;
import today.makrit.gui.GuiHook;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.BooleanSetting;
import today.makrit.module.setting.ModeSetting;
import today.makrit.utils.Renderer.*;

import java.awt.*;

public class Hud extends Module {
    public static ModeSetting mode = new ModeSetting("Mode", "Metalix", "Mitamersv2", "Mitamers", "Lucille", "Metalix");
    public static ModeSetting modesettingssss = new ModeSetting("ArrayList Mode", "Metalix", "Mitamers", "Mitamersv2", "Lucille", "Metalix");
    public static BooleanSetting hueInterpolation = new BooleanSetting("Hue", false);
    public static BooleanSetting movingColors = new BooleanSetting("Moving Colors", false);

    public Hud() {
        super("Hud", ModuleCategory.RENDER, 0);
        settings.add(modesettingssss);
        settings.add(mode);
        settings.add(hueInterpolation);
        settings.add(movingColors);
        this.toggle();
    }

    @Subscribe
    public void onTick(RenderEvent e) {
        if (mode.getValue().equals("Mitamersv2")) {
            double xpos2 = 8;
            float xpos = 8;
            Float ypos = 13.0f;
            Float ypos2 = 26.0f;
            String text = "dev : makritxd";
            MinecraftFontRenderer.drawFontedString4(text, xpos2, ypos);
            ResourceLocation kel = new ResourceLocation("textures/babalar.png");
            today.makrit.utils.mapper.Minecraft.getTextureManager().b(kel, 2L);
            int imageWidth = 100;
            int imageHeight = 100;
            int xVersion = 10;
            int yVersion = 32;
            RenderUtil.color(Color.white);
            Gui.drawScaledCustomSizeModalRect(xVersion, yVersion, 0, 0, 64, 64, imageWidth, imageHeight, 64, 64);
        }
        if (modesettingssss.getValue().equals("Mitamersv2")) {
            GuiHook.DrawMethod2();
        }
        if (mode.getValue().equals("Mitamers")) {
            Double xpos = 8.0;
            Float ypos = 13.0f;

            String text = "mitamers.dev";
            MinecraftFontRenderer.drawFontedString3(text, xpos, ypos);

        }
        if (modesettingssss.getValue().equals("Mitamers")) {
            GuiHook.drawArrayList();
        }
        if (mode.getValue().equals("Lucille")) {
            String watermark = "mitamers | " + today.makrit.utils.mapper.Minecraft.getDebugFPS() + " FPS | 3.1";
            float watermarkWidth = RenderUtil.getTextWidth(watermark);
            int rectWidth = RenderUtil.getTextWidth(watermark) - 8;
            int rectHeight = 12;
            RenderUtil3.drawGlowGradient(1, 1, rectWidth + 1, rectHeight + 1, 3, Color.DARK_GRAY, Color.DARK_GRAY, Color.DARK_GRAY, Color.DARK_GRAY);
            RenderUtil3.drawRoundedRect(2.5, 2.5, watermarkWidth - 8, 12.0, 2.0, new Color(40, 40, 40, 255).getRGB());
            String afterM = "itamers | " + today.makrit.utils.mapper.Minecraft.getDebugFPS() + " FPS | 3.1"; // "m"den sonraki kısım
            float beforeMWidth = (float) FontUtil.tenacityFont18.getStringWidth("m");
            FontUtil.tenacityFont18.drawString("m", 5.0, 5.0, new Color(165, 5, 5, 255).getRGB());
            float mWidth = (float) FontUtil.tenacityFont18.getStringWidth("m");
            FontUtil.tenacityFont18.drawString(afterM, 5.0 + mWidth, 5.0, new Color(255, 255, 255, 255).getRGB());
        }


        if (modesettingssss.getValue().equals("Lucille")) {
            GuiHook.DrawMethod3();
        }

        if (mode.getValue().equals("Metalix")) {
            int speed = 2500;
            int i = 0;
            float initialYPos = 12;
            String watermark = "mitamers 2.0";
            int rectWidth = RenderUtil.getTextWidth(watermark);
            int rectHeight = 12;
            float xPos = 2.5f;
            float yPos = 13f;
            RenderUtil3.drawGlowGradient(xPos - 5, yPos - 1, rectWidth + 16, rectHeight + 2, 20, Color.CYAN, Color.CYAN, Color.CYAN, Color.CYAN);
            FontUtil.tenacityBoldFont32.drawStringWithShadow(watermark, xPos, yPos, MinecraftFontRenderer.getBlueToGreenRainbow(speed, initialYPos, i));
        }



        if (modesettingssss.getValue().equals("Metalix")); {
            GuiHook.DrawMethod5();
        }

    }


    public static void drawSmoothRainbowLine(float x1, float y1, float x2, float y2, float thickness, int color) {
        GL11.glPushMatrix();
        GL11.glLineWidth(thickness);

        float red = (color >> 16 & 255) / 255.0f;
        float green = (color >> 8 & 255) / 255.0f;
        float blue = (color & 255) / 255.0f;
        float alpha = (color >> 24 & 255) / 255.0f;

        GL11.glBegin(GL11.GL_LINES);

        GL11.glColor4f(red, green, blue, alpha);

        GL11.glVertex2f(x1, y1);
        GL11.glVertex2f(x2, y2);

        GL11.glEnd();
        GL11.glPopMatrix();
    }

    public static void drawSmoothRectWithGlow(double x, double y, double width, double height, double radius, Color color, float glowRadius) {
        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        for (int i = 0; i < glowRadius; i++) {
            float glowAlpha = (float) (color.getAlpha() * (1.0f - (float) i / glowRadius)) / 255.0f;
            double expansion = i * 0.25;
            GL11.glColor4f(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, glowAlpha);

            RenderUtil.drawRoundedRect(x - expansion, y - expansion, width + 2 * expansion, height + 2 * expansion, radius + expansion,
                    new Color(color.getRed(), color.getGreen(), color.getBlue(), (int) (glowAlpha * 255)).getRGB());
        }
        GL11.glColor4f(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f);
        RenderUtil.drawRoundedRect(x, y, width, height, radius, color.getRGB());

        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glPopMatrix();
    }
    public static void drawSmoothRect(float x1, float y1, float x2, float y2) {
        GL11.glBegin(GL11.GL_QUADS);
        GL11.glVertex2f(x1, y1);
        GL11.glVertex2f(x2, y1);
        GL11.glVertex2f(x2, y2);
        GL11.glVertex2f(x1, y2);
        GL11.glEnd();
    }

}
