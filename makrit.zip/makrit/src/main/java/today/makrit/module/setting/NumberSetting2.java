package today.makrit.module.setting;

import today.makrit.module.setting.Setting;

public class NumberSetting2 extends Setting {

    private double value, minimum, maximum, increment;

    public NumberSetting2(String name, double value, double minimum, double maximum, double increment) {
        this.name = name;
        this.value = value;
        this.minimum = minimum;
        this.maximum = maximum;
        this.increment = increment;
    }

    public double getNumber() {
        return value;
    }

    public void setValue(double value) {
        if (value < minimum) {
            this.value = minimum;
        } else if (value > maximum) {
            this.value = maximum;
        } else {
            this.value = value;
        }
    }

    public void increment(boolean positive) {
        if (positive) {
            setValue(getNumber() + increment);
        } else {
            setValue(getNumber() - increment);
        }
    }

    public double getMinimum() {
        return minimum;
    }

    public double getMaximum() {
        return maximum;
    }

    public double getIncrement() {
        return increment;
    }

    @Override
    public String getName() {
        return name;
    }
}
