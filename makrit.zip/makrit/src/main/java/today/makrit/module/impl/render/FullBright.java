package today.makrit.module.impl.render;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.utils.mapper.Minecraft;

public class FullBright extends Module {
    public FullBright() {
        super("FullBright", ModuleCategory.RENDER, 0);
    }

    @Subscribe
    public void onRender(RenderEvent e) {
        if(this.toggled) {
            Minecraft.setGammaSetting(100);
        }
    }
}
