package today.makrit.module.setting;

import exela.craftrise.module.Module;

public class KeybindSetting extends Setting {
   private int code;
   public Module module;

   public KeybindSetting(Module module, int code) {
      super("Bind");
      this.code = code;
      this.module = module;
   }

   public int getCode() {
      return this.code == -1 ? 0 : this.code;
   }

   public void setCode(int code) {
      this.code = code;
   }

   public Module getModule() {
      return this.module;
   }
}
