package today.makrit.module.impl.player;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.NumberSetting;
import today.makrit.utils.Helper.BlockHelper;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import cr.launcher.BlockPos;
import cr.launcher.Config;

import java.lang.reflect.Field;

public class Eagle extends Module {
    public static NumberSetting yDist;
    public static com.craftrise.client.gR keybindSneak = Config.getGameSettings().a4;

    static {
        Eagle.yDist = new NumberSetting("BlockY distance", 0, 2, 50);
    }

    public boolean safe;

    public Eagle() {
        super("Eagle", ModuleCategory.PLAYER, 0);
        settings.add(yDist);
        this.safe = false;
    }

    public static void setPressed(boolean value){
        try {
            Class EntityClazz = Class.forName("com.craftrise.client.gR");

            for(Field f : EntityClazz.getDeclaredFields()) {
                if(f.getName().equals("b")) {
                    f.setAccessible(true);

                    f.set(keybindSneak, value);
                }
            }
        } catch (Exception e) {
            Minecraft.addChatMessage(e.toString() + " Exception");
        }
    }

    @Override
    public void onDisable() {
        if (this.safe) {
            setPressed(false);
            this.safe = false;
        }
        super.onDisable();
    }

    @Subscribe
    public void onRender(RenderEvent e) {
        if (this.isToggled()) {
            final double n = (ThePlayer.GetPosY() == (int) ThePlayer.GetPosY()) ? (ThePlayer.GetPosY() - 1.0) : ThePlayer.GetPosY();
            if (ThePlayer.onGround()) {
                cr.launcher.BlockPos blockPos;
                int n2;
                for (blockPos = new cr.launcher.BlockPos(ThePlayer.GetPosX(), n, ThePlayer.GetprevPosZ()), n2 = 0; n2 <= Eagle.yDist.getNumber() && Minecraft.getBlockID(new BlockPos(BlockHelper.getX(blockPos), BlockHelper.getY(blockPos) - n2, BlockHelper.getZ(blockPos))) == 0; ++n2) {
                }
                if (n2 == Eagle.yDist.getNumber() + 1) {
                    setPressed(true);
                    this.safe = true;
                    return;
                }
            }
            if (this.safe) {
                setPressed(false);
                this.safe = false;
            }
        }
    }
}
