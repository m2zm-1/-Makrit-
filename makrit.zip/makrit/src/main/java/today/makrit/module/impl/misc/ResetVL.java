package today.makrit.module.impl.misc;

import today.makrit.event.impl.PacketSentEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import com.craftrise.dR;
import cr.launcher.main.a;

public class ResetVL extends Module {

    public ResetVL() {
        super("ResetVL", ModuleCategory.MISC, 0);
    }

    private int jumped;
    private double y;

    public void onTick(PacketSentEvent ev) {
        if(cr.launcher.main.a.q.s.a(5L)) {
            if(jumped <= 25) {
                a.q.aT= new dR(0.11);
                jumped++;
            }
        }
        if(jumped <= 25) {
            cr.launcher.main.a.q.aY = y;
            //mc.timer.timerSpeed = 2.25f;
        }else{
            // mc.timer.timerSpeed = 1;
            toggle();
        }
    };

    @Override
    public void onEnable() {
        jumped = 0;
        y = a.q.aY;
        super.onEnable();
    }
}
