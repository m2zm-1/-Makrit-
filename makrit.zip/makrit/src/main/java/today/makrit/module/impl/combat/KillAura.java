package today.makrit.module.impl.combat;

import com.craftrise.client.M;
import com.craftrise.client.dg;
import com.craftrise.m9;
import com.craftrise.mg;
import com.craftrise.v;
import com.google.common.eventbus.Subscribe;
import cr.launcher.Config;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.MathHelper;
import org.lwjgl.input.Keyboard;
import today.makrit.Main;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.ModuleManager;
import today.makrit.module.impl.render.TargetHud;
import today.makrit.module.setting.BooleanSetting;
import today.makrit.module.setting.DoubleSetting;
import today.makrit.module.setting.ModeSetting;
import today.makrit.module.setting.NumberSetting;
import today.makrit.utils.MathUtils;
import cr.launcher.ResourceLocation;
import today.makrit.utils.Renderer.ColorUtil;
import today.makrit.utils.Renderer.FontUtil;
import today.makrit.utils.Renderer.RenderUtil;
import today.makrit.utils.Renderer.RoundedUtil;
import today.makrit.utils.RotationUtils;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import today.makrit.utils.mapper.TheWorld;
import org.lwjgl.opengl.GL11;
import today.net.minecraft.util.GLUtil;

import java.awt.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static net.minecraft.client.gui.Gui.drawRect;


public class KillAura extends Module {
    public KillAura() {
        super("Aura", ModuleCategory.COMBAT, Keyboard.KEY_R);
        this.settings.add(swing);
        this.settings.add(reach);
        this.settings.add(auto3rdPerson);
    }

    @Subscribe
    public void render(RenderEvent event) {
        List<mg> targets = TheWorld.playerEntities()
                .stream()
                .filter(this::isValidTarget)
                .filter(e -> getDistanceToEntity(e) < this.reach.getNumber() && e != Minecraft.GetPlayer())
                .sorted(Comparator.comparingDouble(this::getDistanceToEntity))
                .collect(Collectors.toList());
        for (mg target : targets) {
            String targetName = Minecraft.getEntityDisplayName(target);
            String cleanName = targetName.replaceAll("§[0-9a-fA-Fk-oK-OrRgG]", "");
            if (!targets.isEmpty()) {
                attacking = true;
            } else if (targets.isEmpty()) {
                attacking = false;
            }
            {
                if (Main.friends.contains(cleanName)) {
                    continue;
                } else {
                    attackTarget(targets);
                }
            }
        }
    }

    private void attackTarget(List<mg> targets) {
        try {
            for (mg target : targets) {
                if (Minecraft.getEntityHealth(target) != 1.0 && ModuleManager.isEnabled("AntiBot")) {
                    if (getDistanceToEntity(target) <= reach.getNumber()) {
                        if (auto3rdPerson.isToggled() && Config.gameSettings.a0 == 0) {
                            Config.gameSettings.a0 = 1;
                        }
                    }
                }
            }
            for (mg target : targets) {
            }
            if (timer.hasTimeElapsed((int) ((Math.random() * (850 / maxcps.getNumber())) + (850 / mincps.getNumber())), true)) {
                for (mg target : targets) {
                    if (Minecraft.getEntityHealth(target) != 1.0 && ModuleManager.isEnabled("AntiBot")) {
                        if (getDistanceToEntity(target) <= reach.getNumber()) {
                            if (c06look.isToggled()) {

                            }
                            attackTargetLogic(target);
                        }
                    }
                }
            }
        } catch (InvocationTargetException | NoSuchMethodException | IllegalAccessException e) {
        }
    }



    private void attackTargetLogic(mg target) throws InvocationTargetException, NoSuchMethodException, IllegalAccessException {
        if (swing.isToggled()) {
            Minecraft.sendSwing();
        } else {
            v swingPacket = new v();
            Minecraft.GetPlayer().z.a(swingPacket, 5555L);
        }
        Minecraft.addToSendQueue(Minecraft.C02EntityUseAttack((Object) target));
        this.targetHealth = Minecraft.getEntityHealth((Object) target);
        this.targetName = Minecraft.getEntityDisplayName(target);
        this.targetRange = getDistanceToEntity(target);
        targetForROT = target;
    }

    public static void renderPlayer2D(int x, int y, int width, int height, com.craftrise.client.f1 player) {
        GLUtil.startBlend();
        final cr.launcher.ResourceLocation skin = Minecraft.getLocationSkin2(player);
        net.minecraft.client.Minecraft.getMinecraft().getTextureManager().b(skin, 2L);
        Gui.drawScaledCustomSizeModalRect(x, y, (float) 8.0, (float) 8.0, 8, 8, width, height, 64.0F, 64.0F);
        GLUtil.endBlend();
    }

    public static float GetDistanceToEntity(m9 entity) {
        try {
            float f = (float)(Minecraft.GetPlayer().bE - entity.bE);
            float f2 = (float)(Minecraft.GetPlayer().aY - entity.aY);
            float f3 = (float)(Minecraft.GetPlayer().bH - entity.bH);
            float distanceSquared = f * f + f2 * f2 + f3 * f3;
            String className = "com.craftrise.pj";
            String methodName = "d";
            Class<?> clazz = Class.forName(className);
            Method method = clazz.getMethod(methodName, Float.TYPE);
            Object result = method.invoke(null, distanceSquared);
            return ((Number) result).floatValue();
        } catch (Exception exception) {
            Minecraft.addChatMessage("Distance error: " + exception.toString());
            return -1.0f;
        }
    }


    public static void drawImage(float x, float y, int width, int height) {
        ResourceLocation resourceLocation = new ResourceLocation("head.png");
        dg.a(resourceLocation, x, y, width, height, 1337);
    }

    private boolean isValidTarget(mg target) {
        String targetUsername = Minecraft.getEntityDisplayName(target);
        if (targetUsername.startsWith("§") && targetUsername.length() > 2) {
            char specialChar = targetUsername.charAt(2);
            return specialChar != 'r' && specialChar != '7';
        }
        return true;
    }

    private int getHealthBarColor(float targetHealth) {
        if (targetHealth > 15) {
            return new Color(9, 255, 0).getRGB();
        } else if (targetHealth > 10) {
            return new Color(255, 242, 0).getRGB();
        } else if (targetHealth > 5) {
            return new Color(255, 152, 0).getRGB();
        } else {
            return new Color(255, 0, 0).getRGB();
        }
    }

    private String getHeartSymbol(float targetHealth) {
        float roundedHealth = (float) (Math.round(this.targetHealth * 10.0) / 10.0);
        String formattedHealth = String.format("%.1f", roundedHealth);
        if (targetHealth > 15) {
            return "§a" + formattedHealth + "§c❤";
        } else if (targetHealth > 10) {
            return "§e" + formattedHealth + "§c❤";
        } else if (targetHealth > 5) {
            return "§6" + formattedHealth + "§c❤";
        } else {
            return "§c" + formattedHealth + "§c❤";
        }
    }

    @Override
    public void onDisable() {
        if (auto3rdPerson.isToggled() && Config.gameSettings.a0 == 1) {
            Config.gameSettings.a0 = 0;
        }
    }

    public float getDistanceToEntity(m9 m92) {
        try {
            double xDist = Minecraft.GetPlayer().bE - m92.bE;
            double yDist = Minecraft.GetPlayer().aY - m92.aY;
            double zDist = Minecraft.GetPlayer().bH - m92.bH;
            double distanceSq = xDist * xDist + yDist * yDist + zDist * zDist;
            return (float) Math.sqrt(distanceSq);
        } catch (Exception exception) {
            Minecraft.addChatMessage("Distance error: " + exception.toString());
            return -1.0f;
        }
    }


    public static float sqrt_double(double value) {
        return (float) Math.sqrt(value);
    }





    public static float getEyeHeigh(m9 entity) {
        float result = 0.0F;
        try {
            for (Method m : m9.class.getDeclaredMethods()) {
                if (m.getName().equals("e")) {
                    if (m.getParameterCount() == 1) {
                        if (m.getReturnType().toString().contains("float")) {
                            m.setAccessible(true);
                            result = (Float) m.invoke((Object) entity, Main.idk);
                        }
                    }
                }
            }
        } catch (Exception e) {
            Minecraft.addChatMessage(e.toString());
        }
        return result;
    }
    private Timer timer = new Timer();
    public static BooleanSetting c06look = new BooleanSetting("c06look", true);
    private NumberSetting maxcps = new NumberSetting("MaxCPS", 13, 1, 20);
    private NumberSetting mincps = new NumberSetting("MinCPS", 10, 1, 20);
    public static BooleanSetting autoblock = new BooleanSetting("AutoBlock", false);
    public static BooleanSetting auto3rdPerson = new BooleanSetting("Auto 3rd Person", false);
    public static BooleanSetting swing = new BooleanSetting("Swing", true);
    private DoubleSetting reach = new DoubleSetting("Range", 3.8f, 3.0f, 6.0f);
    private ModeSetting mode = new ModeSetting("TargetMode", "Single", "Single", "Multi");
    private String targetName;
    private float targetHealth;
    private float targetRange;
    public static m9 targetForROT = null;

    public static com.craftrise.mj target;
    public static boolean attacking;
}