package today.makrit.module.impl;

import today.makrit.module.ModuleManager;
import today.makrit.module.impl.combat.Velocityy;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import com.craftrise.client.S;
import com.craftrise.client.c9;
import cr.launcher.Config;
import cr.obfuscates.a;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class Packets extends ChannelInboundHandlerAdapter {
    private double sqrt;

    private Object getPrivateValue(Class cls, Object obj, String fieldName) {
        Object result = null;

        try {
            Field field = cls.getDeclaredField(fieldName);
            field.setAccessible(true);
            result = field.get(obj);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            Minecraft.addChatMessage(e.toString());
        }

        return result;
    }

    public static Object C06PacketPlayerLookSeks(double d, double d2, double d4, float f, float f2, boolean bl) {
        Object result = null;

        try {
            Class C02EntityUse = Class.forName("com/craftrise/lE$c");

            Class<?>[] paramTypes = {double.class, double.class, double.class,float.class,float.class,boolean.class};

            Constructor<?> constructor = C02EntityUse.getConstructor(paramTypes);

            Object instance = constructor.newInstance(d,d2, d4, f,f2,bl);

            result = instance;
        } catch (Exception e) {
            //addChatMessage(e.getMessage());
            Config.warn(e.getMessage());
        }

        return result;
    }

    @java.lang.Override
    public void channelRead(ChannelHandlerContext ctx, java.lang.Object packet) throws Exception {
        if(packet instanceof com.craftrise.iU && ModuleManager.isEnabled("Velocity"))
        {
            String sqrt = String.valueOf(Math.sqrt(ThePlayer.GetMotionX()*ThePlayer.GetMotionX() + ThePlayer.GetMotionY()*ThePlayer.GetMotionY() + ThePlayer.GetMotionZ()*ThePlayer.GetMotionZ()));
            if(Velocityy.velocitydebug.isToggled()){
                Minecraft.addChatMessage("Velocity: "+sqrt);
            }
            return;
        }
        if(packet instanceof com.craftrise.gy) {
            Minecraft.addChatMessage("");

            double x = (double) getPrivateValue(com.craftrise.gy.class, packet, "e");
            double y = (double) getPrivateValue(com.craftrise.gy.class, packet, "d");
            double z = (double) getPrivateValue(com.craftrise.gy.class, packet, "a");
            float yaw = (float) getPrivateValue(com.craftrise.gy.class, packet, "b");
            float pitch = (float) getPrivateValue(com.craftrise.gy.class, packet, "c");

            Minecraft.addChatMessage(x + " " + y + " " + z + " " + yaw + " " + pitch);

            Object c06 = C06PacketPlayerLookSeks(x, y, z, yaw, pitch, true);

            x -= ThePlayer.GetPosX();
            y -= ThePlayer.GetPosY();
            z -= ThePlayer.GetPosZ();

            double diff = Math.sqrt(x * x + y * y + z * z);

            if (diff <= 8) {
                Minecraft.addToSendQueue(c06);
                Minecraft.addChatMessage("");
                //return true;
            }
        }
        super.channelRead(ctx, packet);
    }
    public static void start()
    {
        Channel c = getChannel();

        if(c != getChannel()) {
            Object x = c.pipeline().get("packet_handler");
            getChannel().pipeline().addBefore("packet_handler" , "allah" , new Packets());
        }

        Object x = c.pipeline().get("packet_handler");
        c.pipeline().addBefore("packet_handler" , "allah" , new Packets());
    }
    public static Channel getChannel()
    {
        try {
            S minecraft = Config.getMinecraft();
            for (Method method : minecraft.getClass().getMethods()) {
                if(method.getParameterCount() == 0 && method.getReturnType() == com.craftrise.client.c9.class)
                {
                    c9 netHandler = (c9) method.invoke(minecraft);
                    for (Method method1 : c9.class.getMethods()) {
                        if(method1.getReturnType() == a.class)
                        {
                            a netMng = (a) method1.invoke(netHandler);
                            return netMng.p;
                        }
                    }
                }
            }
            return null;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Config.error(e.toString());
            System.exit(-1);
            return null;
        }
    }
}