package today.makrit.module.impl.misc;

import today.makrit.Main;
import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.BooleanSetting;
import today.makrit.module.setting.ModeSetting;
import today.makrit.module.setting.NumberSetting;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import today.makrit.utils.mapper.TheWorld;
import com.craftrise.mg;
import com.craftrise.qd;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class StaffDetector extends Module {
    private ModeSetting mode = new ModeSetting("Mode", "Disconnect", "Lobby");
    public static BooleanSetting bedwars = new BooleanSetting("BedTP", true);
    public static NumberSetting range = new NumberSetting("Range", 310, 2, 500);

    public StaffDetector() {
        super("StaffDetector", ModuleCategory.MISC, 0);
        settings.add(mode);
    }

    @Override
    public void onEnable() {
        Main.admins.add("SoyPatates");
        Main.admins.add("emiremrepro");
        Main.admins.add("Pattis");
        Main.admins.add("BerkKrkmz");
        Main.admins.add("ersy");
        Main.admins.add("Xquers");
        Main.admins.add("CraftRise");
        Main.admins.add("DarelSprings");
        Main.admins.add("BheeKa");
        Main.admins.add("Ferixinder");
        Main.admins.add("darknesse69");
    }

    public Timer timer = new Timer();

    @Subscribe
    public void onTick(RenderEvent re) {
        if (this.toggled) {
            List<mg> targets = TheWorld.playerEntities()
                    .stream()
                    .filter(e -> GetDistanceToEntity(e) < (bedwars.isToggled() ? 9999 : range.getNumber()) && e != Minecraft.GetPlayer())
                    .sorted(Comparator.comparingDouble(entity -> GetDistanceToEntity(entity)))
                    .collect(Collectors.toList());

            if (!targets.isEmpty()) {
                mg target = targets.get(0);
                String nameWithColors = Minecraft.getEntityDisplayName(target);
                String nameWithoutColors = nameWithColors.replaceAll("§[0-9a-fA-Fk-oK-OrRgG]", "");

                if (Main.admins.contains(nameWithoutColors)) {
                    if (Objects.equals(mode.getValue(), "Disconnect")) {
                        Minecraft.addChatMessage("§fStaff Detected " + nameWithoutColors);
                        Minecraft.addChatMessage("§fStaff Detected " + nameWithoutColors);
                        Minecraft.addChatMessage("§fStaff Detected " + nameWithoutColors);
                        Minecraft.addChatMessage("§fStaff Detected " + nameWithoutColors);
                        Minecraft.addChatMessage("§fStaff Detected " + nameWithoutColors);
                        qd C08PacketPlayerBlockPlacement = (new qd());
                        Minecraft.addToSendQueue(C08PacketPlayerBlockPlacement);
                        this.toggle();
                    }
                    if (Objects.equals(mode.getValue(), "Lobby")) {
                        Minecraft.addChatMessage("§fStaff Detected " + nameWithoutColors);
                        Minecraft.addChatMessage("§fStaff Detected " + nameWithoutColors);
                        Minecraft.addChatMessage("§fStaff Detected " + nameWithoutColors);
                        Minecraft.addChatMessage("§fStaff Detected " + nameWithoutColors);
                        Minecraft.addChatMessage("§fStaff Detected " + nameWithoutColors);
                        ThePlayer.sendMessage("/lobi");
                        this.toggle();
                    }
                }
            }
        }
    }

    public static float GetDistanceToEntity(mg entity) {
        try {
            float f = (float) (Minecraft.GetPlayer().bE - entity.bE);
            float f2 = (float) (Minecraft.GetPlayer().aY - entity.aY);
            float f3 = (float) (Minecraft.GetPlayer().bH - entity.bH);
            return (float) Math.sqrt(f * f + f2 * f2 + f3 * f3);
        } catch (Exception exception) {
            Minecraft.addChatMessage("Distance error: " + exception.toString());
            return -1.0f;
        }
    }
}