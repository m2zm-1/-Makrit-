package today.makrit.module.impl.combat;

import today.makrit.module.ModuleCategory;
import today.makrit.module.impl.SimpleModule;
import today.makrit.module.setting.BooleanSetting;
import today.makrit.utils.Helper.InventoryHelper;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import com.craftrise.b3;
import com.craftrise.gM;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Method;

import static today.makrit.utils.proutils.filterMethodFromReturnTypeAndParams;

public class AutoArmor extends SimpleModule {
    public static int[] helmetItems;
    public static int[] chestplateItems;
    public static int[] leggingsItems;
    public static int[] bootsItems;
    public byte currentSlot;
    public static BooleanSetting inventory = new BooleanSetting("Only Inventory", true);

    static {
        AutoArmor.helmetItems = new int[]{565, 310, 306, 302, 314, 298};
        AutoArmor.chestplateItems = new int[]{566, 311, 307, 303, 315, 299};
        AutoArmor.leggingsItems = new int[]{567, 312, 308, 304, 316, 300};
        AutoArmor.bootsItems = new int[]{568, 313, 309, 305, 317, 301};
    }

    public AutoArmor() {
        super("AutoArmor", ModuleCategory.COMBAT, 0, 0);
        settings.add(inventory);

    }
    @Override
    public void onEnable(){
        this.currentSlot = -1;
        super.onEnable();
    }

    public static String getStackTraceAsString(Exception exception) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        exception.printStackTrace(pw);
        return sw.toString();
    }

    @Override
    public void updateDelay() {
        if (isToggled()) {
            if(inventory.isToggled()) {
                if (Minecraft.getCurrentScreen() == null) {
                    if (currentSlot < 3) {
                        currentSlot++;
                    } else {
                        currentSlot = 0;
                    }
                    final com.craftrise.gM currentArmorSlot = InventoryHelper.getArmorInventorySlot(3 - currentSlot);
                    int currentItemID = 0;
                    if (currentArmorSlot != null) {
                        try {
                            Method getItem = filterMethodFromReturnTypeAndParams(b3.class, gM.class);

                            Method getItemId = filterMethodFromReturnTypeAndParams(int.class , b3.class , b3.class);

                            b3 item = (b3) getItem.invoke(currentArmorSlot);
                            int id = (int) getItemId.invoke(null, item);
                            currentItemID = id;
                        }catch (Exception e)
                        {
                            Minecraft.addChatMessage(getStackTraceAsString(e));
                        }
                    }
                    int[] targetItems;
                    if (currentSlot == 0) {
                        targetItems = AutoArmor.helmetItems;
                    } else if (currentSlot == 1) {
                        targetItems = AutoArmor.chestplateItems;
                    } else if (currentSlot == 2) {
                        targetItems = AutoArmor.leggingsItems;
                    } else {
                        targetItems = AutoArmor.bootsItems;
                    }
                    if (targetItems[0] != currentItemID || (currentArmorSlot != null && currentArmorSlot.h(31))) {
                        int targetIndex = -1;
                        int currentEnchantmentStatus = 0;
                        if (currentItemID > 0) {
                            currentEnchantmentStatus = (currentArmorSlot.h(31) ? 1 : 0);
                        }
                        int i;
                        for (i = 0; i < targetItems.length; i++) {
                            if (currentItemID == targetItems[i]) {
                                currentItemID = i;
                                break;
                            }
                        }
                        if (i == targetItems.length) {
                            currentItemID = 6;
                        }
                        for (int j = 0; j < 36; j++) {
                            final com.craftrise.gM mainInventorySlot = InventoryHelper.getMainInventorySlot(j);
                            int currentInventoryItemID = 0;
                            if (mainInventorySlot != null) {
                                try {
                                    Method getItem = filterMethodFromReturnTypeAndParams(b3.class, gM.class);
                                    Method getItemId = filterMethodFromReturnTypeAndParams(int.class , b3.class , b3.class);

                                    b3 item = (b3) getItem.invoke(mainInventorySlot);
                                    int id = (int) getItemId.invoke(null, item);
                                    currentInventoryItemID = id;
                                }catch (Exception e)
                                {
                                    Minecraft.addChatMessage(getStackTraceAsString(e));
                                }
                                int k = 0;
                                while (k < targetItems.length) {
                                    if (currentInventoryItemID == targetItems[k]) {
                                        final boolean currentInventoryItemEnchantmentStatus = mainInventorySlot.h(31);
                                        if (k < currentItemID || (k == currentItemID && currentInventoryItemEnchantmentStatus && currentEnchantmentStatus == 0)) {
                                            targetIndex = j;
                                            currentItemID = k;
                                            currentEnchantmentStatus = (currentInventoryItemEnchantmentStatus ? 1 : 0);
                                            break;
                                        }
                                        break;
                                    } else {
                                        k++;
                                    }
                                }
                                if (currentItemID == 0 && currentEnchantmentStatus != 0) {
                                    break;
                                }
                            }
                        }
                        if (targetIndex != -1) {
                            Minecraft.GetPlayerControllerMp().a(ThePlayer.getInventoryContainer().i, 5 + currentSlot, 0, 1, Minecraft.GetPlayer(), 90);
                            Minecraft.GetPlayerControllerMp().a(ThePlayer.getInventoryContainer().i, (targetIndex < 9) ? (targetIndex + 36) : targetIndex, 0, 1, Minecraft.GetPlayer(), 90);
                            super.updateDelay();
                        }
                    }
                }
            } else {
                if (Minecraft.getCurrentScreen() == null) {
                    if (currentSlot < 3) {
                        currentSlot++;
                    } else {
                        currentSlot = 0;
                    }
                    final com.craftrise.gM currentArmorSlot = InventoryHelper.getArmorInventorySlot(3 - currentSlot);
                    int currentItemID = 0;
                    if (currentArmorSlot != null) {
                        try {
                            Method getItem = filterMethodFromReturnTypeAndParams(b3.class, gM.class);

                            Method getItemId = filterMethodFromReturnTypeAndParams(int.class , b3.class , b3.class);

                            b3 item = (b3) getItem.invoke(currentArmorSlot);
                            int id = (int) getItemId.invoke(null, item);
                            currentItemID = id;
                        }catch (Exception e)
                        {
                            Minecraft.addChatMessage(getStackTraceAsString(e));
                        }
                    }
                    int[] targetItems;
                    if (currentSlot == 0) {
                        targetItems = AutoArmor.helmetItems;
                    } else if (currentSlot == 1) {
                        targetItems = AutoArmor.chestplateItems;
                    } else if (currentSlot == 2) {
                        targetItems = AutoArmor.leggingsItems;
                    } else {
                        targetItems = AutoArmor.bootsItems;
                    }
                    if (targetItems[0] != currentItemID || (currentArmorSlot != null && currentArmorSlot.h(31))) {
                        int targetIndex = -1;
                        int currentEnchantmentStatus = 0;
                        if (currentItemID > 0) {
                            currentEnchantmentStatus = (currentArmorSlot.h(31) ? 1 : 0);
                        }
                        int i;
                        for (i = 0; i < targetItems.length; i++) {
                            if (currentItemID == targetItems[i]) {
                                currentItemID = i;
                                break;
                            }
                        }
                        if (i == targetItems.length) {
                            currentItemID = 6;
                        }
                        for (int j = 0; j < 36; j++) {
                            final com.craftrise.gM mainInventorySlot = InventoryHelper.getMainInventorySlot(j);
                            int currentInventoryItemID = 0;
                            if (mainInventorySlot != null) {
                                try {
                                    Method getItem = filterMethodFromReturnTypeAndParams(b3.class, gM.class);
                                    Method getItemId = filterMethodFromReturnTypeAndParams(int.class , b3.class , b3.class);

                                    b3 item = (b3) getItem.invoke(mainInventorySlot);
                                    int id = (int) getItemId.invoke(null, item);
                                    currentInventoryItemID = id;
                                }catch (Exception e)
                                {
                                    Minecraft.addChatMessage(getStackTraceAsString(e));
                                }
                                int k = 0;
                                while (k < targetItems.length) {
                                    if (currentInventoryItemID == targetItems[k]) {
                                        final boolean currentInventoryItemEnchantmentStatus = mainInventorySlot.h(31);
                                        if (k < currentItemID || (k == currentItemID && currentInventoryItemEnchantmentStatus && currentEnchantmentStatus == 0)) {
                                            targetIndex = j;
                                            currentItemID = k;
                                            currentEnchantmentStatus = (currentInventoryItemEnchantmentStatus ? 1 : 0);
                                            break;
                                        }
                                        break;
                                    } else {
                                        k++;
                                    }
                                }
                                if (currentItemID == 0 && currentEnchantmentStatus != 0) {
                                    break;
                                }
                            }
                        }
                        if (targetIndex != -1) {
                            Minecraft.GetPlayerControllerMp().a(ThePlayer.getInventoryContainer().i, 5 + currentSlot, 0, 1, Minecraft.GetPlayer(), 90);
                            Minecraft.GetPlayerControllerMp().a(ThePlayer.getInventoryContainer().i, (targetIndex < 9) ? (targetIndex + 36) : targetIndex, 0, 1, Minecraft.GetPlayer(), 90);
                            super.updateDelay();
                        }
                    }
                }
            }
        }
    }
}
