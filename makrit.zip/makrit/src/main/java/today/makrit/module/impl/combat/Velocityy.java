package today.makrit.module.impl.combat;

import today.makrit.management.PacketSent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.impl.Packets;
import today.makrit.module.setting.BooleanSetting;

public class Velocityy extends Module {
    com.craftrise.m9 m9 = null;
    public static BooleanSetting velocitydebug = new BooleanSetting("Debug", false);

    public Velocityy() {
        super("Velocity", ModuleCategory.COMBAT, 0);
        this.settings.add(velocitydebug);
    }

    @Override
    public void onEnable() {
        Packets.start();
        Packets.getChannel().pipeline().addAfter("encoder", "packet_sent", new PacketSent());
    }
}
