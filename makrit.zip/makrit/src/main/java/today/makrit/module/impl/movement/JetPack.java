package today.makrit.module.impl.movement;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.DoubleSetting;
import today.makrit.module.setting.ModeSetting;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.ThePlayer;
import org.lwjgl.input.Keyboard;

import java.util.Objects;

public class JetPack extends Module {
    private ModeSetting mode = new ModeSetting("Mode", "Spoof", "Spoof");
    private DoubleSetting height = new DoubleSetting("Spoof Delay", 0.5f, 0.1f, 3.0f);

    public JetPack() {
        super("JetPack", ModuleCategory.MOVEMENT, 0);
        settings.add(mode);
        settings.add(height);
    }

    public Timer timer = new Timer();

    @Subscribe
    public void render(RenderEvent re) {
        if (timer.hasTimeElapsed(1000 / 50, true)) {
            if (Objects.equals(mode.getValue(), "Spoof")) {
                if (ThePlayer.isMoving()) {
                    if (Keyboard.isKeyDown(57)) {
                        ThePlayer.jump();
                        //ThePlayer.SetMotionY(height.getNumber());
                        //ThePlayer.setPosition_mid(ThePlayer.GetPosX(), ThePlayer.GetPosY() + 0.1, ThePlayer.GetPosZ());
                        //ThePlayer.setPosition_mid(ThePlayer.GetPosX(), ThePlayer.GetPosY() + -0.1, ThePlayer.GetPosZ());
                    }
                }
            }
        }
    }
}