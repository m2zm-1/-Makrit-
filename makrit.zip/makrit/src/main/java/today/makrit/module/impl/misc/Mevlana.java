package today.makrit.module.impl.misc;

import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.ModeSetting;
import today.makrit.module.setting.NumberSetting;
import today.makrit.utils.mapper.ThePlayer;

import java.util.Objects;

public class Mevlana extends Module {
    public static NumberSetting mevlanaSpeedSetting;
    private ModeSetting mode = new ModeSetting("Mode", "Jitter", "Jitter", "Spin");

    static {
        Mevlana.mevlanaSpeedSetting = new NumberSetting("Speed", 1, 0, 50);

    }

    public float yaw;

    public Mevlana() {
        super("Mevlana", ModuleCategory.MISC, 0);
        settings.add(mevlanaSpeedSetting);
        settings.add(mode);
    }

    @Override
    public void onEnable() {
        this.yaw = ThePlayer.GetrotationYaw();
        super.onEnable();
    }

    @Override
    public void onRender2DEvent() {
        if (this.isToggled()) {
            if (Objects.equals(mode.getValue(), "Spin")) {
                this.yaw += Mevlana.mevlanaSpeedSetting.getNumber();
                if (this.yaw >= 360.0f) {
                    this.yaw = 0.0f;
                }
                ThePlayer.rotationYawHead(this.yaw);
                ThePlayer.renderYawOffset(this.yaw);
            }
            if (Objects.equals(mode.getValue(), "Jitter")) {
                this.yaw += 55.0;
                if (this.yaw >= 195.0f) {
                    this.yaw = 0.0f;
                }
                ThePlayer.rotationYawHead(this.yaw);
                ThePlayer.renderYawOffset(this.yaw);
            }
        }
    }
}