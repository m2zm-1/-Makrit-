package today.makrit.module.impl.movement;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.ModeSetting;
import today.makrit.utils.Helper.InventoryHelper;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.ThePlayer;
import com.craftrise.dR;
import cr.launcher.main.a;
import org.lwjgl.input.Mouse;

public class NoSlow extends Module {
    private ModeSetting mode = new ModeSetting("Mode", "Rise", "Rise");
    public static int[] blackList = new int[]{267, 268, 272, 276, 283, 322, 364, 261};

    public NoSlow() {
        super("NoSlow", ModuleCategory.MOVEMENT, 0);
        settings.add(mode);
    }

    public Timer timer = new Timer();


    @Subscribe
    public void render(RenderEvent re) {
        int fcount = 0;
        if (timer.hasTimeElapsed(1000 / 50, true)) {
            if (this.toggled) {
                final int itemInInventory = InventoryHelper.findItemInInventory(blackList);
                final int currentItemSlot = InventoryHelper.getCurrentItemSlot();
                if (currentItemSlot == itemInInventory) {
                    if (ThePlayer.isMoving()) {
                        if (Mouse.isButtonDown(1)) {
                            if (!ThePlayer.isMoving()) return;
                            if (ThePlayer.onGround() && (fcount % 3 == 0)) {
                                setSpeed(0.245);
                            } else if (ThePlayer.onGround() && !(fcount % 3 == 0)) {
                                setSpeed(0.090);
                            }
                            fcount++;
                        }
                    }
                } else {
                }
            }
        }
    }

    public static void setSpeed(double moveSpeed, float yaw, double strafe, double forward) {
        if (forward != 0.0D) {
            if (strafe > 0.0D) {
                yaw += ((forward > 0.0D) ? -45 : 45);
            } else if (strafe < 0.0D) {
                yaw += ((forward > 0.0D) ? 45 : -45);
            }
            strafe = 0.0D;
            if (forward > 0.0D) {
                forward = 1.0D;
            } else if (forward < 0.0D) {
                forward = -1.0D;
            }
        }
        if (strafe > 0.0D) {
            strafe = 1.0D;
        } else if (strafe < 0.0D) {
            strafe = -1.0D;
        }
        double mx = Math.cos(Math.toRadians((yaw + 90.0F)));
        double mz = Math.sin(Math.toRadians((yaw + 90.0F)));
        a.q.bh = new dR(forward * moveSpeed * mx + strafe * moveSpeed * mz);
        a.q.bf = new dR(forward * moveSpeed * mz - strafe * moveSpeed * mx);
    }
    public static double getBaseMoveSpeed() {
        double baseSpeed = a.q.S.b(5L) * 2.873;
        return baseSpeed;
    }

    public static void setSpeed(double moveSpeed) {
        setSpeed(moveSpeed, a.q.bL, a.q.l.c.a(5L), a.q.l.b.a(5L));
    }
}