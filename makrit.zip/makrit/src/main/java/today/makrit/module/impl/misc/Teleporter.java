package today.makrit.module.impl.misc;

import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.ModuleManager;
import today.makrit.module.setting.BooleanSetting;
import today.makrit.module.setting.DoubleSetting;
import today.makrit.module.setting.NumberSetting;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import today.makrit.utils.mapper.TheWorld;
import com.craftrise.m9;
import com.craftrise.mg;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static today.makrit.utils.mapper.ThePlayer.setPositionAndRotation;

public class Teleporter extends Module {
    public Timer timer = new Timer();
    public static BooleanSetting look = new BooleanSetting("Look target", true);
    public static NumberSetting range = new NumberSetting("Range", 8, 2, 500);
    public static DoubleSetting radius = new DoubleSetting("Radius", -1.8, -10, 7.0);
    public static NumberSetting degree = new NumberSetting("Degree", 1, -180, 359);
    public static BooleanSetting mevlana = new BooleanSetting("Mevlana", false);
    public static BooleanSetting bedwars = new BooleanSetting("BedTP", false);


    public Teleporter() {
        super("Teleporter", ModuleCategory.MISC, 0);
        settings.add(mevlana);
        settings.add(look);
        settings.add(range);
        settings.add(radius);
        settings.add(degree);
    }
    @Override
    public void onRender2DEvent() {

        List<mg> targets = TheWorld.playerEntities();
        targets = targets.stream().filter(e -> GetDistanceToEntity(e) < (bedwars.isToggled() ? 110 : range.getNumber()) && e != Minecraft.GetPlayer()).collect(Collectors.toList());
        targets = new ArrayList<>(targets);
        targets.sort(Comparator.comparingDouble(entity -> GetDistanceToEntity(entity)));

        if (this.isToggled()) {
            for (int i = targets.size() - 1; i >= 0; i--) {
                mg target = targets.get(i);

                if (Minecraft.getEntityHealth(target) != 1.0 && ModuleManager.isEnabled("AntiBot")) {
                    ThePlayer.SetMotionX(0);
                    final double n = 360.0f - ThePlayer.GetrotationYaw(target) + degree.getNumber();
                    final double radians = Math.toRadians(n);
                    setPositionAndRotation(ThePlayer.GetPosX(target) + radius.getNumber() * Math.sin(radians),
                            ThePlayer.GetPosY(target),
                            ThePlayer.GetprevPosZ(target) + radius.getNumber() * Math.cos(radians),
                            look.isToggled() ? (float) (360.0f - n) : ThePlayer.GetrotationYaw(),
                            look.isToggled() ? 0.0f : ThePlayer.GetRotationPitch());

                    targets.remove(target);
                }
            }
        }

        if (this.isToggled() && bedwars.isToggled()) {
            for (mg target : targets) {
                if (Minecraft.getEntityHealth(target) != 1.0 && ModuleManager.isEnabled("AntiBot")) {
                    ExecutorService executorService = Executors.newSingleThreadExecutor();

                    executorService.submit(() -> {
                        try {
                            TimeUnit.SECONDS.sleep(3);
                            ThePlayer.SetMotionX(0);
                            final double n = 360.0f - ThePlayer.GetrotationYaw(target) + degree.getNumber();
                            final double radians = Math.toRadians(n);
                            setPositionAndRotation(ThePlayer.GetPosX(target) + radius.getNumber() * Math.sin(radians), ThePlayer.GetPosY(target), ThePlayer.GetprevPosZ(target) + radius.getNumber() * Math.cos(radians), look.isToggled() ? (float) (360.0f - n) : ThePlayer.GetrotationYaw(), look.isToggled() ? 0.0f : ThePlayer.GetRotationPitch());
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    });
                    executorService.shutdown();
                }
            }
        }

        if (this.isToggled() && !targets.isEmpty()) {
            for (mg target : targets) {
                if(Minecraft.getEntityHealth(target) != 1.0 && ModuleManager.isEnabled("AntiBot")) {
                    ThePlayer.SetMotionX(0);
                    final double n = 360.0f - ThePlayer.GetrotationYaw(target) + degree.getNumber();
                    final double radians = Math.toRadians(n);
                    setPositionAndRotation(ThePlayer.GetPosX(target) + radius.getNumber() * Math.sin(radians), ThePlayer.GetPosY(target), ThePlayer.GetprevPosZ(target) + radius.getNumber() * Math.cos(radians), look.isToggled() ? (float) (360.0f - n) : ThePlayer.GetrotationYaw(), look.isToggled() ? 0.0f : ThePlayer.GetRotationPitch());
                }
            }
        }
    }

    public static float GetDistanceToEntity(m9 m92) {
        try {
            float f = (float)(Minecraft.GetPlayer().bE - m92.bE);
            float f2 = (float)(Minecraft.GetPlayer().aY - m92.aY);
            float f3 = (float)(Minecraft.GetPlayer().bH - m92.bH);
            String string = "com.craftrise.pj";
            String string2 = "d";
            Class<?> clazz = Class.forName(string);
            Method method = clazz.getMethod(string2, Float.TYPE);
            Object object = method.invoke((Object)m92, Float.valueOf(f * f + f2 * f2 + f3 * f3));
            return ((Number) object).floatValue();
        } catch (Exception exception) {
            Minecraft.addChatMessage("Distance error: " + exception.toString());
            return -1.0f;
        }
    }
}
