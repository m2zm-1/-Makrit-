package today.makrit.module.impl.movement;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.NumberSetting;
import today.makrit.utils.mapper.ThePlayer;

public class Glide extends Module {
    private NumberSetting ticks = new NumberSetting("Ticks", 20, 1, 50);
    private int aac3glideDelay;
    public Glide() {
        super("Glide", ModuleCategory.MOVEMENT, 0);
        settings.add(ticks);
    }

    @Subscribe
    public void onRender(RenderEvent tick) {

        if (!ThePlayer.onGround()){
            aac3glideDelay++;
        }

        if (aac3glideDelay >= ticks.getNumber() && !ThePlayer.onGround()) {
            aac3glideDelay = 0;
            ThePlayer.SetMotionY(.015);
        }
    }
}
