package today.makrit.module.setting.interfaces;

public interface IRunnable {
    void onRun();
}
