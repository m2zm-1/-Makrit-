package today.makrit.module.impl.movement;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.utils.mapper.ThePlayer;
import org.lwjgl.input.Keyboard;

public class AirJump extends Module {
    private boolean isJumping;
    public AirJump() {
        super("AirJump", ModuleCategory.MOVEMENT, 0);
    }

    @Subscribe
    public void onTick(RenderEvent e) {
        if(Keyboard.isKeyDown(Keyboard.KEY_SPACE)) {
            if (this.isJumping == false) {
                if (this.isToggled() && !ThePlayer.onGround()) {
                    ThePlayer.jump();
                    this.isJumping = true;
                }
            }
        } else {
            this.isJumping = false;
        }
    }
}
