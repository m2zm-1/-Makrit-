package today.makrit.module.impl.movement;

import com.craftrise.client.fa;
import com.craftrise.dR;
import com.craftrise.lE;
import com.craftrise.m9;
import com.craftrise.mg;
import com.google.common.eventbus.Subscribe;
import cr.e;
import cr.launcher.BlockPos;
import cr.launcher.Config;
import cr.launcher.eb;
import cr.launcher.main.a;
import org.lwjgl.input.Keyboard;
import today.makrit.event.impl.EventListener;
import today.makrit.event.impl.PacketSentEvent;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.DoubleSetting;
import today.makrit.module.setting.ModeSetting;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;

public class Fly extends Module {
    private ModeSetting mode = new ModeSetting("Mode", "Motion", "Motion", "Vanilla");
    private DoubleSetting speed = new DoubleSetting("Speed", 0.1f, 0.1f, 7.0f);
    private DoubleSetting aac3MotionY = new DoubleSetting("AAC3 MotionY", 5.0f, 0.1f, 5.0f);
    public Fly() {
        super("Fly", ModuleCategory.MOVEMENT, Keyboard.KEY_F);
        settings.add(mode);
        settings.add(speed);
    }
    public Timer timer = new Timer();

    @Subscribe
    public void render(RenderEvent re) {
        if (timer.hasTimeElapsed(1000 / 50, true)) {
            if (ThePlayer.isMoving()) {
            } else {
                setSpeed(0);
                ThePlayer.SetMotionX(0.0f);
                ThePlayer.SetMotionZ(0.0f);
            }
            if (Objects.equals(mode.getValue(), "Motion")) {
                ThePlayer.SetMotionY(-0.06);
                if (Keyboard.isKeyDown(42)) {
                    ThePlayer.SetMotionY(-0.5);
                }
                if (Keyboard.isKeyDown(57)) {
                    ThePlayer.SetMotionY(0.5);
                }
            } else if (Objects.equals(mode.getValue(), "Vanilla")) {
                ThePlayer.SetMotionY(-0.06);
                if (Keyboard.isKeyDown(42)) {
                    ThePlayer.SetMotionY(-0.5);
                }
                if (Keyboard.isKeyDown(57)) {
                    ThePlayer.SetMotionY(0.5);
                }
                if (Keyboard.isKeyDown(Keyboard.KEY_W)) {
                    float yaw = ThePlayer.GetrotationYaw();

                    double speed = 0.6;
                    double motionX = -Math.sin(Math.toRadians(yaw)) * speed;
                    double motionZ = Math.cos(Math.toRadians(yaw)) * speed;

                    ThePlayer.SetMotionX(motionX);
                    ThePlayer.SetMotionZ(motionZ);
                }

                if (Keyboard.isKeyDown(Keyboard.KEY_S)) {
                    float yaw = ThePlayer.GetrotationYaw() + 180;  // Geri hareket için 180 derece ekliyoruz

                    double speed = 0.6;
                    double motionX = -Math.sin(Math.toRadians(yaw)) * speed;
                    double motionZ = Math.cos(Math.toRadians(yaw)) * speed;

                    ThePlayer.SetMotionX(motionX);
                    ThePlayer.SetMotionZ(motionZ);
                }

                if (Keyboard.isKeyDown(Keyboard.KEY_A)) {
                    float yaw = ThePlayer.GetrotationYaw() - 90;  // Sol için 90 derece çıkarıyoruz

                    double speed = 0.6;
                    double motionX = -Math.sin(Math.toRadians(yaw)) * speed;
                    double motionZ = Math.cos(Math.toRadians(yaw)) * speed;

                    ThePlayer.SetMotionX(motionX);
                    ThePlayer.SetMotionZ(motionZ);
                }

                if (Keyboard.isKeyDown(Keyboard.KEY_D)) {
                    float yaw = ThePlayer.GetrotationYaw() + 90;  // Sağ için 90 derece ekliyoruz

                    double speed = 0.6;
                    double motionX = -Math.sin(Math.toRadians(yaw)) * speed;
                    double motionZ = Math.cos(Math.toRadians(yaw)) * speed;

                    ThePlayer.SetMotionX(motionX);
                    ThePlayer.SetMotionZ(motionZ);
                }


            } else if (Objects.equals(mode.getValue(), "Ground")) {
                a.q.aT = new dR(0);
                a.q.s = new eb(true, cr.launcher.main.a.m);
            } else if (Objects.equals(mode.getValue(), "AirWalk")) {
                ThePlayer.SetMotionY(0);
            } else if (Objects.equals(mode.getValue(), "AAC Boost")) {
                if (ThePlayer.GethurtResistantTime() > 1) {
                    SetisFlying(true);
                    SetflySpeed((float) speed.getNumber());
                    double posx = ThePlayer.GetPosX();
                    double posy = ThePlayer.GetPosY();
                    double posz = ThePlayer.GetPosZ();
                    float rotationyaw = ThePlayer.GetrotationYaw();
                    float rotationpitch = ThePlayer.GetRotationPitch();
                    double radians = degreesToRadians(rotationyaw * -1.0f);
                    double radians2 = degreesToRadians(rotationpitch * -1.0f);
                    ThePlayer.setPosition_mid(posx + Math.sin(radians) * Math.cos(radians2) * 0.1,
                            posy + Math.sin(radians2) * 0.1,
                            posz + Math.cos(radians) * Math.cos(radians2) * 0.1);
                }
            } else if (Objects.equals(mode.getValue(), "AAC3")) {

                final double currentPosY = (ThePlayer.GetPosY() == (int) ThePlayer.GetPosY()) ? (ThePlayer.GetPosY() - 1.0) : ThePlayer.GetPosY();
                if (ThePlayer.onGround()) {
                    if (Minecraft.getBlockID(new BlockPos(ThePlayer.GetPosX(), currentPosY, ThePlayer.GetprevPosZ())) != 0) {
                        lastPosX = ThePlayer.GetPosX();
                        lastPosZ = ThePlayer.GetPosY();
                        lastPosY = ThePlayer.GetprevPosZ();
                    }
                } else if (!ThePlayer.isMoving() && lastPosZ - ThePlayer.GetPosY() > aac3MotionY.getNumber()) {
                    boolean lagBackTriggered = false;
                    BlockPos blockPos;
                    int distanceFromBlockY;
                    for (distanceFromBlockY = 0; distanceFromBlockY <= 65; ++distanceFromBlockY) {
                        BlockPos blockPos1 = new BlockPos((int) ThePlayer.GetPosX(), (int) (ThePlayer.GetPosY() - distanceFromBlockY), (int) ThePlayer.GetPosZ());
                        int blockID = Minecraft.getBlockID(blockPos1);

                        if (blockID == 0) {
                            lagBackTriggered = true;
                        } else {
                        }
                    }

                    if (lagBackTriggered) {
                        ThePlayer.SetMotionY(aac3MotionY.getNumber());
                    }
                }
            }
        }
    }
    public double lastPosX;
    public double lastPosY;
    public double lastPosZ;

    private final EventListener<PacketSentEvent> onPacketSend = e -> {
        if (e.getPacket() instanceof lE) {
            if (cr.launcher.main.a.q.Z % 1 == 0) {
                e.cancel();
            }
        }
    };

    @Override
    public void onDisable() {
        SetisFlying(false);
        ThePlayer.SetMotionX(0);
        ThePlayer.SetMotionZ(0);
        ThePlayer.SetMotionY(0);
        super.onDisable();
    }

    private double posX,posY,posZ;
    int mmcstate;
    public float FallDistance() {
        try {
            Class<m9> clazz = m9.class;
            Field field = clazz.getDeclaredField("c");
            field.setAccessible(true);
            fa fa2 = Minecraft.GetPlayer();
            float f = field.getFloat(fa2);
            return f;
        } catch (IllegalAccessException | NoSuchFieldException reflectiveOperationException) {
            reflectiveOperationException.printStackTrace();
            return -1.0f;
        }
    }
    public static void SetflySpeed(float value){
        try {
            Class<?> thePlayerClass = com.craftrise.mg.class;
            Field sField = thePlayerClass.getDeclaredField("S");
            sField.setAccessible(true);
            Object sObject = sField.get(a.q);
            Field hField = sObject.getClass().getDeclaredField("c");
            hField.setAccessible(true);
            hField.set(sObject, new com.craftrise.de(value));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    float degreesToRadians(float degrees) {
        return degrees * (3.14159265358979323846f / 180.0f);
    }
    public static cr.g getgField() {
        try {
            Field hField = Config.getMinecraft().cl.getClass().getDeclaredField("d");
            hField.setAccessible(true);
            return (cr.g)hField.get(Config.getMinecraft().cl);
        }catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void setTimerSpeed(float value){
        try {
            Field hField = Config.getMinecraft().cl.getClass().getDeclaredField("a");
            hField.setAccessible(true);
            hField.set(Config.getMinecraft().cl, new e(value,getgField().a()));
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }
    public static void SetPosition(double x, double y, double z){
        try{
            Class<?> Entity = com.craftrise.m9.class;
            Method setPosition = Entity.getMethod("b",double.class,double.class,double.class,long.class);
            setPosition.invoke(a.q,x,y,z,5L);
        }
        catch (Exception e){
            e.printStackTrace();
        }

    }
    public static void SetisFlying(boolean value) {
        try {
            Class<?> thePlayerClass = com.craftrise.mg.class;
            Field sField = thePlayerClass.getDeclaredField("S");
            sField.setAccessible(true);
            Object sObject = sField.get(a.q);
            Field hField = sObject.getClass().getDeclaredField("h");
            hField.setAccessible(true);
            hField.set(sObject, new eb(value, cr.launcher.main.a.m));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void SetAllowFlying(boolean value) {
        try {
            Class<?> thePlayerClass = com.craftrise.mg.class;
            Field sField = thePlayerClass.getDeclaredField("S");
            sField.setAccessible(true);
            Object sObject = sField.get(Minecraft.GetPlayer());
            Field hField = sObject.getClass().getDeclaredField("k");
            hField.setAccessible(true);
            hField.set(sObject, new eb(value, cr.launcher.main.a.m));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static boolean isMoving(mg player) {
        return player.aZ.a(5L) != 0F || player.cm.a(5L) != 0F;
    }

    public static boolean isFalseFlaggable(mg player) {
        return player.z(5L) || player.Z < 10;
    }

    public static void setSpeed(double moveSpeed, float yaw, double strafe, double forward) {
        if (forward != 0.0D) {
            if (strafe > 0.0D) {
                yaw += ((forward > 0.0D) ? -45 : 45);
            } else if (strafe < 0.0D) {
                yaw += ((forward > 0.0D) ? 45 : -45);
            }
            strafe = 0.0D;
            if (forward > 0.0D) {
                forward = 1.0D;
            } else if (forward < 0.0D) {
                forward = -1.0D;
            }
        }
        if (strafe > 0.0D) {
            strafe = 1.0D;
        } else if (strafe < 0.0D) {
            strafe = -1.0D;
        }
        double mx = Math.cos(Math.toRadians((yaw + 90.0F)));
        double mz = Math.sin(Math.toRadians((yaw + 90.0F)));
        a.q.bh = new dR(forward * moveSpeed * mx + strafe * moveSpeed * mz);
        a.q.bf = new dR(forward * moveSpeed * mz - strafe * moveSpeed * mx);
    }
    public static double getBaseMoveSpeed() {
        double baseSpeed = a.q.S.b(5L) * 2.873;
        return baseSpeed;
    }

    public static void setSpeed(double moveSpeed) {
        setSpeed(moveSpeed, a.q.bL, a.q.l.c.a(5L), a.q.l.b.a(5L));
    }

}