package today.makrit.module.impl.render;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.utils.MathUtils;
import today.makrit.utils.Renderer.FontUtil;
import today.makrit.utils.Renderer.RenderUtil;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.Arrays;
import java.util.List;

import static today.net.minecraft.client.gui.Gui.drawRect;

public class Statistics extends Module {
    public Statistics() {
        super("Statistics", ModuleCategory.RENDER, 0);
    }

    private final List<String> linesLeft = Arrays.asList("Play time", "Games played", "Kills");

    @Subscribe
    public void onRender(RenderEvent e) {
        int x = 90;  // X koordinatı
        int y = 10;  // Y koordinatı (aşağı alındı)
        int boxWidth = 150;
        int boxHeight = 100;
        int borderRadius = 8;

        drawStatisticsBox(x, y, boxWidth, boxHeight, borderRadius);
    }


    private void drawStatisticsBox(int x, int y, int boxWidth, int boxHeight, int borderRadius) {
        float var9 = (float)(MathUtils.square(ThePlayer.GetMotionX()) + MathUtils.square(ThePlayer.GetMotionZ()));
        float bps = (float)MathUtils.round(Math.sqrt((double)var9) * 20.0D * (double) 1.0f, 2.0D);
        String formattedBps = String.format("%.2f", bps);
        int[] playTime = getPlayTime();
        String playTimeString = formatPlayTime(playTime);
        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glEnable(GL11.GL_POLYGON_SMOOTH);

        int boxColor = new Color(0, 0, 0, 144).getRGB();
        RenderUtil.drawRoundedRect(x, y, boxWidth, boxHeight, borderRadius, boxColor);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glDisable(GL11.GL_POLYGON_SMOOTH);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();

        FontUtil.tenacityBoldFont18.drawStringWithShadow("Statistics", x + boxWidth / 2 - FontUtil.tenacityFont18.getStringWidth("Statistics") / 2, y + 5, Color.WHITE.getRGB());

        int underlineY = y + 5 + FontUtil.tenacityFont18.getHeight(); // Adjust the y-coordinate for the underline
        drawRect(x + 5, underlineY, x + boxWidth - 5, underlineY, Color.WHITE.getRGB());

        FontUtil.tenacityFont18.drawStringWithShadow("Time Played: " + playTimeString, x + 5, y + 20, Color.WHITE.getRGB());
        FontUtil.tenacityFont18.drawStringWithShadow("BPS: " + formattedBps, x + 5, y + 30, Color.WHITE.getRGB());
        FontUtil.tenacityFont18.drawStringWithShadow("FPS: " + Minecraft.getDebugFPS(), x + 5, y + 40, Color.WHITE.getRGB());
    }

    private String formatPlayTime(int[] playTime) {
        int hours = playTime[0];
        int minutes = playTime[1];
        int seconds = playTime[2];

        if (hours > 0) {
            return String.format("%02dh %02dm %02ds", hours, minutes, seconds);
        } else if (minutes > 0) {
            return String.format("%02dm %02ds", minutes, seconds);
        } else {
            return String.format("%02ds", seconds);
        }
    }

    public static int gamesPlayed, killCount;
    public static long startTime = System.currentTimeMillis(), endTime = -1;

    public static int[] getPlayTime() {
        long diff = getTimeDiff();
        long diffSeconds = 0, diffMinutes = 0, diffHours = 0;
        if (diff > 0) {
            diffSeconds = diff / 1000 % 60;
            diffMinutes = diff / (60 * 1000) % 60;
            diffHours = diff / (60 * 60 * 1000) % 24;
        }
        return new int[]{(int) diffHours, (int) diffMinutes, (int) diffSeconds};
    }

    public static long getTimeDiff() {
        return (endTime == -1 ? System.currentTimeMillis() : endTime) - startTime;
    }

    public static void reset() {
        startTime = System.currentTimeMillis();
        endTime = -1;
        gamesPlayed = 0;
        killCount = 0;
    }
}
