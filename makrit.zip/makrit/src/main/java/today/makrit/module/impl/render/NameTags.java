package today.makrit.module.impl.render;


import com.craftrise.mj;
import cr.launcher.Config;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.ModeSetting;
import today.makrit.utils.Renderer.ColorCreator;
import today.makrit.utils.Renderer.FontUtil;
import today.makrit.utils.Renderer.GLAllocation;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import today.makrit.utils.mapper.TheWorld;
import today.net.minecraft.client.gui.ScaledResolution;
import today.net.minecraft.client.renderer.GlStateManager;

import java.awt.*;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.List;
import java.util.*;

public class NameTags extends Module {
    private ModeSetting mode = new ModeSetting("Mode", "Rise", "Rise", "Tenacity");
    private final FloatBuffer modelView = GLAllocation.createDirectFloatBuffer(16);
    private final FloatBuffer projection = GLAllocation.createDirectFloatBuffer(16);
    private final IntBuffer viewport = GLAllocation.createDirectIntBuffer(16);
    private final FloatBuffer screenCords = GLAllocation.createDirectFloatBuffer(3);
    private final double[][] currentEntityPoints = new double[8][3];
    public NameTags() {
        super("NameTags", ModuleCategory.RENDER, 0);
        settings.add(mode);
    }
    public static ThePlayer.AxisAlignedBB getEntityBoundingBox(mj ent) {
        float f = 0.3f;
        float f1 = 1.8f;//mappig
        return new ThePlayer.AxisAlignedBB(ThePlayer.GetPosX(ent) - (double) f, ThePlayer.GetPosY(ent),ThePlayer.GetPosZ(ent) - (double) f, ThePlayer.GetPosX(ent) + (double) f,
                ThePlayer.GetPosY(ent) + (double) f1, ThePlayer.GetPosZ(ent) + (double) f);
    }
    private final Map<mj, float[]> entityPosMap = new HashMap<>();//EntityLivingBase maping ney

    @Override
    public void onRender2DEvent(float partialTicks) {
        if (this.isToggled()) {
            ScaledResolution res = new ScaledResolution(today.net.minecraft.client.Minecraft.getMinecraft());
            GlStateManager.pushMatrix();
            entityLoop:
            for (mj entity : collectEntities()) {
                Config.getMinecraft().aI.b(partialTicks, 0, 0);

                ThePlayer.AxisAlignedBB boundingBox = getEntityBoundingBox(entity).expand(0.05f, 0.05f, 0.05f).offset(0, 0.05, 0);
                currentEntityPoints[0] = project2D(
                        boundingBox.minX - Minecraft.getRenderManager().j,
                        boundingBox.minY - Minecraft.getRenderManager().t,
                        boundingBox.minZ - Minecraft.getRenderManager().c);
                currentEntityPoints[1] = project2D(
                        boundingBox.minX - Minecraft.getRenderManager().j,
                        boundingBox.minY - Minecraft.getRenderManager().t,
                        boundingBox.maxZ - Minecraft.getRenderManager().c);
                currentEntityPoints[2] = project2D(
                        boundingBox.maxX - Minecraft.getRenderManager().j,
                        boundingBox.minY - Minecraft.getRenderManager().t,
                        boundingBox.minZ - Minecraft.getRenderManager().c);
                currentEntityPoints[3] = project2D(
                        boundingBox.maxX - Minecraft.getRenderManager().j,
                        boundingBox.minY - Minecraft.getRenderManager().t,
                        boundingBox.maxZ - Minecraft.getRenderManager().c);
                currentEntityPoints[4] = project2D(
                        boundingBox.minX - Minecraft.getRenderManager().j,
                        boundingBox.maxY - Minecraft.getRenderManager().t,
                        boundingBox.minZ - Minecraft.getRenderManager().c);
                currentEntityPoints[5] = project2D(
                        boundingBox.minX - Minecraft.getRenderManager().j,
                        boundingBox.maxY - Minecraft.getRenderManager().t,
                        boundingBox.maxZ - Minecraft.getRenderManager().c);
                currentEntityPoints[6] = project2D(
                        boundingBox.maxX - Minecraft.getRenderManager().j,
                        boundingBox.maxY - Minecraft.getRenderManager().t,
                        boundingBox.minZ - Minecraft.getRenderManager().c);
                currentEntityPoints[7] = project2D(
                        boundingBox.maxX - Minecraft.getRenderManager().j,
                        boundingBox.maxY - Minecraft.getRenderManager().t,
                        boundingBox.maxZ - Minecraft.getRenderManager().c);

                double renderPosX1 = Double.MAX_VALUE;
                double renderPosY1 = Double.MAX_VALUE;
                double renderPosX2 = -1;
                double renderPosY2 = -1;

                for (double[] point : currentEntityPoints) {
                    if (point == null)
                        continue entityLoop;

                    if (point[2] < 0.0f || point[2] > 1.0f)
                        continue entityLoop;

                    point[1] = ((double) Display.getHeight() / 2 - point[1]);

                    if (point[0] < renderPosX1)
                        renderPosX1 = point[0];

                    if (point[0] > renderPosX2)
                        renderPosX2 = point[0];

                    if (point[1] < renderPosY1)
                        renderPosY1 = point[1];

                    if (point[1] > renderPosY2)
                        renderPosY2 = point[1];
                }

                int guiScale = Config.getGameSettings().z;
                Config.getGameSettings().z = 2;
                Config.getMinecraft().aI.j();
                Config.getGameSettings().z = guiScale;
                {
                    if (Objects.equals(mode.getValue(), "Rise")) {
                        String name = Minecraft.getEntityDisplayName(entity);
                        String cleanName = name.replaceAll("§7", "");
                        float targetHealth = Minecraft.getEntityHealth(entity);
                        int centerX = (int) ((renderPosX1 + renderPosX2) / 2);
                        int centerY = (int) ((renderPosY1 + renderPosY2) / 2);
                        centerY -= 30;
                        double hpPercentage = Minecraft.getEntityHealth(entity) / 20;
                        if (hpPercentage > 1)
                            hpPercentage = 1;
                        else if (hpPercentage < 0)
                            hpPercentage = 0;
                        int r = (int) (230 + (50 - 230) * hpPercentage);
                        int g = (int) (50 + (230 - 50) * hpPercentage);
                        int b = 50;
                        Hud.drawSmoothRectWithGlow(centerX, centerY, 50, 50,10, Color.YELLOW, 5);
                        FontUtil.arialbd.drawCenteredStringWithShadow(cleanName, centerX, centerY, new Color(255, 255, 255, 255).getRGB());
                        String halalhp = String.format("%.0f", targetHealth);
                        FontUtil.arialbd.drawCenteredStringWithShadow(halalhp, centerX, centerY + 8, ColorCreator.create(r, g, b, 255));
                    } else if (Objects.equals(mode.getValue(), "Tenacity")) {
                        String name = Minecraft.getEntityDisplayName(entity);
                        String cleanName = name.replaceAll("§7", "");
                        float targetHealth = Minecraft.getEntityHealth(entity);
                        int centerX = (int) ((renderPosX1 + renderPosX2) / 2);
                        int centerY = (int) ((renderPosY1 + renderPosY2) / 2);
                        centerY -= 30;
                        double hpPercentage = Minecraft.getEntityHealth(entity) / 20;
                        if (hpPercentage > 1)
                            hpPercentage = 1;
                        else if (hpPercentage < 0)
                            hpPercentage = 0;
                        int r = (int) (230 + (50 - 230) * hpPercentage);
                        int g = (int) (50 + (230 - 50) * hpPercentage);
                        int b = 50;
                        FontUtil.tenacityBoldFont22.drawString(cleanName, centerX, centerY, new Color(255, 255, 255, 255).getRGB());
                        String halalhp = String.format("%.0f", targetHealth);
                        FontUtil.tenacityBoldFont22.drawString(halalhp, centerX, centerY + 8, ColorCreator.create(r, g, b, 255));
                    }
                }
            }
        }
        GlStateManager.popMatrix();
        GlStateManager.enableBlend();
        Config.getMinecraft().aI.j();
    }

    private boolean isValidEntity(mj entity) {
        if (entity == Minecraft.GetPlayer())
            return false;


        boolean npcCheck = true;

        if (entity != null) {
            if (Minecraft.getEntityHealth(entity) == 1.0) {
                npcCheck = false;
            }
            if (Minecraft.getEntityDisplayName(entity).contains("[CR]")) {
                npcCheck = false;
            }
        }


        return npcCheck;
    }

    public List<mj> collectEntities() {
        List<mj> validEntities = new ArrayList<>();
        for (mj entity : TheWorld.playerEntities()) {
            if (entity != null && isValidEntity(entity)) {
                validEntities.add(entity);
            }
        }
        return validEntities;
    }
    private double[] project2D(double posX, double posY, double posZ) {
        modelView.clear();
        projection.clear();
        viewport.clear();
        screenCords.clear();

        GL11.glGetFloat(2982, modelView);
        GL11.glGetFloat(2983, projection);
        GL11.glGetInteger(2978, viewport);

        if (GLU.gluProject((float) posX, (float) posY, (float) posZ, modelView, projection, viewport, screenCords)) {
            return new double[]{screenCords.get(0) / 2.0f, screenCords.get(1) / 2.0f, screenCords.get(2)};
        }

        return null;
    }
}
