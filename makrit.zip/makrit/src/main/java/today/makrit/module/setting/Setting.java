package today.makrit.module.setting;

public class Setting {
   public String name;
   private boolean listening;

   public Setting(String name) {
      this.name = name;
   }

    public Setting() {
    }

    public boolean isListening() {
      return this.listening;
   }

   public void setListening(boolean listening) {
      this.listening = listening;
   }

   public String getName() {
      return this.name;
   }
}
