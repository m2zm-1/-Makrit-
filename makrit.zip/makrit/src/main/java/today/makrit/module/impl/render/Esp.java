package today.makrit.module.impl.render;

import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.BooleanSetting;
import today.makrit.module.setting.DoubleSetting;
import today.makrit.utils.Helper.RenderHelper;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import today.makrit.utils.mapper.TheWorld;
import com.craftrise.mg;

import java.awt.*;
import java.util.List;

public class Esp extends Module {
    private String targetName;
    private DoubleSetting width = new DoubleSetting("Width", 0.7f, 0.1f, 6.0f);
    private DoubleSetting height = new DoubleSetting("Height", 1.83f, 0.1f, 4.0f);
    private DoubleSetting depth = new DoubleSetting("Depth", 0.7f, 0.1f, 6.0f);
    private DoubleSetting thickness = new DoubleSetting("Thickness", 2.0f, 0.1f, 6.0f);
    public static BooleanSetting rainbow = new BooleanSetting("Rainbow", false);

    public Esp() {
        super("Esp", ModuleCategory.RENDER, 0);
        settings.add(width);
        settings.add(height);
        settings.add(depth);
        //settings.add(thickness);
        settings.add(rainbow);
    }

    private static int getRainbowColor(int speed, int offset) {
        float hue = (System.currentTimeMillis() + offset) % speed;
        return Color.getHSBColor(hue / speed, 0.9f, 1.0f).getRGB();
    }

    private void renderEntityBoundingBox(mg entity) {
        if (entity != null && entity != Minecraft.GetPlayer()) {
            double width = this.width.getNumber();
            double height = this.height.getNumber();
            double depth = this.depth.getNumber();

            double posX = ThePlayer.GetPosX(entity);
            double posY = ThePlayer.GetPosY(entity);
            double posZ = ThePlayer.GetPosZ(entity);

            int rainbowColor = getRainbowColor(-2000, 15);

            this.targetName = Minecraft.getEntityDisplayName(entity);

            if (!this.targetName.contains("[CR]") && Minecraft.getEntityHealth(entity) != 1.0) {
                if (rainbow.isToggled()) {
                    RenderHelper.drawOutlinedBoundingBox(posX - width / thickness.getNumber(), posY, posZ - depth / thickness.getNumber(), width, height, depth, rainbowColor);
                } else {
                    RenderHelper.drawOutlinedBoundingBox(posX - width / thickness.getNumber(), posY, posZ - depth / thickness.getNumber(), width, height, depth, new Color(255, 255, 255, 255).getRGB());
                }
            }
        }
    }

    @Override
    public void onRender3DEvent(float partialTicks) {
        if (this.isToggled()) {
            List<mg> entityList = TheWorld.playerEntities();

            for (mg entity : entityList) {
                renderEntityBoundingBox(entity);
            }
        }
    }
    public String getHelp() {
        return "Draw players through walls.";
    }
}
