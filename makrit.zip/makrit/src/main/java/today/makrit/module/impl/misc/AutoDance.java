package today.makrit.module.impl.misc;

import cr.client.packets.PacketServerEmote;
import today.makrit.module.ModuleCategory;
import today.makrit.module.impl.SimpleModule;
import today.makrit.utils.Timer;

public class AutoDance extends SimpleModule {

    public AutoDance() {
        super("AutoDance", ModuleCategory.MISC, 0, 0);
    }

    public Timer timer = new Timer();

    @Override
    public void updateDelay() {
        if (this.toggled) {
            final PacketServerEmote packetServerEmote = new PacketServerEmote();
            packetServerEmote.setName("Squat");
            packetServerEmote.setState(PacketServerEmote.EmoteState.START);
            packetServerEmote.send();
            super.updateDelay();
        }
    }
}