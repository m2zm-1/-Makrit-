package today.makrit.module.impl.player;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.ModeSetting;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import com.craftrise.client.fa;
import com.craftrise.lE;
import com.craftrise.m9;

import java.lang.reflect.Field;
import java.util.Objects;

public class NoFall extends Module {
    private ModeSetting mode = new ModeSetting("Mode", "Packet", "Collide", "Ground");

    public NoFall() {
        super("NoFall", ModuleCategory.PLAYER, 0);
        this.settings.add(mode);
    }

    public float FallDistance() {
        try {
            Class<m9> clazz = m9.class;
            Field field = clazz.getDeclaredField("c");
            field.setAccessible(true);
            fa fa2 = Minecraft.GetPlayer();
            float f = field.getFloat(fa2);
            return f;
        } catch (IllegalAccessException | NoSuchFieldException reflectiveOperationException) {
            reflectiveOperationException.printStackTrace();
            return -1.0f;
        }
    }
    @Subscribe
    public void onTick(RenderEvent e) {
        if (Objects.equals(mode.getValue(), "Packet")) {
            if (FallDistance() > 3.0f) {
                lE lE2 = new lE(true);
                Minecraft.GetPlayer().z.a(lE2, 5L);
            }
        }
        if (Objects.equals(mode.getValue(), "Collide")) {
            if (FallDistance() > 3.0f) {
                ThePlayer.SetMotionY(0);
                resetFallDistance();
            }
        }
        if (Objects.equals(mode.getValue(), "Ground")) {
            if (FallDistance() > 2f) {

            }
        }
    }


    private void resetFallDistance() {
        try {
            Class<m9> clazz = m9.class;
            Field field = clazz.getDeclaredField("c");
            field.setAccessible(true);
            fa fa2 = Minecraft.GetPlayer();
            field.setFloat(fa2, 0.0f);
        } catch (IllegalAccessException | NoSuchFieldException reflectiveOperationException) {
            reflectiveOperationException.printStackTrace();
        }
    }
}
