package today.makrit.module.impl.movement;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.DoubleSetting;
import today.makrit.module.setting.ModeSetting;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.ThePlayer;

import java.util.Objects;

public class HighJump extends Module {
    private ModeSetting mode = new ModeSetting("Mode", "AAC", "AAC");
    private DoubleSetting height = new DoubleSetting("Height", 0.1, 0.1, 20.5);
    boolean jumped = false;
    int stage = 0;
    public HighJump() {
        super("HighJump", ModuleCategory.MOVEMENT, 0);
        settings.add(mode);
        settings.add(height);
    }

    public Timer timer = new Timer();


    @Subscribe
    public void render(RenderEvent re) {
        if (timer.hasTimeElapsed(1000 / 50, true)) {
            if (Objects.equals(mode.getValue(), "AAC")) {
                if (ThePlayer.onGround()) {
                    ThePlayer.jumpMovementFactor((float) height.getNumber());
                }
            }
        }
    }
}
