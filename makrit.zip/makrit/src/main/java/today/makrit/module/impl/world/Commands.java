package today.makrit.module.impl.world;

import com.craftrise.d3;
import com.craftrise.m9;
import com.google.common.eventbus.Subscribe;
import today.makrit.event.EventTarget;
import today.makrit.event.impl.PacketSentEvent;
import today.makrit.friend.FriendManager;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.ModuleManager;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import org.lwjgl.input.Keyboard;

public class Commands
        extends Module {
    static String[] args;
    static String name;
    static ModuleCategory cat;
    public m9 target;
    static int key;

    public Commands() {
        super("Commands", ModuleCategory.WORLD, 0);
        this.toggle();
    }
}
 