package today.makrit.module.impl.misc;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import cr.launcher.Config;
import cr.launcher.main.a;
@SuppressWarnings("unused")
public class AntiInvıs extends Module {
    public AntiInvıs() {
        super("AntiInvıs", ModuleCategory.MISC, 0);
    }

    @Subscribe
    public void onRender(RenderEvent e) {
        Config.getMinecraft().bu.H.stream()
                .filter(player -> player != a.q)
                .forEach(player -> {
                    player.i(com.craftrise.Z.L.k.a(5L),5L);
                    player.a(false,5L);
                });
    }
}
