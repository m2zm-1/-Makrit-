package today.makrit.module;

import today.makrit.module.impl.combat.Aimbot;
import today.makrit.module.impl.combat.AutoArmor;
import today.makrit.module.impl.combat.KillAura;
import today.makrit.module.impl.combat.Velocityy;
import today.makrit.module.impl.misc.*;
import today.makrit.module.impl.movement.*;
import today.makrit.module.impl.player.InvManager;
import today.makrit.module.impl.player.Mevlana;
import today.makrit.module.impl.player.NoFall;
import today.makrit.module.impl.render.*;
import today.makrit.module.impl.world.Commands;
import today.makrit.module.impl.world.Reporter;
import today.makrit.module.impl.world.Scaffold;
import today.makrit.module.impl.world.Stealer;
import today.makrit.utils.mapper.Minecraft;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ModuleManager {
    private static final List<Module> youDidIt = new ArrayList<>();

    public static void addMod(Module kys) {
        youDidIt.add(kys);
    }

    public static void removeMod(Module kys) {
        youDidIt.remove(kys);
    }

    public static void addAll(Module... kys) {
        for (Module ky : kys) {
            addMod(ky);
        }
    }

    public static Module withName(String name) {
        return youDidIt.stream().filter(it -> it.name.equalsIgnoreCase(name)).findFirst().orElseThrow(NullPointerException::new);
    }

    public static List<Module> enabled() {
        return youDidIt.stream().filter(Module::isToggled).collect(Collectors.toList());
    }

    public static List<Module> all() {
        return youDidIt;
    }

    public static boolean isEnabled(String name) {
        return youDidIt.stream().filter(Module::isToggled).anyMatch(it -> it.name.equalsIgnoreCase(name));
    }
    public static boolean isDisabled(String name) {
        return youDidIt.stream().filter(Module::unToggled).anyMatch(it -> it.name.equalsIgnoreCase(name));
    }

    public static void registerModules() {
        ModuleManager.addMod(new NoSlow());
        ModuleManager.addMod(new Fly());
        ModuleManager.addMod(new Glide());
        ModuleManager.addMod(new Speed());
        ModuleManager.addMod(new KillAura());
        ModuleManager.addMod(new Velocityy());
        ModuleManager.addMod(new NoFall());
        ModuleManager.addMod(new AirJump());
        ModuleManager.addMod(new Mevlana());
        ModuleManager.addMod(new Hud());
        ModuleManager.addMod(new TargetHud());
        ModuleManager.addMod(new AntiBot());
        ModuleManager.addMod(new Strafe());
        ModuleManager.addMod(new Teleporter());
        ModuleManager.addMod(new AutoArmor());
        ModuleManager.addMod(new TeleportTargetStrafe());
        ModuleManager.addMod(new InvManager());
        ModuleManager.addMod(new Scaffold());
        ModuleManager.addMod(new Stealer());
        ModuleManager.addMod(new InventoryWalk());
        ModuleManager.addMod(new Reporter());
        //ModuleManager.addMod(new Step());
        //ModuleManager.addMod(new PIT());
        ModuleManager.addMod(new Clip());
        ModuleManager.addMod(new ClickTP());
        ModuleManager.addMod(new Aimbot());
        //ModuleManager.addMod(new AntiVoid());
        ModuleManager.addMod(new Animations());
        ModuleManager.addMod(new Commands());
    }

    public static void checkForKeyBind() {
        for (Module module : youDidIt) {
            boolean isKeyDown = Keyboard.isKeyDown(module.key);
            if (Minecraft.getCurrentScreen() == null) {
                if (isKeyDown && !module.wasKeyPressed) {
                    module.toggle();
                    module.wasKeyPressed = true;
                } else if (!isKeyDown) {
                    module.wasKeyPressed = false;
                }
            }
        }
    }
}
