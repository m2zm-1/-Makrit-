package today.makrit.module.impl.movement;

import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.NumberSetting;
import today.makrit.utils.mapper.ThePlayer;

public class ClickTP extends Module {
    NumberSetting blockSetting = new NumberSetting("Block", 5,1,7);
    public ClickTP() {
        super("Flash", ModuleCategory.MOVEMENT, 0);

        this.settings.add(blockSetting);
    }
    float degreesToRadians(float degrees) {
        return degrees * (3.14159265358979323846f / 180.0f);
    }
    @Override
    public void onEnable() {
        if(this.toggled) {
            double posx = ThePlayer.GetPosX();
            double posy = ThePlayer.GetPosY();
            double posz = ThePlayer.GetPosZ();

            float rotationyaw = ThePlayer.GetrotationYaw();
            float rotationpitch = ThePlayer.GetRotationPitch();

            double radians = degreesToRadians(rotationyaw * -1.0f);
            double radians2 = degreesToRadians(rotationpitch * -1.0f);



            ThePlayer.setPosition_mid(posx + Math.sin(radians) * Math.cos(radians2) * blockSetting.getNumber(),
                    posy + Math.sin(radians2) * blockSetting.getNumber(),
                    posz + Math.cos(radians) * Math.cos(radians2) * blockSetting.getNumber());
            this.toggle();
        }
    }
}
