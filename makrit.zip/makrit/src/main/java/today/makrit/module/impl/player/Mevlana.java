package today.makrit.module.impl.player;

import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.NumberSetting;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.ThePlayer;

public class Mevlana extends Module {
    public static NumberSetting mevlanaSpeedSetting;
    private final Timer timer = new Timer();
    static {
        Mevlana.mevlanaSpeedSetting = new NumberSetting("Speed", 2, 0, 10);
    }
    public float yaw;

    public Mevlana() {
        super("SpinBot", ModuleCategory.PLAYER, 0);
        settings.add(mevlanaSpeedSetting);
    }

    @Override
    public void onEnable() {
        this.yaw = ThePlayer.GetrotationYaw();
        super.onEnable();
    }

    @Override
    public void onRender2DEvent() {
        if (this.isToggled()) {
            // Yaw (sağ-sol ekseni) için sahte dönüş
            float targetYaw = this.yaw;
            targetYaw += Mevlana.mevlanaSpeedSetting.getNumber();
            if (targetYaw >= 360.0f) {
                targetYaw = 0.0f;
            }

            // Kafanın aşağıya bakmasını ayarlamak için pitch
            float fakePitch = -90.0f; // Tamamen aşağıya bakması için

            // Sahte olarak kafanın rotasyonunu ayarla
            ThePlayer.rotationYawHead(targetYaw);   // Kafanın sağ-sol dönüşü
            ThePlayer.renderYawOffset(targetYaw);   // Kafanın render'ında sağ-sol

            this.yaw = targetYaw;
        }
    }

    public float interpolate(float current, float target, float factor) {
        float delta = wrapDegrees(target - current);
        return current + delta * factor;
    }

    public float wrapDegrees(float degrees) {
        degrees = degrees % 360.0f;
        if (degrees >= 180.0f) {
            degrees -= 360.0f;
        }
        if (degrees < -180.0f) {
            degrees += 360.0f;
        }
        return degrees;
    }
}
