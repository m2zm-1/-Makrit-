package today.makrit.module.impl.world;

import com.craftrise.client.e3;
import com.google.common.eventbus.Subscribe;
import cr.launcher.main.a;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.DoubleSetting;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.*;
import today.makrit.utils.proutils;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class Stealer extends Module {
    DoubleSetting delay = new DoubleSetting("Delay", 1, 1, 300);
    public Timer timer = new Timer();

    public Stealer() {
        super("Stealer", ModuleCategory.WORLD, 0);
        settings.add(delay);
    }

    public static boolean collecting = false;

    @Subscribe
    public void onRender(RenderEvent e) throws ClassNotFoundException, IllegalAccessException {
        if (isToggled() && Minecraft.GetMinecraft().bw instanceof com.craftrise.client.e3) {
            try {
                if (isToggled() && Minecraft.GetMinecraft().bw instanceof com.craftrise.client.e3) {
                    com.craftrise.qe container = (com.craftrise.qe) Minecraft.GetPlayer().T;
                    Method getLowerChestInventoryMethod = proutils.filterMethodFromReturnTypeAndParams(com.craftrise.kX.class, com.craftrise.qe.class);
                    getLowerChestInventoryMethod.setAccessible(true);

                    List<Integer> slots = new ArrayList<>();
                    e3 chest = (e3) Minecraft.GetMinecraft().bw;
                    for (int index = 0; index < 27; ++index) {
                        {
                            slots.add(index);
                        }
                    }


                    for (int slot : slots) {
                        if (timer.hasTimeElapsed((short) delay.getNumber(), true)) {
                            collecting = true;
                            Minecraft.GetPlayerControllerMp().a(chest.E.i, slot, 0, 1, a.q, 10L);
                        }
                    }
                    collecting = false;
                }
            } catch (Exception ex) {
                Minecraft.addChatMessage(ex.toString());
            }
        }
    }

}