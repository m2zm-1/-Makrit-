package today.makrit.module.impl.combat;

import today.makrit.Main;
import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.ModuleManager;
import today.makrit.module.setting.NumberSetting;
import today.makrit.utils.Helper.MathHelper;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import today.makrit.utils.mapper.TheWorld;
import com.craftrise.client.S;
import com.craftrise.m9;
import com.craftrise.mg;
import cr.launcher.Config;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Aimbot extends Module {
    private NumberSetting reach = new NumberSetting("Range", 4, 3, 7);
    private String targetName;
    private float targetHealth;
    public Timer timer = new Timer();

    public Aimbot() {
        super("Aimbot", ModuleCategory.COMBAT, 0);

        this.settings.add(reach);
    }

    public static float[] getDirectionToEntity(com.craftrise.m9 entity) throws InvocationTargetException, NoSuchMethodException, IllegalAccessException {
        return new float[]{getYaw(entity) + ThePlayer.GetrotationYaw(), getPitch(entity) + ThePlayer.GetRotationPitch()};
    }

    public static float sqrt_double(double value) {
        return (float) Math.sqrt(value);
    }

    public static float wrapAngleTo180_float(float value) {
        value = value % 360.0F;

        if (value >= 180.0F) {
            value -= 360.0F;
        }

        if (value < -180.0F) {
            value += 360.0F;
        }

        return value;
    }

    public static float getYaw(com.craftrise.m9 entity) {
        double var1 = entity.bE - ThePlayer.GetPosX();
        double var3 = entity.bH - ThePlayer.GetPosZ();
        double var5;
        double v = Math.toDegrees(Math.atan(var3 / var1));
        if ((var3 < 0.0D) && (var1 < 0.0D)) {
            var5 = 90.0D + v;
        } else {
            if ((var3 < 0.0D) && (var1 > 0.0D)) {
                var5 = -90.0D + v;
            } else {
                var5 = Math.toDegrees(-Math.atan(var1 / var3));
            }
        }

        return wrapAngleTo180_float(-(ThePlayer.GetrotationYaw() - (float) var5));
    }

    public static float getPitch(com.craftrise.m9 var0) {
        double var1 = var0.bE - ThePlayer.GetPosX();
        double var3 = var0.bH - ThePlayer.GetPosZ();
        double var5 = var0.aY - 1.6D + getEyeHeigh(var0) - ThePlayer.GetPosY();
        double var7 = sqrt_double(var1 * var1 + var3 * var3);
        double var9 = -Math.toDegrees(Math.atan(var5 / var7));
        return -wrapAngleTo180_float(ThePlayer.GetRotationPitch() - (float) var9);
    }

    public static float getEyeHeigh(com.craftrise.m9 entity) {
        float result = 0.0F;

        try {
            for (Method m : com.craftrise.m9.class.getDeclaredMethods()) {
                if (m.getName().equals("e")) {
                    if (m.getParameterCount() == 1) {
                        if (m.getReturnType().toString().contains("float")) {
                            m.setAccessible(true);

                            result = (Float) m.invoke((Object) entity, Main.idk);
                        }
                    }
                }
            }
        } catch (Exception e) {
            Minecraft.addChatMessage(e.toString());
        }

        return result;
    }

    public static float[] getRotationsNeeded(final mg target) {
        List<mg> targets = TheWorld.playerEntities()
                .stream()
                .filter(e -> GetDistanceToEntity(e) < 5 && e != Minecraft.GetPlayer())
                .sorted(Comparator.comparingDouble(entity -> GetDistanceToEntity(entity)))
                .collect(Collectors.toList());

        if (!targets.isEmpty()) {
            mg nearestTarget = targets.get(0);
            S mc = Config.getMinecraft();

            final double xSize = ThePlayer.GetPosX(nearestTarget) - ThePlayer.GetPosX();
            final double ySize = ThePlayer.GetPosY(nearestTarget) + getEyeHeigh(Minecraft.GetPlayer()) / 2 - (ThePlayer.GetPosY() + getEyeHeigh(Minecraft.GetPlayer()));
            final double zSize = ThePlayer.GetPosZ(nearestTarget) - ThePlayer.GetPosZ();
            final double theta = MathHelper.sqrt_double(xSize * xSize + zSize * zSize);

            final float yaw = (float) (Math.atan2(zSize, xSize) * 180 / Math.PI) - 90;
            final float pitch = (float) (-(Math.atan2(ySize, theta) * 180 / Math.PI));

            return new float[]{
                    (ThePlayer.GetrotationYaw() + MathHelper.wrapAngleTo180_float(yaw - ThePlayer.GetrotationYaw())) % 360,
                    (ThePlayer.GetRotationPitch() + MathHelper.wrapAngleTo180_float(pitch - ThePlayer.GetRotationPitch())) % 360.0f
            };
        }
        return null; // Return null if there are no valid targets
    }


    @Subscribe
    public void render(RenderEvent event) throws InvocationTargetException, NoSuchMethodException, IllegalAccessException {
        List<mg> targets = TheWorld.playerEntities();

        targets = targets.stream().filter(e -> GetDistanceToEntity(e) < this.reach.getNumber() && e != Minecraft.GetPlayer()).collect(Collectors.toList());
        targets = new ArrayList<>(targets);
        targets.sort(Comparator.comparingDouble(entity -> GetDistanceToEntity(entity)));

        if(!targets.isEmpty()) {
            for (mg target : targets) {
                if(Minecraft.getEntityHealth(target) != 1.0 && ModuleManager.isEnabled("AntiBot")) {
                    if(GetDistanceToEntity(target) < reach.getNumber()) {
                        float[] rots = getDirectionToEntity(target);
                        ThePlayer.setRotations(rots[0], rots[1]);
                        this.targetHealth = Minecraft.getEntityHealth(target);
                        this.targetName = Minecraft.getEntityDisplayName(target);
                    }
                }
            }
        }
    }

    public static float GetDistanceToEntity(m9 m92) {
        try {
            float f = (float)(Minecraft.GetPlayer().bE - m92.bE);
            float f2 = (float)(Minecraft.GetPlayer().aY - m92.aY);
            float f3 = (float)(Minecraft.GetPlayer().bH - m92.bH);
            String string = "com.craftrise.pj";
            String string2 = "d";
            Class<?> clazz = Class.forName(string);
            Method method = clazz.getMethod(string2, Float.TYPE);
            Object object = method.invoke((Object)m92, Float.valueOf(f * f + f2 * f2 + f3 * f3));
            return ((Number) object).floatValue();
        } catch (Exception exception) {
            Minecraft.addChatMessage("Distance error: " + exception.toString());
            return -1.0f;
        }
    }
}