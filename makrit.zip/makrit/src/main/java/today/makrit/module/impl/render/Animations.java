package today.makrit.module.impl.render;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.ModeSetting;
import today.makrit.module.setting.NumberSetting;
import today.makrit.utils.mapper.ThePlayer;
import today.net.minecraft.util.MathHelper;

import java.util.Objects;

public class Animations extends Module {
    private ModeSetting mode = new ModeSetting("Mode", "Normal", "Normal", "Helicopter");
    public static NumberSetting pitch = new NumberSetting("Pitch", -150, -2500, 2500);
    public static NumberSetting yaw = new NumberSetting("Yaw", -45, -2500, 2500);
    public float yaw2;
    public Animations() {
        super("Animations", ModuleCategory.RENDER, 0);
        settings.add(mode);
        settings.add(yaw);
        settings.add(pitch);
    }
    float swingProgress = 1;
    float var16 = MathHelper.sin(MathHelper.sqrt_float(swingProgress) * 3.1415927F);

    @Subscribe
    public void onTick(RenderEvent e) {
        if (Objects.equals(mode.getValue(), "Normal")) {
            ThePlayer.SetrenderArmPitch(ThePlayer.GetRotationPitch() +pitch.getNumber());
            ThePlayer.SetrenderArmYaw(ThePlayer.GetrotationYaw() + yaw.getNumber());
            ThePlayer.SetrenderArmPitch(ThePlayer.GetRotationPitch() +pitch.getNumber());
            ThePlayer.SetrenderArmYaw(ThePlayer.GetrotationYaw() + yaw.getNumber());
        }
        if (Objects.equals(mode.getValue(), "Helicopter")) {
            // Açıyı arttırarak dairesel hareket sağla
            this.yaw2 += 5;
            if (this.yaw2 >= 360.0f) {
                this.yaw2 = 0.0f;
            }

            // Daire etrafındaki açı (radyan cinsinden)
            double angleRad = Math.toRadians(this.yaw2);

            // Daire'nin yarıçapı ve merkezi
            float radius = 65.0f;
            float centerX = 25.0f;
            float centerY = 0.0f;

            // Kolun konumunu daire üzerinde hesapla
            float x = (float) (centerX + radius * Math.cos(angleRad));
            float y = (float) (centerY + radius * Math.sin(angleRad));

            // Kolun her zaman dairenin merkezine bakmasını sağla
            float deltaX = centerX - x;
            float deltaY = centerY - y;

            // Yön açısını hesapla
            float lookAngle = (float) Math.toDegrees(Math.atan2(deltaY, deltaX));

            // Kolun pozisyonunu ve yönünü ayarla
            ThePlayer.SetrenderArmPitch(ThePlayer.GetRotationPitch() + y);
            ThePlayer.SetrenderArmYaw(lookAngle); // Kolun yönü merkezi gösterecek
        }

    }
}
