package today.makrit.module.impl.movement;

import com.craftrise.dR;
import com.google.common.eventbus.Subscribe;
import cr.e;
import cr.launcher.Config;
import cr.launcher.main.a;
import org.lwjgl.input.Keyboard;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.ModeSetting;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.ThePlayer;

import java.lang.reflect.Field;
import java.util.Objects;

public class Speed extends Module {
    private ModeSetting mode = new ModeSetting("Mode", "Rise", "Rise", "Exhibition", "AAC");

    public Speed() {
        super("Speed", ModuleCategory.MOVEMENT, Keyboard.KEY_V);
        settings.add(mode);
    }

    @Subscribe
    public void render(RenderEvent re) {
        if (timer.hasTimeElapsed(1000 / 50, true)) {
            if (Objects.equals(mode.getValue(), "AAC")) {
                if (ThePlayer.isMoving()) {
                    if (ThePlayer.onGround()) {
                        ThePlayer.Strafe(2.1f);
                        ThePlayer.jump();
                        double motionx = ThePlayer.GetMotionX();
                        double motionz = ThePlayer.GetMotionZ();
                        ThePlayer.SetMotionY(0.050f);
                        setSpeed(0.5);
                    }
                }
            } else if (Objects.equals(mode.getValue(), "Rise")) {
                if (ThePlayer.isMoving()) {
                    setSpeed(0.25);
                    if (ThePlayer.onGround()) {
                        ThePlayer.jump();
                    }
                }
            }  else if (Objects.equals(mode.getValue(), "Exhibition")) {
                if (ThePlayer.isMoving()) {
                    if (ThePlayer.onGround()) {
                        ThePlayer.jump();
                        double speed = getBaseMoveSpeed() - 0.02;
                        ThePlayer.Strafe((float) (speed - (Math.random() / 2000)));
                    }
                }
            }
        }
    }
    private int ticks, offGroundTicks, onGroundTicks, stage, ticksDisable;
    private boolean jumped, bool, verusEpicBypassBooleanTM, touchedGround;
    private float speed2;
    private float speed3;
    public Timer timer = new Timer();
    private int stage2;

    public static cr.g getgField() {
        try {
            Field hField = Config.getMinecraft().cl.getClass().getDeclaredField("d");
            hField.setAccessible(true);
            return (cr.g)hField.get(Config.getMinecraft().cl);
        }catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public static void setTimerSpeed(float value){
        try {
            Field hField = Config.getMinecraft().cl.getClass().getDeclaredField("a");
            hField.setAccessible(true);
            hField.set(Config.getMinecraft().cl, new e(value,getgField().a()));
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }
    public static void setSpeed(double moveSpeed, float yaw, double strafe, double forward) {
        if (forward != 0.0D) {
            if (strafe > 0.0D) {
                yaw += ((forward > 0.0D) ? -45 : 45);
            } else if (strafe < 0.0D) {
                yaw += ((forward > 0.0D) ? 45 : -45);
            }
            strafe = 0.0D;
            if (forward > 0.0D) {
                forward = 1.0D;
            } else if (forward < 0.0D) {
                forward = -1.0D;
            }
        }
        if (strafe > 0.0D) {
            strafe = 1.0D;
        } else if (strafe < 0.0D) {
            strafe = -1.0D;
        }
        double mx = Math.cos(Math.toRadians((yaw + 90.0F)));
        double mz = Math.sin(Math.toRadians((yaw + 90.0F)));
        a.q.bh = new dR(forward * moveSpeed * mx + strafe * moveSpeed * mz);
        a.q.bf = new dR(forward * moveSpeed * mz - strafe * moveSpeed * mx);
    }
    public static double getBaseMoveSpeed() {
        double baseSpeed = a.q.S.b(5L) * 2.873;
        return baseSpeed;
    }

    public static void setSpeed(double moveSpeed) {
        setSpeed(moveSpeed, a.q.bL, a.q.l.c.a(5L), a.q.l.b.a(5L));
    }
}