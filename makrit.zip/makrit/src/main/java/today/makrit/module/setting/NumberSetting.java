package today.makrit.module.setting;

public class NumberSetting extends Setting {
   public int increment = 1;
   private float number;
   private float min;
   private float max;

   public NumberSetting(String name, float value, float min, float max) {
      super(name);
      this.number = value;
      this.min = min;
      this.max = max;
   }

   public float getMax() {
      return this.max;
   }

   public float getMin() {
      return this.min;
   }

   public long getNumber() {
      return (long)this.number;
   }

   public void setNumber(float number) {
      this.number = number;
   }
}
