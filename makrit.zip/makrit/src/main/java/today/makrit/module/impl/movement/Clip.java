package today.makrit.module.impl.movement;

import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.NumberSetting;
import today.makrit.utils.mapper.ThePlayer;

public class Clip extends Module {
    NumberSetting blockSetting = new NumberSetting("Block", 5, -10, 10);

    public Clip() {
        super("Clip", ModuleCategory.MOVEMENT, 0);
        this.settings.add(blockSetting);
    }

    @Override
    public void onEnable() {
        if (this.toggled) {
            double posy = ThePlayer.GetPosY();
            ThePlayer.setPosition_mid(ThePlayer.GetPosX(), posy + blockSetting.getNumber(), ThePlayer.GetPosZ());
            this.toggle();
        }
    }

    private float degreesToRadians(float degrees) {
        return degrees * (3.14159265358979323846f / 180.0f);
    }
}
