package today.makrit.module.impl.misc;

import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.ModuleManager;
import today.makrit.module.setting.BooleanSetting;
import today.makrit.module.setting.DoubleSetting;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import today.makrit.utils.mapper.TheWorld;
import com.craftrise.m9;
import com.craftrise.mg;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class TeleportTargetStrafe extends Module {
    public static BooleanSetting look = new BooleanSetting("Look target", true);
    public static DoubleSetting radius = new DoubleSetting("Radius", 2.5, 0.1, 10.0); // Etrafında dönülecek mesafe
    public static DoubleSetting range = new DoubleSetting("Range", 10.0, 1.0, 50.0); // Hedefin seçilme menzili
    public static DoubleSetting speed = new DoubleSetting("Speed", 0.3, 0.1, 2.0); // Dönme hızı

    public TeleportTargetStrafe() {
        super("Target Strafe", ModuleCategory.MISC, 0);
        settings.add(look);
        settings.add(radius);
        settings.add(range);
        settings.add(speed);
    }

    @Override
    public void onRender2DEvent() {
        List<mg> targets = TheWorld.playerEntities();
        targets = targets.stream().filter(e -> GetDistanceToEntity(e) < range.getNumber() && e != Minecraft.GetPlayer()).collect(Collectors.toList());
        targets = new ArrayList<>(targets);
        targets.sort(Comparator.comparingDouble(entity -> GetDistanceToEntity(entity)));

        if (this.isToggled() && !targets.isEmpty()) {
            mg target = targets.get(0); // En yakın hedefi al
            if(Minecraft.getEntityHealth(target) != 1.0 && ModuleManager.isEnabled("AntiBot")) {
                double angle = (System.currentTimeMillis() % 360) * speed.getNumber(); // Zamanla artan bir açı

                // Oyuncunun etrafında dönme işlemi (X ve Z eksenlerinde daire çizer)
                double offsetX = radius.getNumber() * Math.cos(Math.toRadians(angle));
                double offsetZ = radius.getNumber() * Math.sin(Math.toRadians(angle));


                // Y eksenindeki hareket değişmeden kalır
                ThePlayer.SetMotionY(ThePlayer.GetMotionY());

                // Hedefe bak
                if (look.isToggled()) {
                    double diffX = ThePlayer.GetPosX(target) - ThePlayer.GetPosX();
                    double diffZ = ThePlayer.GetprevPosZ(target) - ThePlayer.GetprevPosZ();
                    float yaw = (float) (Math.atan2(diffZ, diffX) * (180.0 / Math.PI)) - 90.0f;
                    ThePlayer.SetRotationYaw(yaw);
                }

                // Oyuncu hareket ediyorsa hız ayarla ve yerdeyse zıpla
                if (ThePlayer.isMoving()) {
                    setSpeed(0.25); // Hızını ayarla
                    if (ThePlayer.onGround()) {
                        ThePlayer.jump(); // Zıpla
                    }
                }
            }
        }
    }

    public static float GetDistanceToEntity(m9 m92) {
        try {
            float f = (float)(Minecraft.GetPlayer().bE - m92.bE);
            float f2 = (float)(Minecraft.GetPlayer().aY - m92.aY);
            float f3 = (float)(Minecraft.GetPlayer().bH - m92.bH);
            return (float)Math.sqrt(f * f + f2 * f2 + f3 * f3);
        } catch (Exception exception) {
            Minecraft.addChatMessage("Distance error: " + exception.toString());
            return -1.0f;
        }
    }

    // Hızı ayarlamak için basit bir metod
    private void setSpeed(double speed) {
        double currentYaw = Math.toRadians(ThePlayer.GetrotationYaw());
        ThePlayer.SetMotionX(-Math.sin(currentYaw) * speed);
        ThePlayer.SetMotionZ(Math.cos(currentYaw) * speed);
    }
}
