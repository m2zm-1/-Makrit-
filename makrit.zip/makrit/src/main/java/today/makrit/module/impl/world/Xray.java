package today.makrit.module.impl.world;

import today.makrit.Main;
import today.makrit.module.ModuleCategory;
import today.makrit.module.impl.SimpleModule;
import today.makrit.module.setting.BooleanSetting;
import today.makrit.module.setting.ModeSetting;
import today.makrit.module.setting.NumberSetting;
import today.makrit.module.setting.RunnableSetting;
import today.makrit.module.setting.interfaces.IRunnable;
import today.makrit.utils.Helper.BlockHelper;
import today.makrit.utils.Helper.RenderHelper;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import cr.launcher.BlockPos;
import cr.launcher.Config;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Xray extends SimpleModule {
    public static List<XrayBlock> highlightedBlocks;
    private ModeSetting antiXrayBypass = new ModeSetting("Mode", "Orebfuscator1", "Orebfuscator1", "Vanilla");
    private static final BooleanSetting render = new BooleanSetting("Render", true);
    private static final BooleanSetting custom = new BooleanSetting("Custom", false);
    private static final BooleanSetting Diamond = new BooleanSetting("Diamond", true);
    private static final BooleanSetting Ametist = new BooleanSetting("Ametist", true);
    private static final BooleanSetting Emerald = new BooleanSetting("Emerald", true);
    private static final BooleanSetting Iron = new BooleanSetting("Iron", true);
    private static final BooleanSetting Gold = new BooleanSetting("Gold", true);
    private static final BooleanSetting Coal = new BooleanSetting("Coal", false);
    private static final BooleanSetting Lapis = new BooleanSetting("Lapis", false);
    private static final BooleanSetting Redstone = new BooleanSetting("Redstone", false);
    private static final BooleanSetting Cobweb = new BooleanSetting("Cobweb", false);
    private static final NumberSetting range = new NumberSetting("Xray range", 10, 1, 32);
    private static final NumberSetting delay = new NumberSetting("Packet Delay", 15, 1, 30);
    private static final int[] blockIDs = {56, 15, 14, 557, 21, 73, 16, 129, 153, 30};
    public float oldGamma;
    private long lastTime;
    private final List<BlockPos> interactedBlocks;
    private final List<Object> interactPackets;
    private final RunnableSetting clearInteracts;
    public Xray() {
        super("Xray", ModuleCategory.WORLD, 1000, 10000);

        this.lastTime = 0L;
        this.interactedBlocks = new ArrayList<>();
        this.interactPackets = new ArrayList<>();
        this.clearInteracts = new RunnableSetting("Clear Interacts", (exela.craftrise.module.setting.interfaces.IRunnable) new XrayRemoveInteractsRunnable(this));
        this.settings.add(antiXrayBypass);
        this.settings.add(render);
        this.settings.add(custom);
        this.settings.add(range);
        this.settings.add(delay);
        if (custom.isToggled()) {
            this.settings.add(Diamond);
            this.settings.add(Ametist);
            this.settings.add(Emerald);
            this.settings.add(Iron);
            this.settings.add(Gold);
            this.settings.add(Lapis);
            this.settings.add(Redstone);
            this.settings.add(Coal);
            this.settings.add(Cobweb);
        }
    }

    @Override
    public void onEnable() {
        this.lastTime = Main.lastModuleOpen;
        super.onEnable();
    }
    @Override
    public void updateDelay() {
        if(this.isToggled()) {
            if (Objects.equals(antiXrayBypass.getValue(), "Orebfuscator1")) {
                final List<BlockPos> nearbyBlocks = BlockHelper.getBlockPositions(
                        (int) ThePlayer.GetPosX(),
                        (int) ThePlayer.GetPosY(),
                        (int) ThePlayer.GetPosZ(),
                        (char) range.getNumber());

                Minecraft.addChatMessage("§eTaranan blok sayisi: §7" + nearbyBlocks.size());

                List<XrayBlock> highlightedBlocks = null;
                if (render.isToggled()) {
                    highlightedBlocks = new ArrayList<>();
                }

                for (final BlockPos blockPos : nearbyBlocks) {
                    if (BlockHelper.getY(blockPos) > 0) {
                        final int blockID = Minecraft.getBlockID(blockPos);

                        if (antiXrayBypass.getValue().contains("Orebfuscator") && !interactedBlocks.contains(blockPos)) {
                            interactedBlocks.add(blockPos);
                            if (blockID != 0 && (blockID < 7 || blockID > 11)) {
                                interactPackets.add(Minecraft.C07PacketPlayerDigging(Minecraft.C07PacketPlayerDiggingAbortDestroyBlockEnum(), blockPos, Minecraft.EnumFacingUp()));
                            }
                        }

                        if (!render.isToggled()) {
                            continue;
                        }

                        for (int i = 0; i < blockIDs.length; ++i) {
                            if (blockID == blockIDs[i]) {
                                highlightedBlocks.add(new XrayBlock(blockPos, blockID));
                                break;
                            }
                        }
                    }
                }
                if (render.isToggled()) {
                    Xray.highlightedBlocks = highlightedBlocks;
                }
                super.updateDelay();
            }
        }
        if (Objects.equals(antiXrayBypass.getValue(), "Vanilla")) {
            oldGamma = Config.getGameSettings().y;

            Config.getGameSettings().y = 10F;
            Config.getGameSettings().aO = 0;

        }
    }


    @Override
    public void onRender2DEvent() {
        if (Objects.equals(antiXrayBypass.getValue(), "Orebfuscator1")) {
            super.onRender2DEvent();
            if (this.isToggled() && lastTime + delay.getNumber() <= Main.lastModuleOpen) {
                for (long n = lastTime + delay.getNumber(); n < Main.lastModuleOpen && !interactPackets.isEmpty(); n += delay.getNumber()) {
                    Minecraft.addToSendQueue(interactPackets.get(0));
                    interactPackets.remove(0);
                }
                lastTime = Main.lastModuleOpen;
            }
        }
        if (Objects.equals(antiXrayBypass.getValue(), "Vanilla")) {
            oldGamma = Config.getGameSettings().y;

            Config.getGameSettings().y = 10F;
            Config.getGameSettings().aO = 0;


        }
    }

    @Override
    public void onRender3DEvent(float float1) {
        if (Objects.equals(antiXrayBypass.getValue(), "Orebfuscator1")) {
            if (highlightedBlocks != null && render.isToggled()) {
                for (final XrayBlock xrayBlock : highlightedBlocks) {
                    if (Diamond.isToggled()) {
                        if (xrayBlock.id == 56) {
                            RenderHelper.calculateAdjustedEntityBoundingBox(xrayBlock.pos, new Color(2, 225, 255, 192).getRGB());
                        }
                    }
                    if (Ametist.isToggled()) {
                        if (xrayBlock.id == 557) {
                            RenderHelper.calculateAdjustedEntityBoundingBox(xrayBlock.pos, new Color(209, 0, 255, 192).getRGB());
                        }
                    }
                    if (Iron.isToggled()) {
                        if (xrayBlock.id == 15) {
                            RenderHelper.calculateAdjustedEntityBoundingBox(xrayBlock.pos, new Color(153, 160, 161, 192).getRGB());
                        }
                    }
                    if (Emerald.isToggled()) {
                        if (xrayBlock.id == 129) {
                            RenderHelper.calculateAdjustedEntityBoundingBox(xrayBlock.pos, new Color(21, 255, 5, 192).getRGB());
                        }
                    }
                    if (Gold.isToggled()) {
                        if (xrayBlock.id == 14) {
                            RenderHelper.calculateAdjustedEntityBoundingBox(xrayBlock.pos, new Color(255, 246, 31, 192).getRGB());
                        }
                    }
                    if (Coal.isToggled()) {
                        if (xrayBlock.id == 16) {
                            RenderHelper.calculateAdjustedEntityBoundingBox(xrayBlock.pos, new Color(0, 0, 0, 192).getRGB());
                        }
                    }
                    if (Redstone.isToggled()) {
                        if (xrayBlock.id == 73) {
                            RenderHelper.calculateAdjustedEntityBoundingBox(xrayBlock.pos, new Color(255, 0, 0, 192).getRGB());
                        }
                    }
                    if (Lapis.isToggled()) {
                        if (xrayBlock.id == 21) {
                            RenderHelper.calculateAdjustedEntityBoundingBox(xrayBlock.pos, new Color(7, 49, 255, 192).getRGB());
                        }
                    }
                    if (Cobweb.isToggled()) {
                        if (xrayBlock.id == 30) {
                            RenderHelper.calculateAdjustedEntityBoundingBox(xrayBlock.pos, new Color(255, 255, 255, 192).getRGB());
                        }
                    }
                }
            }
        }
        if (Objects.equals(antiXrayBypass.getValue(), "Vanilla")) {
            oldGamma = Config.getGameSettings().y;

            Config.getGameSettings().y = 10F;
            Config.getGameSettings().aO = 0;


        }
    }

    @Override
    public void onDisable() {
        Config.getGameSettings().y = oldGamma;
        Config.getGameSettings().aO = 1;


    }


    public static class XrayBlock {
        public BlockPos pos;
        public int id;

        public XrayBlock(BlockPos pos, int id) {
            this.pos = pos;
            this.id = id;
        }
    }
    static class XrayRemoveInteractsRunnable implements IRunnable {
        private final Xray xray;

        public XrayRemoveInteractsRunnable(Xray xray) {
            this.xray = xray;
        }

        @Override
        public void onRun() {
            xray.interactPackets.clear();;
            xray.interactedBlocks.clear();
        }
    }
}