package today.makrit.module.impl.player;

import today.makrit.module.ModuleCategory;
import today.makrit.module.impl.SimpleModule;
import today.makrit.module.setting.NumberSetting;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import com.craftrise.client.fa;
import com.craftrise.m9;
import cr.launcher.BlockPos;

import java.lang.reflect.Field;

public class AntiVoid extends SimpleModule {
    private static final NumberSetting distance = new NumberSetting("Distance", 4, 1, 6);

    private static final NumberSetting blockYDistance = new NumberSetting("BlockY Distance", 15, 1, 30);
    public double lastPosX;
    public double lastPosY;
    public double lastPosZ;

    public AntiVoid() {
        super("AntiVoid", ModuleCategory.WORLD, 1000, 10000);
        this.settings.add(distance);
        //this.settings.add(blockYDistance);
    }

    public float FallDistance() {
        try {
            Class<m9> clazz = m9.class;
            Field field = clazz.getDeclaredField("c");
            field.setAccessible(true);
            fa fa2 = Minecraft.GetPlayer();
            float f = field.getFloat(fa2);
            return f;
        } catch (IllegalAccessException | NoSuchFieldException reflectiveOperationException) {
            reflectiveOperationException.printStackTrace();
            return -1.0f;
        }
    }
    @Override
    public void updateDelay() {
        if (this.toggled) {
            final double currentPosY = (ThePlayer.GetPosY() == (int) ThePlayer.GetPosY()) ? (ThePlayer.GetPosY() - 1.0) : ThePlayer.GetPosY();
            if (ThePlayer.onGround()) {
                if (Minecraft.getBlockID(new BlockPos(ThePlayer.GetPosX(), currentPosY, ThePlayer.GetprevPosZ())) != 0) {
                    lastPosX = ThePlayer.GetPosX();
                    lastPosZ = ThePlayer.GetPosY();
                    lastPosY = ThePlayer.GetprevPosZ();
                }
            } else if (!ThePlayer.isMoving() && lastPosZ - ThePlayer.GetPosY() > AntiVoid.distance.getNumber()) {
                boolean lagBackTriggered = false;
                BlockPos blockPos;
                int distanceFromBlockY;
                for (distanceFromBlockY = 0; distanceFromBlockY <= AntiVoid.blockYDistance.getNumber(); ++distanceFromBlockY) {
                    BlockPos blockPos1 = new BlockPos((int) ThePlayer.GetPosX(), (int) (ThePlayer.GetPosY() - distanceFromBlockY), (int) ThePlayer.GetPosZ());
                    int blockID = Minecraft.getBlockID(blockPos1);

                    if (blockID == 0) {
                        lagBackTriggered = true;
                    } else {
                    }
                }

                if (lagBackTriggered) {
                    Minecraft.addChatMessage("§fFlag!");
                    ThePlayer.setPositionAndRotation(lastPosX + 0.5, lastPosZ, lastPosY, ThePlayer.GetrotationYaw(), ThePlayer.GetRotationPitch());
                    super.updateDelay();
                }
            }
        }
    }
}