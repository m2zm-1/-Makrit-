package today.makrit.module.impl.world;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.utils.mapper.Minecraft;

public class FastPlace extends Module {
    public FastPlace() {
        super("FastPlace", ModuleCategory.WORLD, 0);
    }

    @Subscribe
    public void onTick(RenderEvent e) {
        if(this.toggled) {
            Minecraft.setRightClickDelayTimer(); // Set 0
        }
    }
}
