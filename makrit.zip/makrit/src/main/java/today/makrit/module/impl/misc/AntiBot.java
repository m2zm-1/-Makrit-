package today.makrit.module.impl.misc;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.ModeSetting;
import today.makrit.utils.mapper.Minecraft;
import com.craftrise.m9;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Objects;

public class AntiBot extends Module {
    private ModeSetting mode = new ModeSetting("Mode", "Reflex", "ReflexNew", "Reflex");

    public AntiBot() {
        super("AntiBot", ModuleCategory.MISC, 0);
        settings.add(mode);
        this.toggle();
    }

    public static void RemoveEntity(Object entity) {
        try {
            Class<?> worldClass = Class.forName("com.craftrise.client.cf");
            Method bMethod = worldClass.getDeclaredMethod("b", m9.class, Long.TYPE);
            bMethod.invoke(Minecraft.GetWorld(), entity, 5L);
        }
        catch (ClassNotFoundException | IllegalAccessException | NoSuchMethodException | InvocationTargetException e2) {
            e2.printStackTrace();
        }
    }

    @Subscribe
    public void onRender(RenderEvent e) {
        if (Objects.equals(mode.getValue(), "Reflex")) {
        }

        if (Objects.equals(mode.getValue(), "ReflexNew")) {
            AntiBot.RemoveEntity(Minecraft.GetPlayer());
        }
    }
}
