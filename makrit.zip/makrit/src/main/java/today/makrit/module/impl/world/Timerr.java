package today.makrit.module.impl.world;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.DoubleSetting;
import cr.e;
import cr.launcher.Config;

import java.lang.reflect.Field;

@SuppressWarnings("unused")
public class Timerr extends Module {
    private static cr.g d;
    private DoubleSetting amount = new DoubleSetting("Timer Speed", 1.5f, 0.1f, 3.0f);

    public Timerr() {
        super("Timer", ModuleCategory.WORLD, 0);
        settings.add(amount);
    }

    public static cr.g getgField() {
        try {
            Field hField = Config.getMinecraft().cl.getClass().getDeclaredField("d");
            hField.setAccessible(true);
            return (cr.g)hField.get(Config.getMinecraft().cl);
        }catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void setTimerSpeed(float value){
        try {
            Field hField = Config.getMinecraft().cl.getClass().getDeclaredField("a");
            hField.setAccessible(true);
            hField.set(Config.getMinecraft().cl, new e(value,getgField().a()));
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }
    @Subscribe
    public void render(RenderEvent re) {
        setTimerSpeed((float) (amount.getNumber()*1));
    }
}
