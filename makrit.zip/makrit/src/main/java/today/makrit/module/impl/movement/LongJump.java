package today.makrit.module.impl.movement;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.DoubleSetting;
import today.makrit.module.setting.ModeSetting;
import today.makrit.utils.mapper.ThePlayer;

import java.util.Objects;

import static today.makrit.module.impl.movement.Fly.setSpeed;

public class LongJump extends Module {
    private ModeSetting mode = new ModeSetting("Mode", "AAC4", "AAC4");
    private DoubleSetting speed = new DoubleSetting("Speed", 0.1f, 0.1f, 7.0f);

    public LongJump() {
        super("LongJump", ModuleCategory.MOVEMENT, 0);
        this.settings.add(mode);
    }

    @Override
    public void onEnable() {
        ThePlayer.jump();
        setSpeed((float)speed.getNumber() * 2);
    }

    @Subscribe
    public void render(RenderEvent re) {
        if (Objects.equals(mode.getValue(), "AAC4") && ThePlayer.isMoving()) {
            if(ThePlayer.GetMotionY() < -0.05)
                ThePlayer.SetMotionY(0.03);
            setSpeed((float)speed.getNumber() * 0.6f);
        }
    }
}
