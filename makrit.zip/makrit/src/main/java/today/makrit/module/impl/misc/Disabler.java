package today.makrit.module.impl.misc;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.PacketSentEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;

import java.util.Timer;
import java.util.TimerTask;

public class Disabler extends Module {
    private Timer timer;

    public Disabler() {
        super("Disabler", ModuleCategory.MISC, 0);
        this.toggle();
    }

    @Override
    public void onEnable() {
        super.onEnable();
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
            }
        }, 0, 15 * 1000);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (timer != null) {
            timer.cancel();
        }
    }

    @Subscribe
    public void onTick(PacketSentEvent ev) {
        if (ev.getPacket() instanceof com.craftrise.iU) {
            ev.cancel();
        }
        if (ev.getPacket() instanceof cr.D) {
            ev.cancel();
        }
        if (ev.getPacket() instanceof com.craftrise.dc)
        {
            ev.cancel();
        }
        if (ev.getPacket() instanceof craftrise.eF) {
            ev.cancel();
        }
        if (ev.getPacket() instanceof com.craftrise.fD) {
            ev.cancel();
        }
        if (ev.getPacket().toString().contains("com.craftrise.lE@")) {
            ev.cancel();
        } else if (ev.getPacket().toString().contains("com.craftrise.lE$a@")) {
        } else if (ev.getPacket().toString().contains("com.craftrise.lE$c@")) {
        }
    }
}
