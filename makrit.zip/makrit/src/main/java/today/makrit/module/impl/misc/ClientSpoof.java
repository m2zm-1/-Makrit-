package today.makrit.module.impl.misc;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.DoubleSetting;
import com.craftrise.Z;
import cr.launcher.Config;
import cr.launcher.main.a;

@SuppressWarnings("unused")
public class ClientSpoof extends Module {
    private static cr.g d;
    private DoubleSetting amount = new DoubleSetting("Timer Speed", 1.5f, 0.1f, 3.0f);

    public ClientSpoof() {
        super("ClientSpoof", ModuleCategory.MISC, 0);
        settings.add(amount);
        this.toggle();
    }

    @Subscribe
    public void render(RenderEvent event) {
        Config.getMinecraft().bu.H.stream().filter(player -> player != a.q).forEach(player -> {
            player.i(Z.L.k.a(5L), 5L);
            a.a(false, 5L);
        });
    }
}
