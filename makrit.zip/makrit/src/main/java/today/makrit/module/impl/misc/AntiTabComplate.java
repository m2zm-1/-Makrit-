package today.makrit.module.impl.misc;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.PacketSentEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import com.craftrise.jB;
import com.craftrise.p4;

public class AntiTabComplate extends Module {

    public AntiTabComplate() {
        super("AntiTabComplate", ModuleCategory.MISC, 0);
    }
    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscribe
    public void onTick(PacketSentEvent ev) {
        if (ev.getPacket() instanceof p4) {
            ev.cancel();
        }
        if (ev.getPacket() instanceof jB) {
            ev.cancel();
        }
    }
}
