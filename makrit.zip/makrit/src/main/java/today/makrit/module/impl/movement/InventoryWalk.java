package today.makrit.module.impl.movement;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.NumberSetting;
import today.makrit.utils.Timer;
import cr.launcher.Config;
import org.lwjgl.input.Keyboard;

import java.lang.reflect.Field;

public class InventoryWalk extends Module {
    private static final NumberSetting delay = new NumberSetting("Delay Second", 10, 1, 32);
    public Timer timer = new Timer();
    private boolean inventoryWalking = false;

    public InventoryWalk() {
        super("Inv Walk", ModuleCategory.PLAYER, 0);
        this.toggle();
    }

    private static void setKeybind(boolean value, com.craftrise.client.gR keybind) {
        try {
            Class<?> EntityClazz = Class.forName("com.craftrise.client.gR");
            Field field = EntityClazz.getDeclaredField("b");
            field.setAccessible(true);
            field.set(keybind, value);
        } catch (Exception e) {
            Config.warn(e.getMessage() + " Exception");
        }
    }

    private static boolean isKeyPressed(int keyCode) {
        return Keyboard.isKeyDown(keyCode);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        startInventoryWalking();
    }

    @Subscribe
    public void render(RenderEvent e) {
        if (inventoryWalking) {
            updateKeyState(Keyboard.KEY_W, 0);
            updateKeyState(Keyboard.KEY_A, 1);
            updateKeyState(Keyboard.KEY_S, 2);
            updateKeyState(Keyboard.KEY_D, 3);
            updateKeyState(Keyboard.KEY_SPACE, 4);
        }
    }

    private void updateKeyState(int keyCode, int index) {
        if (isKeyPressed(keyCode)) {
            setKeybind(true, getKeybindByIndex(index));
        } else {
            setKeybind(false, getKeybindByIndex(index));
        }
    }

    private com.craftrise.client.gR getKeybindByIndex(int index) {
        switch (index) {
            case 0:
                return Config.getGameSettings().bz;
            case 1:
                return Config.getGameSettings().D;
            case 2:
                return Config.getGameSettings().a8;
            case 3:
                return Config.getGameSettings().bO;
            case 4:
                return Config.getGameSettings().bM;
            default:
                throw new IllegalArgumentException("Invalid keybind index");
        }
    }

    private void startInventoryWalking() {
        inventoryWalking = true;
    }

    private void stopInventoryWalking() {
        inventoryWalking = false;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        stopInventoryWalking();
    }
}
