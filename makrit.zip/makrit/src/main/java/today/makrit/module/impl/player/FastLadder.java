package today.makrit.module.impl.player;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.DoubleSetting;
import today.makrit.module.setting.ModeSetting;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import com.craftrise.dR;
import cr.launcher.BlockPos;
import cr.launcher.main.a;

import java.lang.reflect.Method;

public class FastLadder extends Module {
    private ModeSetting mode = new ModeSetting("Mode", "AAC", "AAC");
    private DoubleSetting speed = new DoubleSetting("Speed", 0.5f, 0.1f, 3.0f);

    public FastLadder() {
        super("FastLadder", ModuleCategory.MOVEMENT, 0);
        settings.add(mode);
        settings.add(speed);
    }
    public static int[] blocks;
    public Timer timer = new Timer();
    static {
        FastLadder.blocks = new int[]{53, 67, 108, 109, 114, 128, 134, 135, 136, 156, 163, 164, 180, 203};
    }
    public static void SetPosition(double x, double y, double z){
        try{
            Class<?> Entity = com.craftrise.m9.class;
            Method setPosition = Entity.getMethod("b",double.class,double.class,double.class,long.class);
            setPosition.invoke(a.q,x,y,z,5L);
        }
        catch (Exception e){
            e.printStackTrace();
        }

    }

    @Subscribe
    public void render(RenderEvent re) {
        if (timer.hasTimeElapsed(1000 / 50, true)) {
            final BlockPos blockPos = new BlockPos(ThePlayer.GetPosX(), ThePlayer.GetPosY(), ThePlayer.GetprevPosZ());
            if(a.q.N()) {
                a.q.aT = new dR(speed.getNumber());
            }
            if (Minecraft.getBlockID(blockPos) == 65) {
                if(ThePlayer.isMoving()) {
                    double y = ThePlayer.GetPosY();
                    ThePlayer.setPosition_mid(ThePlayer.GetPosX(), y + 0.169, ThePlayer.GetPosZ());
                }
            }
            int blockID = Minecraft.getBlockID(blockPos);
            for (int validBlock : FastLadder.blocks) {
                if (blockID == validBlock) {
                    double x = ThePlayer.GetMotionX();
                    double z = ThePlayer.GetMotionZ();
                    double y = ThePlayer.GetPosY();
                    ThePlayer.setPosition_mid(ThePlayer.GetPosX(), y + 0.169, ThePlayer.GetPosZ());
                    ThePlayer.SetMotionX(x * 0.9f);
                    ThePlayer.SetMotionZ(z * 0.9f);
                    ThePlayer.SetMotionY(0.8f);
                    break;
                }
            }
        }
    }
}