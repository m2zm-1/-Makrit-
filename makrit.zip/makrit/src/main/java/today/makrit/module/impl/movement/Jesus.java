package today.makrit.module.impl.movement;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.ModeSetting;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import cr.launcher.BlockPos;

public class Jesus extends Module {
    private ModeSetting mode = new ModeSetting("Mode", "AAC", "AAC");

    public Jesus() {
        super("Jesus", ModuleCategory.MOVEMENT, 0);
        settings.add(mode);
    }

    public Timer timer = new Timer();

    float degreesToRadians(float degrees) {
        return degrees * (3.14159265358979323846f / 180.0f);
    }

    @Subscribe
    public void render(RenderEvent re) {
        if (timer.hasTimeElapsed(1000 / 50, true)) {
            final BlockPos blockPos = new BlockPos(ThePlayer.GetPosX(), ThePlayer.GetPosY(), ThePlayer.GetprevPosZ());
            if (Minecraft.getBlockID(blockPos) == 8) {
                double x = ThePlayer.GetMotionX();
                double z = ThePlayer.GetMotionZ();
                double y = ThePlayer.GetPosY();
                double shotSpeed = Math.sqrt(x * x + z * z);
                float rotationYaw = ThePlayer.GetrotationYaw();
                if (Minecraft.GetPlayer().l.b.a(5L) < 0.0f) {
                    rotationYaw += 180.0f;
                }
                float f2 = 1.0f;
                if (Minecraft.GetPlayer().l.b.a(5L) < 0.0f) {
                    f2 = -0.5f;
                } else if (Minecraft.GetPlayer().l.b.a(5L) > 0.0f) {
                    f2 = 0.5f;
                }
                if (Minecraft.GetPlayer().l.c.a(5L) > 0.0f) {
                    rotationYaw -= 90.0f * f2;
                }
                if (Minecraft.GetPlayer().l.c.a(5L) < 0.0f) {
                    rotationYaw += 90.0f * f2;
                }
                double direction = degreesToRadians(rotationYaw);
                ThePlayer.setPosition_mid(ThePlayer.GetPosX(), y + 0.1, ThePlayer.GetPosZ());
                ThePlayer.setPosition_mid(ThePlayer.GetPosX(), y + -0.1, ThePlayer.GetPosZ());
                ThePlayer.setPosition_mid(ThePlayer.GetPosX(), y + 0.1, ThePlayer.GetPosZ());
                ThePlayer.SetMotionX(-Math.sin(direction) * shotSpeed);
                ThePlayer.SetMotionZ(Math.cos(direction) * shotSpeed);
                ThePlayer.SetMotionY(0.0f);
            }
            if (Minecraft.getBlockID(blockPos) == 9) {
                double x = ThePlayer.GetMotionX();
                double z = ThePlayer.GetMotionZ();
                double y = ThePlayer.GetPosY();
                double shotSpeed = Math.sqrt(x * x + z * z);
                float rotationYaw = ThePlayer.GetrotationYaw();
                if (Minecraft.GetPlayer().l.b.a(5L) < 0.0f) {
                    rotationYaw += 180.0f;
                }
                float f2 = 1.0f;
                if (Minecraft.GetPlayer().l.b.a(5L) < 0.0f) {
                    f2 = -0.5f;
                } else if (Minecraft.GetPlayer().l.b.a(5L) > 0.0f) {
                    f2 = 0.5f;
                }
                if (Minecraft.GetPlayer().l.c.a(5L) > 0.0f) {
                    rotationYaw -= 90.0f * f2;
                }
                if (Minecraft.GetPlayer().l.c.a(5L) < 0.0f) {
                    rotationYaw += 90.0f * f2;
                }
                double direction = degreesToRadians(rotationYaw);
                ThePlayer.setPosition_mid(ThePlayer.GetPosX(), y + 0.1, ThePlayer.GetPosZ());
                ThePlayer.setPosition_mid(ThePlayer.GetPosX(), y + -0.1, ThePlayer.GetPosZ());
                ThePlayer.setPosition_mid(ThePlayer.GetPosX(), y + 0.1, ThePlayer.GetPosZ());
                ThePlayer.SetMotionX(-Math.sin(direction) * shotSpeed);
                ThePlayer.SetMotionZ(Math.cos(direction) * shotSpeed);
                ThePlayer.SetMotionY(0.0f);
            }
            if (Minecraft.getBlockID(blockPos) == 10) {
                double x = ThePlayer.GetMotionX();
                double z = ThePlayer.GetMotionZ();
                double y = ThePlayer.GetPosY();
                double shotSpeed = Math.sqrt(x * x + z * z);
                float rotationYaw = ThePlayer.GetrotationYaw();
                if (Minecraft.GetPlayer().l.b.a(5L) < 0.0f) {
                    rotationYaw += 180.0f;
                }
                float f2 = 1.0f;
                if (Minecraft.GetPlayer().l.b.a(5L) < 0.0f) {
                    f2 = -0.5f;
                } else if (Minecraft.GetPlayer().l.b.a(5L) > 0.0f) {
                    f2 = 0.5f;
                }
                if (Minecraft.GetPlayer().l.c.a(5L) > 0.0f) {
                    rotationYaw -= 90.0f * f2;
                }
                if (Minecraft.GetPlayer().l.c.a(5L) < 0.0f) {
                    rotationYaw += 90.0f * f2;
                }
                double direction = degreesToRadians(rotationYaw);
                ThePlayer.setPosition_mid(ThePlayer.GetPosX(), y + 0.2, ThePlayer.GetPosZ());
                ThePlayer.setPosition_mid(ThePlayer.GetPosX(), y + -0.1, ThePlayer.GetPosZ());
                ThePlayer.setPosition_mid(ThePlayer.GetPosX(), y + 0.1, ThePlayer.GetPosZ());
                ThePlayer.SetMotionX(-Math.sin(direction) * shotSpeed);
                ThePlayer.SetMotionZ(Math.cos(direction) * shotSpeed);
                ThePlayer.SetMotionY(0.0f);
            }
            if (Minecraft.getBlockID(blockPos) == 11) {
                double x = ThePlayer.GetMotionX();
                double z = ThePlayer.GetMotionZ();
                double y = ThePlayer.GetPosY();
                double shotSpeed = Math.sqrt(x * x + z * z);
                float rotationYaw = ThePlayer.GetrotationYaw();
                if (Minecraft.GetPlayer().l.b.a(5L) < 0.0f) {
                    rotationYaw += 180.0f;
                }
                float f2 = 1.0f;
                if (Minecraft.GetPlayer().l.b.a(5L) < 0.0f) {
                    f2 = -0.5f;
                } else if (Minecraft.GetPlayer().l.b.a(5L) > 0.0f) {
                    f2 = 0.5f;
                }
                if (Minecraft.GetPlayer().l.c.a(5L) > 0.0f) {
                    rotationYaw -= 90.0f * f2;
                }
                if (Minecraft.GetPlayer().l.c.a(5L) < 0.0f) {
                    rotationYaw += 90.0f * f2;
                }
                double direction = degreesToRadians(rotationYaw);
                ThePlayer.setPosition_mid(ThePlayer.GetPosX(), y + 0.2, ThePlayer.GetPosZ());
                ThePlayer.setPosition_mid(ThePlayer.GetPosX(), y + -0.1, ThePlayer.GetPosZ());
                ThePlayer.setPosition_mid(ThePlayer.GetPosX(), y + 0.1, ThePlayer.GetPosZ());
                ThePlayer.SetMotionX(-Math.sin(direction) * shotSpeed);
                ThePlayer.SetMotionZ(Math.cos(direction) * shotSpeed);
                ThePlayer.SetMotionY(0.0f);
            }
        }
    }
}