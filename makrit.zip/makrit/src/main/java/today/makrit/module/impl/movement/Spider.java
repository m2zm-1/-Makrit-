package today.makrit.module.impl.movement;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.RenderEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.utils.Timer;
import today.makrit.utils.mapper.ThePlayer;

public class Spider extends Module {

    public Spider() {
        super("Spider", ModuleCategory.MOVEMENT, 0);
    }

    public Timer timer = new Timer();

    @Subscribe
    public void render(RenderEvent re) {
        if (timer.hasTimeElapsed(350, true)) {
            if (ThePlayer.isCollidedHorizontally()) {
                if (!ThePlayer.onGround() && ThePlayer.isCollidedVertically()) {
                    return;
                }
                if (ThePlayer.GetticksExisted % 3 == 0) {
                    ThePlayer.SetMotionY(0.42f);
                }
            }
        }
    }
}
