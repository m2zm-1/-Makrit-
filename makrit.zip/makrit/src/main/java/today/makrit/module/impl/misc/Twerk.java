package today.makrit.module.impl.misc;

import com.google.common.eventbus.Subscribe;
import cr.launcher.Config;
import today.makrit.event.impl.PacketSentEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.module.setting.DoubleSetting;
import today.makrit.utils.TimerUtils;
import today.makrit.utils.mapper.Minecraft;

import java.lang.reflect.Field;

public class Twerk extends Module {

    public Twerk() {
        super("Twerk", ModuleCategory.MISC, 0);
    }

    @Subscribe
    public void onTick(PacketSentEvent ev) {
        setPressed(upp);

        if (onTwerk.passedMillis((long) twerkDelay.getNumber()) && !upp) {
            onTwerk.reset();
            upp = true;
        }

        if (onTwerk.passedMillis((long) twerkDelay.getNumber()) && upp) {
            onTwerk.reset();
            upp = false;
        }

    }
    private static final DoubleSetting twerkDelay = new DoubleSetting("Delay", 1.5, 0.1, 20.0);
    public static com.craftrise.client.gR keybindSneak = Config.getGameSettings().a4;
    public static void setPressed(boolean value){
        try {
            Class EntityClazz = Class.forName("com.craftrise.client.gR");
            for(Field f : EntityClazz.getDeclaredFields()) {
                if(f.getName().equals("b")) {
                    f.setAccessible(true);
                    f.set(keybindSneak, value);
                }
            }
        } catch (Exception e) {
            Minecraft.addChatMessage(e.toString() + " Exception");
        }
    }
    private boolean upp = false;
    public TimerUtils onTwerk = new TimerUtils();
}