package today.makrit.module.impl.misc;

import com.google.common.eventbus.Subscribe;
import today.makrit.event.impl.PacketSentEvent;
import today.makrit.module.Module;
import today.makrit.module.ModuleCategory;
import today.makrit.utils.mapper.Minecraft;
import com.craftrise.gP;

public class LightningTracker extends Module {

    public LightningTracker() {
        super("LightningTracker", ModuleCategory.MISC, 0);
    }
    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscribe
    public void onTick(PacketSentEvent ev) {
        if (ev.getPacket() instanceof gP) {
            gP soundPacket = ((gP) ev.getPacket());
            if (soundPacket.a().equals("ambient.weather.thunder")) {
                Minecraft.addChatMessage(String.format("Lightning detected at (%s, %s, %s)", (int) soundPacket.c(), (int) soundPacket.b(), (int) 0));
            }
        }
    }
}
