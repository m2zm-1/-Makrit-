package today.makrit.module;

public enum ModuleCategory {
    COMBAT,
    MOVEMENT,
    PLAYER,
    RENDER,
    MISC,
    WORLD
}
