package today.makrit.module.setting;

public class DoubleSetting extends Setting {
   public int increment = 1;
   private double number;
   private double min;
   private double max;
   public double renderPercentage;
   public double percentage;

   public DoubleSetting(String name, double value, double min, double max) {
      super(name);
      this.number = this.round(value);
      this.min = min;
      this.max = max;
   }

   private double round(double value) {
      int precision = 2;
      double scale = Math.pow(10.0D, (double)precision);
      return (double)Math.round(value * scale) / scale;
   }

   public double getMax() {
      return this.max;
   }

   public double getMin() {
      return this.min;
   }

   public double getNumber() {
      return this.number;
   }

   public void setNumber(double number) {
      this.number = this.round(number);
   }

   public int getIncrement() {
      return this.increment;
   }

   public double getInc() {
      return 1.0D;
   }
}
