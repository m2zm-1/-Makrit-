package today.makrit.font;

import today.makrit.utils.Renderer.MinecraftFontRenderer;

import java.awt.Font;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class FontUtil {
   public static volatile int completed;
   public static MinecraftFontRenderer product_sans;
   public static MinecraftFontRenderer comfortaaBold20;
   public static MinecraftFontRenderer comfortaa16;
   public static MinecraftFontRenderer comfortaa18;
   public static MinecraftFontRenderer iconfont20;
   public static MinecraftFontRenderer fontRise28;
   public static MinecraftFontRenderer fontRise22;
   public static MinecraftFontRenderer fontRise18;
   public static MinecraftFontRenderer tenacityFont18;
   public static MinecraftFontRenderer iconfont40;
   public static MinecraftFontRenderer iconfont35;
   public static MinecraftFontRenderer sf17;
   public static MinecraftFontRenderer SFBOLD_26;
   public static MinecraftFontRenderer tahoma18;
   public static MinecraftFontRenderer tahoma16;
   public static MinecraftFontRenderer tahoma14;
   public static MinecraftFontRenderer icon24novo;
   public static MinecraftFontRenderer iconfont16;
   public static MinecraftFontRenderer comfortaa22;
   public static MinecraftFontRenderer sf22;
   public static MinecraftFontRenderer sf20;
   public static MinecraftFontRenderer sf16;
   public static MinecraftFontRenderer sf18;
   public static MinecraftFontRenderer SFBOLD_22;
   public static MinecraftFontRenderer apple18;
   public static MinecraftFontRenderer tenacityBoldFont20;
   public static MinecraftFontRenderer tenacityFont20;
   private static Font product_sans_;
   private static Font comfortaaBold20_;
   private static Font comfortaa18_;
   private static Font tenacityBoldFont20_;
   private static Font tenacityFont20_;
   private static Font tenacityFont18_;
   private static Font apple18_;
   private static Font comfortaa22_;
   private static Font comfortaa16_;
   private static Font tahoma14_;
   private static Font tahoma16_;
   private static Font fontRise18_;
   private static Font fontRise22_;
   private static Font fontRise28_;
   private static Font tahoma18_;
   private static Font iconfont20_;
   private static Font iconfont16_;
   private static Font iconfont40_;
   private static Font sf20_;
   private static Font sf22_;
   private static Font sf17_;
   private static Font sf18_;
   private static Font sf16_;
   private static Font icon24novo_;
   public static Font SFBOLD_26_;
   public static Font SFBOLD_22_;
   public static Font iconfont35_;
   public static final String BUG = "a";
   public static final String LIST = "b";
   public static final String BOMB = "c";
   public static final String EYE = "d";
   public static final String PERSON = "e";
   public static final String WHEELCHAIR = "f";
   public static final String SCRIPT = "g";
   public static final String SKIP_LEFT = "h";
   public static final String PAUSE = "i";
   public static final String PLAY = "j";
   public static final String SKIP_RIGHT = "k";
   public static final String SHUFFLE = "l";
   public static final String INFO = "m";
   public static final String SETTINGS = "n";
   public static final String CHECKMARK = "o";
   public static final String XMARK = "p";
   public static final String TRASH = "q";
   public static final String WARNING = "r";
   public static final String FOLDER = "s";
   public static final String LOAD = "t";
   public static final String SAVE = "u";
   public static final String UPVOTE_OUTLINE = "v";
   public static final String UPVOTE = "w";
   public static final String DOWNVOTE_OUTLINE = "x";
   public static final String DOWNVOTE = "y";
   public static final String DROPDOWN_ARROW = "z";
   public static final String PIN = "s";
   public static final String EDIT = "A";
   public static final String SEARCH = "B";
   public static final String UPLOAD = "C";
   public static final String REFRESH = "D";
   public static final String ADD_FILE = "E";
   public static final String STAR_OUTLINE = "F";
   public static final String STAR = "G";

   private static Font getFont(Map<String, Font> locationMap, String location, int size) {
      Font font = null;

      try {
         if (locationMap.containsKey(location)) {
            font = ((Font)locationMap.get(location)).deriveFont(0, (float)size);
         } else {
            String fontPath = "D:" + location;
            File fontFile = new File(fontPath);
            InputStream is = new FileInputStream(fontFile);
            font = Font.createFont(0, is);
            locationMap.put(location, font);
            font = font.deriveFont(0, (float)size);
         }
      } catch (Exception var7) {
         var7.printStackTrace();
         System.out.println("Error loading font");
         font = new Font("default", 0, 10);
      }

      return font;
   }

   private static InputStream getInputStreamFromResource(String resourcePath) throws IOException {
      ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
      InputStream inputStream = classLoader.getResourceAsStream(resourcePath);
      if (inputStream == null) {
         throw new IOException("Resource not found: " + resourcePath);
      } else {
         return inputStream;
      }
   }

   public static boolean hasLoaded() {
      return completed >= 3;
   }

   public static void bootstrap() {
      (new Thread(() -> {
         Map<String, Font> locationMap = new HashMap();
         product_sans_ = getFont(locationMap, "product_sans.ttf", 21);
         comfortaaBold20_ = getFont(locationMap, "comfortaabold.ttf", 20);
         comfortaa18_ = getFont(locationMap, "comfortaa.ttf", 18);
         apple18_ = getFont(locationMap, "apple.ttf", 18);
         comfortaa22_ = getFont(locationMap, "comfortaa.ttf", 22);
         comfortaa16_ = getFont(locationMap, "comfortaa.ttf", 16);
         iconfont20_ = getFont(locationMap, "icon.ttf", 20);
         iconfont40_ = getFont(locationMap, "icon.ttf", 40);
         tenacityBoldFont20_ = getFont(locationMap, "tenacitybold.ttf", 20);
         fontRise22_ = getFont(locationMap, "fontrise.ttf", 22);
         fontRise28_ = getFont(locationMap, "fontrise.ttf", 28);
         fontRise18_ = getFont(locationMap, "fontrise.ttf", 18);
         tenacityFont18_ = getFont(locationMap, "tenacity.ttf", 18);
         iconfont16_ = getFont(locationMap, "icon.ttf", 20);
         tahoma14_ = getFont(locationMap, "tahoma.ttf", 14);
         tahoma18_ = getFont(locationMap, "tahoma.ttf", 18);
         tahoma16_ = getFont(locationMap, "tahoma.ttf", 16);
         iconfont35_ = getFont(locationMap, "icon.ttf", 35);
         tenacityFont20_ = getFont(locationMap, "tenacity.ttf", 20);
         sf17_ = getFont(locationMap, "SF.ttf", 17);
         sf20_ = getFont(locationMap, "SF.ttf", 20);
         SFBOLD_26_ = getFont(locationMap, "SFBOLD.ttf", 26);
         SFBOLD_22_ = getFont(locationMap, "SFBOLD.ttf", 22);
         sf22_ = getFont(locationMap, "SF.ttf", 22);
         icon24novo_ = getFont(locationMap, "iconnovo.ttf", 24);
         sf16_ = getFont(locationMap, "SF.ttf", 16);
         sf18_ = getFont(locationMap, "SF.ttf", 18);
         ++completed;
      })).start();
      (new Thread(() -> {
         new HashMap();
         ++completed;
      })).start();
      (new Thread(() -> {
         new HashMap();
         ++completed;
      })).start();

      while(!hasLoaded()) {
         try {
            Thread.sleep(5L);
         } catch (InterruptedException var1) {
            var1.printStackTrace();
         }
      }

      product_sans = new MinecraftFontRenderer(product_sans_, true, true);
      comfortaaBold20 = new MinecraftFontRenderer(comfortaaBold20_, true, true);
      comfortaa18 = new MinecraftFontRenderer(comfortaa18_, true, true);
      apple18 = new MinecraftFontRenderer(apple18_, true, true);
      comfortaa16 = new MinecraftFontRenderer(comfortaa16_, true, true);
      tenacityBoldFont20 = new MinecraftFontRenderer(tenacityBoldFont20_, true, true);
      tenacityFont20 = new MinecraftFontRenderer(tenacityFont20_, true, true);
      tenacityFont18 = new MinecraftFontRenderer(tenacityFont18_, true, true);
      comfortaa22 = new MinecraftFontRenderer(comfortaa22_, true, true);
      iconfont20 = new MinecraftFontRenderer(iconfont20_, true, true);
      iconfont40 = new MinecraftFontRenderer(iconfont40_, true, true);
      sf22 = new MinecraftFontRenderer(sf22_, true, true);
      sf20 = new MinecraftFontRenderer(sf20_, true, true);
      sf16 = new MinecraftFontRenderer(sf16_, true, true);
      sf18 = new MinecraftFontRenderer(sf18_, true, true);
      icon24novo = new MinecraftFontRenderer(icon24novo_, true, true);
      iconfont16 = new MinecraftFontRenderer(iconfont16_, true, true);
      iconfont35 = new MinecraftFontRenderer(iconfont35_, true, true);
      SFBOLD_26 = new MinecraftFontRenderer(SFBOLD_26_, true, true);
      fontRise22 = new MinecraftFontRenderer(fontRise22_, true, true);
      fontRise18 = new MinecraftFontRenderer(fontRise18_, true, true);
      fontRise28 = new MinecraftFontRenderer(fontRise28_, true, true);
      SFBOLD_22 = new MinecraftFontRenderer(SFBOLD_22_, true, true);
      sf17 = new MinecraftFontRenderer(sf17_, true, true);
      tahoma14 = new MinecraftFontRenderer(tahoma14_, true, true);
      tahoma16 = new MinecraftFontRenderer(tahoma16_, true, true);
      tahoma18 = new MinecraftFontRenderer(tahoma18_, true, true);
   }
}
