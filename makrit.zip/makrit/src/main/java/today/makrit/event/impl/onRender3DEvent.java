package today.makrit.event.impl;

import today.makrit.event.Event;

public class onRender3DEvent extends Event {
}
