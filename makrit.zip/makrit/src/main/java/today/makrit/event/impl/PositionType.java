package today.makrit.event.impl;

public enum PositionType {

    C03, C04, C05, C06;

}