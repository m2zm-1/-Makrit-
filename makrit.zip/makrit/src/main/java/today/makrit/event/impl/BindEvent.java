package today.makrit.event.impl;

import today.makrit.event.Event;

public class BindEvent extends Event {
   private final int keyCode;
   private final String keyName;
   private final int module;

   public BindEvent(int module, int keyCode, String keyName) {
      this.module = module;
      this.keyCode = keyCode;
      this.keyName = keyName;
   }

   public String getKeyName() {
      return this.keyName;
   }

   public int getKeyCode() {
      return this.keyCode;
   }

   public int getModule() {
      return this.module;
   }
}
