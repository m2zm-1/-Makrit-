package today.makrit.event.impl;

import today.makrit.event.Event;

public class EventNameTagRender extends Event {
}
