package today.makrit.event.impl;

import today.makrit.event.Event;

public class TickEvent extends Event {
}
