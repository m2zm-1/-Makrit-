package today.makrit.event.impl;

public interface EventListener<T>
{
    void call(T event);
}
