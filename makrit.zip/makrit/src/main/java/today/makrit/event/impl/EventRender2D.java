package today.makrit.event.impl;

import today.makrit.event.Event;

public class EventRender2D extends Event {
}