package today.makrit.event;

public class Event {
    public boolean cancelled = false;
    private Type type;
    public void setType(Type type)
    {
        this.type = type;
    }
    public enum Type
    {
        PRE, POST
    }

    public void cancel() {
        cancelled = true;
    }
}
