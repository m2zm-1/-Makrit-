package today.makrit.event.impl;

import today.makrit.event.Event;

public class drawStringEvent extends Event {
}
