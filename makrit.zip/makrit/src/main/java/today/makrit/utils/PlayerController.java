package today.makrit.utils;

import com.craftrise.gM;
import com.craftrise.k3;
import com.craftrise.lG;
import com.craftrise.client.S;
import com.craftrise.client.c9;
import com.craftrise.client.ez;
import cr.launcher.BlockPos;
import today.makrit.utils.mapper.Minecraft;

public class PlayerController extends ez {
   public PlayerController(ez playerControllerMP) {
      super((S)null, (c9)null);
      ReflectFields.copyNonStaticField((Object)this, playerControllerMP);
   }

   public boolean onPlayerRightClickPlayer(gM itemStack, BlockPos blockPos, lG enumFacing, k3 vec3) {
      return super.onPlayerRightClick(Minecraft.GetPlayer(), Minecraft.GetWorld(), itemStack, blockPos, enumFacing, vec3);
   }

   public static boolean onPlayerRightClick(gM itemStack, BlockPos blockPos, lG enumFacing, k3 vec3) {
      ez playerController = Minecraft.getPlayerController2();
      return playerController instanceof PlayerController ? ((PlayerController)playerController).onPlayerRightClickPlayer(itemStack, blockPos, enumFacing, vec3) : playerController.onPlayerRightClick(Minecraft.GetPlayer(), Minecraft.GetWorld(), itemStack, blockPos, enumFacing, vec3);
   }
}
