package today.makrit.utils.Renderer;

public enum ThemeType {
    ARRAYLIST,
    LOGO,
    FLAT_COLOR,
    GENERAL,
}
