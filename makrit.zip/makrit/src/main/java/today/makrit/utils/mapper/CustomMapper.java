package today.makrit.utils.mapper;

import com.craftrise.ah;
import com.craftrise.b3;
import com.craftrise.dN;
import com.craftrise.dR;
import com.craftrise.de;
import com.craftrise.gM;
import com.craftrise.k3;
import com.craftrise.lG;
import com.craftrise.lU;
import com.craftrise.m9;
import com.craftrise.mg;
import com.craftrise.pI;
import com.craftrise.qJ;
import com.craftrise.client.S;
import com.craftrise.client.cf;
import com.craftrise.client.d0;
import com.craftrise.client.dG;
import com.craftrise.client.dt;
import com.craftrise.client.ez;
import com.craftrise.client.fV;
import com.craftrise.client.fa;
import com.craftrise.client.g8;
import com.craftrise.client.gR;
import com.craftrise.client.y;
import cr.p;
import cr.launcher.BlockPos;
import cr.launcher.Config;
import cr.launcher.IChatComponent;
import cr.launcher.main.a;
import today.makrit.Main;
import today.makrit.module.ModuleManager;
import today.makrit.utils.BlockHelper;
import today.makrit.utils.EffectRenderer;
import today.makrit.utils.PlayerController;
import today.makrit.utils.proutils;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import net.minecraft.util.Vec3;

public class CustomMapper {
   public static gR keybindSneak;
   public static m9 targetForROT;
   public static int GetticksExisted;
   private CustomMapper.AxisAlignedBB boundingBox;

   public static fa GetPlayer() {
      return a.q;
   }

   public static S GetMinecraft() {
      return Config.getMinecraft();
   }

   public static cf GetWorld() {
      return GetMinecraft().bu;
   }

   public static String getCommandSenderName(Object paramObject) {
      String str = null;

      try {
         Class<?> clazz = Class.forName("com.craftrise.client.f1");
         Method[] var3 = clazz.getDeclaredMethods();
         int var4 = var3.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            Method method = var3[var5];
            if (method.getName().equals("a") && method.getParameterCount() == 0 && method.getReturnType().toString().contains("(J)Ljava/lang/String")) {
               method.setAccessible(true);
               str = (String)method.invoke(paramObject);
            }
         }
      } catch (IllegalAccessException | InvocationTargetException | ClassNotFoundException var7) {
         addChatMessage(var7.toString());
      }

      return str;
   }

   public static void addChatMessage(String paramString) {
      try {
         paramString = String.format(">>%s", paramString);
         Class<?> clazz1 = Class.forName("com.craftrise.client.fa");
         Class[] arrayOfClass1 = new Class[]{IChatComponent.class, Long.TYPE};
         Method method1 = clazz1.getDeclaredMethod("a", arrayOfClass1);
         clazz1.getDeclaredMethod("a", arrayOfClass1);
         Class[] var10000 = new Class[]{IChatComponent.class, Long.TYPE};
         Class<?> clazz2 = Class.forName("cr.launcher.ChatComponentText");
         Constructor<?> constructor = clazz2.getConstructor(String.class);
         Object object = constructor.newInstance(paramString);
         method1.invoke(GetPlayer(), object, Main.idk);
      } catch (Exception var9) {
         Config.warn("Exception: " + var9.getMessage());
      }

   }

   public static void addChatMessageNoText(String paramString) {
      try {
         paramString = String.format("%s", paramString);
         Class<?> clazz1 = Class.forName("com.craftrise.client.fa");
         Class[] arrayOfClass1 = new Class[]{IChatComponent.class, Long.TYPE};
         Method method1 = clazz1.getDeclaredMethod("a", arrayOfClass1);
         clazz1.getDeclaredMethod("a", arrayOfClass1);
         Class[] var10000 = new Class[]{IChatComponent.class, Long.TYPE};
         Class<?> clazz2 = Class.forName("cr.launcher.ChatComponentText");
         Constructor<?> constructor = clazz2.getConstructor(String.class);
         Object object = constructor.newInstance(paramString);
         method1.invoke(GetPlayer(), object, Main.idk);
      } catch (Exception var9) {
         Config.warn("Exception: " + var9.getMessage());
      }

   }

   public static qJ openContainer(mg parammg) {
      return parammg.T;
   }

   public static float GetDistanceToEntity(m9 paramm9) {
      try {
         float f1 = (float)(GetPlayer().bE - paramm9.bE);
         float f2 = (float)(GetPlayer().aY - paramm9.aY);
         float f3 = (float)(GetPlayer().bH - paramm9.bH);
         String str1 = "com.craftrise.pj";
         String str2 = "d";
         Class<?> clazz = Class.forName(str1);
         Method method = clazz.getMethod(str2, Float.TYPE);
         Object object = method.invoke(paramm9, f1 * f1 + f2 * f2 + f3 * f3);
         return ((Number)object).floatValue();
      } catch (Exception var9) {
         addChatMessage("Distance error: " + var9.toString());
         return -1.0F;
      }
   }

   public static float[] getDirectionToEntity(m9 paramm9) throws InvocationTargetException, NoSuchMethodException, IllegalAccessException {
      return new float[]{getYaw(paramm9) + GetrotationYaw(), getPitch(paramm9) + GetRotationPitch()};
   }

   public static float sqrt_double(double paramDouble) {
      return (float)Math.sqrt(paramDouble);
   }

   public static float wrapAngleTo180_float(float paramFloat) {
      paramFloat %= 360.0F;
      if (paramFloat >= 180.0F) {
         paramFloat -= 360.0F;
      }

      if (paramFloat < -180.0F) {
         paramFloat += 360.0F;
      }

      return paramFloat;
   }

   public float prevRotationYaw() {
      return GetPlayer().C;
   }

   public float prevRotationPitch() {
      return GetPlayer().aM;
   }

   public static float getYaw(m9 paramm9) {
      double d1 = paramm9.bE - GetPosX();
      double d2 = paramm9.bH - GetPosZ();
      double d4 = Math.toDegrees(Math.atan(d2 / d1));
      double d3;
      if (d2 < 0.0D && d1 < 0.0D) {
         d3 = 90.0D + d4;
      } else if (d2 < 0.0D && d1 > 0.0D) {
         d3 = -90.0D + d4;
      } else {
         d3 = Math.toDegrees(-Math.atan(d1 / d2));
      }

      return wrapAngleTo180_float(-(GetrotationYaw() - (float)d3));
   }

   public static float getPitch(m9 paramm9) {
      double d1 = paramm9.bE - GetPosX();
      double d2 = paramm9.bH - GetPosZ();
      double d3 = paramm9.aY - 1.6D + (double)getEyeHeigh(paramm9) - GetPosY();
      double d4 = (double)sqrt_double(d1 * d1 + d2 * d2);
      double d5 = -Math.toDegrees(Math.atan(d3 / d4));
      return -wrapAngleTo180_float(GetRotationPitch() - (float)d5);
   }

   public static float getEyeHeigh(m9 paramm9) {
      float f = 0.0F;

      try {
         Method[] var2 = m9.class.getDeclaredMethods();
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            Method method = var2[var4];
            if (method.getName().equals("e") && method.getParameterCount() == 1 && method.getReturnType().toString().contains("float")) {
               method.setAccessible(true);
               f = (Float)method.invoke(paramm9, Main.idk);
            }
         }
      } catch (Exception var6) {
         addChatMessage(var6.toString());
      }

      return f;
   }

   public static void setRotationYaw(float paramFloat) {
      GetPlayer().bL = paramFloat;
   }

   public static double GetPosX(m9 paramm9) {
      return paramm9.bE;
   }

   public static double GetPosY(m9 paramm9) {
      return paramm9.aY;
   }

   public static double GetPosZ(m9 paramm9) {
      return paramm9.bH;
   }

   public static double GetPosX() {
      return GetPlayer().bE;
   }

   public static double GetPosY() {
      return GetPlayer().aY;
   }

   public static double GetPosZ() {
      return GetPlayer().bH;
   }

   public static void setRotationPitch(float paramFloat) {
      GetPlayer().N = paramFloat;
   }

   public static float GetrotationYaw(m9 paramm9) {
      return paramm9.bL;
   }

   public static float GetrotationYaw() {
      return GetPlayer().bL;
   }

   public static float GetRotationPitch() {
      return GetPlayer().N;
   }

   public static void setRotations(float paramFloat1, float paramFloat2) {
      setRotationYaw(paramFloat1);
      setRotationPitch(paramFloat2);
   }

   public static void rotationYawHead(float paramFloat) {
      GetPlayer().ap = paramFloat;
   }

   public static float renderYawOffset(float paramFloat) {
      GetPlayer().a = paramFloat;
      return paramFloat;
   }

   public static String getStackTraceAsString(Exception paramException) {
      StringWriter stringWriter = new StringWriter();
      PrintWriter printWriter = new PrintWriter(stringWriter);
      paramException.printStackTrace(printWriter);
      return stringWriter.toString();
   }

   public static boolean checkAdjacentAndPerformAction(gM paramgM, int paramInt1, int paramInt2, int paramInt3) {
      for(byte b = 0; b < 6; ++b) {
         int i = paramInt1;
         int j = paramInt2;
         int k = paramInt3;
         if (b == 0) {
            j = paramInt2 + 1;
         } else if (b == 1) {
            j = paramInt2 - 1;
         } else if (b == 2) {
            k = paramInt3 + 1;
         } else if (b == 3) {
            k = paramInt3 - 1;
         } else if (b == 4) {
            i = paramInt1 + 1;
         } else {
            i = paramInt1 - 1;
         }

         BlockPos blockPos = new BlockPos(i, j, k);
         if (getBlockID(blockPos) != 0) {
            if (PlayerController.onPlayerRightClick(paramgM, blockPos, lG.values()[b], new k3((double)i, (double)j, (double)k))) {
               sendSwing();
            }

            return true;
         }
      }

      return false;
   }

   public static void sendSwing() {
      try {
         Class<?> clazz = Class.forName("com.craftrise.mj");
         Method[] var1 = clazz.getDeclaredMethods();
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            Method method = var1[var3];
            if (method.getName().equals("G") && method.getParameterCount() == 1) {
               method.invoke(GetPlayer(), Main.idk);
            }
         }
      } catch (IllegalAccessException | InvocationTargetException | ClassNotFoundException var5) {
         Config.warn(var5.getMessage());
      }

   }

   public static int getBlockID(BlockPos paramBlockPos) {
      cf cf = GetWorld();
      pI pI = cf.getBlockState(paramBlockPos);
      int i = 0;
      Object object = null;

      try {
         Method[] var5 = pI.getClass().getDeclaredMethods();
         int var6 = var5.length;

         for(int var7 = 0; var7 < var6; ++var7) {
            Method method = var5[var7];
            if (method.getReturnType().toString().contains("com.craftrise.dN")) {
               method.setAccessible(true);
               object = method.invoke(pI);
               i = BlockHelper.getIdFromBlock((dN)object);
            }
         }
      } catch (Exception var9) {
         addChatMessage(var9.toString());
      }

      return i;
   }

   public static int getCurrentItemSlot(lU paramlU) {
      return paramlU.c;
   }

   public static int getCurrentItemSlot(mg parammg) {
      return getCurrentItemSlot(getInventory(parammg));
   }

   public static int getCurrentItemSlot() {
      return getCurrentItemSlot((mg)GetPlayer());
   }

   public static void setCurrentItemSlot(lU paramlU, int paramInt) {
      paramlU.c = paramInt;
   }

   public static void setCurrentItemSlot(mg parammg, int paramInt) {
      setCurrentItemSlot(getInventory(parammg), paramInt);
   }

   public static void setCurrentItemSlot(int paramInt) {
      setCurrentItemSlot((mg)GetPlayer(), paramInt);
   }

   public static gM[] getMainInventory(lU paramlU) {
      return paramlU.e;
   }

   public static gM[] getMainInventory(mg parammg) {
      return getMainInventory(getInventory(parammg));
   }

   public static gM[] getMainInventory() {
      return getMainInventory((mg)GetPlayer());
   }

   public static gM getMainInventorySlot(lU paramlU, int paramInt) {
      return getMainInventory(paramlU)[paramInt];
   }

   public static gM getMainInventorySlot(mg parammg, int paramInt) {
      return getMainInventorySlot(getInventory(parammg), paramInt);
   }

   public static gM getMainInventorySlot(int paramInt) {
      return getMainInventorySlot((mg)GetPlayer(), paramInt);
   }

   public static gM[] getArmorInventory(lU paramlU) {
      return paramlU.f;
   }

   public static gM[] getArmorInventory(mg parammg) {
      return getArmorInventory(getInventory(parammg));
   }

   public static gM[] getArmorInventory() {
      return getArmorInventory((mg)GetPlayer());
   }

   public static gM getArmorInventorySlot(lU paramlU, int paramInt) {
      return getArmorInventory(paramlU)[paramInt];
   }

   public static gM getArmorInventorySlot(mg parammg, int paramInt) {
      return getArmorInventorySlot(parammg.J, paramInt);
   }

   public static gM getArmorInventorySlot(int paramInt) {
      return getArmorInventorySlot((mg)GetPlayer(), paramInt);
   }

   public static gM getCurrentItemStack(lU paramlU) {
      return getCurrentItemSlot(paramlU) < 0 ? null : getMainInventory(paramlU)[getCurrentItemSlot(paramlU)];
   }

   public static gM getCurrentItemStack(mg parammg) {
      return getCurrentItemStack(getInventory(parammg));
   }

   public static gM getCurrentItemStack() {
      return getCurrentItemStack((mg)GetPlayer());
   }

   public static String getItemCount() {
      gM gM = getCurrentItemStack();
      return gM.toString();
   }

   public static int findItemInInventory(int... paramVarArgs) {
      gM gM = getCurrentItemStack();
      int j;
      int i;
      if (gM != null) {

         try {
            Method method1 = proutils.filterMethodFromReturnTypeAndParams(b3.class, gM.class);
            Method method2 = proutils.filterMethodFromReturnTypeAndParams(Integer.TYPE, b3.class, b3.class);
            b3 b3 = (b3)method1.invoke(gM);
            j = (Integer)method2.invoke((Object)null, b3);
            i = j;
         } catch (Exception var10) {
            addChatMessage(getStackTraceAsString(var10));
         }

         int[] var12 = paramVarArgs;
         i = paramVarArgs.length;

         for(int var15 = 0; var15 < i; ++var15) {
            j = var12[var15];
            if (i == j) {
               return getCurrentItemSlot();
            }
         }
      }

      for(byte b = 0; b < 9; ++b) {
         if (getCurrentItemSlot() != b) {
            gM gM1 = getMainInventorySlot(b);
            if (gM1 != null) {
               i = 0;

               try {
                  Method method1 = proutils.filterMethodFromReturnTypeAndParams(b3.class, gM.class);
                  Method method2 = proutils.filterMethodFromReturnTypeAndParams(Integer.TYPE, b3.class, b3.class);
                  b3 b3 = (b3)method1.invoke(gM1);
                  j = (Integer)method2.invoke((Object)null, b3);
                  i = j;
               } catch (Exception var9) {
                  addChatMessage(getStackTraceAsString(var9));
               }

               int[] var17 = paramVarArgs;
               j = paramVarArgs.length;

               for(int var19 = 0; var19 < j; ++var19) {
                  j = var17[var19];
                  if (i == j) {
                     return b;
                  }
               }
            }
         }
      }

      return -1;
   }

   public static void rotation(mg parammg) throws InvocationTargetException, NoSuchMethodException, IllegalAccessException {
      if ((double)getEntityHealth(parammg) == 1.0D || !ModuleManager.isEnabled("AntiBot")) {
         ;
      }
   }

   public static double GetlastTickPosX(m9 paramm9) {
      return paramm9.a6;
   }

   public static double GetlastTickPosY(m9 paramm9) {
      return paramm9.h;
   }

   public static double GetlastTickPosZ(m9 paramm9) {
      return paramm9.G;
   }

   public static Object C02EntityUseAttack(Object paramObject) {
      Object object = null;

      try {
         Class<?> clazz = Class.forName("com.craftrise.on");
         Class[] arrayOfClass = new Class[]{m9.class, com.craftrise.on.a.class};
         Constructor<?> constructor = clazz.getConstructor(arrayOfClass);
         Object object1 = constructor.newInstance(paramObject, getAttackAction());
         object = object1;
      } catch (Exception var6) {
         Config.warn(var6.getMessage());
      }

      return object;
   }

   public static Object getAttackAction() {
      try {
         Class<?> clazz = Class.forName("com.craftrise.on$a");
         Field field = clazz.getField("ATTACK");
         return field.get((Object)null);
      } catch (NoSuchFieldException | IllegalAccessException | ClassNotFoundException var2) {
         Config.warn(var2.getMessage());
         return null;
      }
   }

   public static Object GetMinecraftObj() {
      Object object = null;

      try {
         Class<?> clazz = Class.forName("com.craftrise.client.S");
         Field field = clazz.getDeclaredField("cj");
         field.setAccessible(true);
         Object object1 = field.get((Object)null);
         object = object1;
      } catch (NoSuchFieldException | IllegalAccessException | ClassNotFoundException var4) {
         Config.warn(var4.getMessage());
      }

      return object;
   }

   public static Object getPlayerController() {
      Object object = null;

      try {
         Class<?> clazz = Class.forName("com.craftrise.client.S");
         Field field = clazz.getDeclaredField("b");
         field.setAccessible(true);
         object = field.get(GetMinecraftObj());
      } catch (NoSuchFieldException | IllegalAccessException | ClassNotFoundException var3) {
         Config.warn(var3.getMessage());
      }

      return object;
   }

   public static Object getNetClientHandler() {
      Object object = null;

      try {
         Class<?> clazz = Class.forName("com.craftrise.client.ez");
         Field field = clazz.getDeclaredField("a");
         field.setAccessible(true);
         object = field.get(getPlayerController());
      } catch (NoSuchFieldException | IllegalAccessException | ClassNotFoundException var3) {
         Config.warn(var3.getMessage());
      }

      return object;
   }

   public static void addToSendQueue(Object paramObject) {
      try {
         Class<?> clazz = Class.forName("com.craftrise.client.c9");
         Class[] arrayOfClass = new Class[]{Class.forName("com.craftrise.lv"), Long.TYPE};
         Method method = clazz.getDeclaredMethod("a", arrayOfClass);
         Object object = createCancelPacket();
         method.invoke(getNetClientHandler(), object, Main.idk);
         method.invoke(getNetClientHandler(), paramObject, Main.idk);
      } catch (Exception var5) {
         Config.warn(var5.getMessage());
      }

   }

   public static Object createCancelPacket() {
      return null;
   }

   public static float getEntityHealth(Object paramObject) {
      float f = 31.0F;

      try {
         Class<?> clazz = Class.forName("com.craftrise.mj");
         Method[] var3 = clazz.getDeclaredMethods();
         int var4 = var3.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            Method method = var3[var5];
            if (method.getName().equals("k") && method.getParameterCount() == 0 && method.getReturnType().equals(Float.TYPE)) {
               Object object = method.invoke(paramObject);
               f = (Float)object;
            }
         }
      } catch (IllegalAccessException | InvocationTargetException | ClassNotFoundException var8) {
         Config.warn(var8.getMessage());
      }

      return f;
   }

   public static void jump() {
      try {
         Class<?> clazz = Class.forName("com.craftrise.mg");
         Method method = clazz.getMethod("y", Long.TYPE);
         method.setAccessible(true);
         method.invoke(GetPlayer(), 5L);
      } catch (Exception var2) {
         addChatMessage(var2.toString() + " Exception");
      }

   }

   public static void setPosition_mid(double paramDouble1, double paramDouble2, double paramDouble3) {
      try {
         Class<?> clazz = Class.forName("com.craftrise.m9");
         Method[] var7 = clazz.getDeclaredMethods();
         int var8 = var7.length;

         for(int var9 = 0; var9 < var8; ++var9) {
            Method method = var7[var9];
            if (method.getName().contains("b") && method.getParameterCount() == 4) {
               method.setAccessible(true);
               method.invoke(GetPlayer(), paramDouble1, paramDouble2, paramDouble3, Main.idk);
            }
         }
      } catch (Exception var11) {
         addChatMessage(var11.toString() + " Exception");
      }

   }

   public static void setPositionAndRotation(double paramDouble1, double paramDouble2, double paramDouble3, float paramFloat1, float paramFloat2) {
      setPositionAndRotation(GetPlayer(), paramDouble1, paramDouble2, paramDouble3, paramFloat1, paramFloat2);
   }

   public static void setPositionAndRotation(m9 paramm9, double paramDouble1, double paramDouble2, double paramDouble3, float paramFloat1, float paramFloat2) {
      paramm9.b(paramDouble1, paramDouble2, paramDouble3, paramFloat1, paramFloat2, 31L);
   }

   public static void SetMotionX(double paramDouble) {
      GetPlayer().bh = new dR(paramDouble);
   }

   public static void SetMotionY(double paramDouble) {
      GetPlayer().aT = new dR(paramDouble);
   }

   public static void SetMotionZ(double paramDouble) {
      GetPlayer().bf = new dR(paramDouble);
   }

   public static double GetprevPosZ(m9 paramm9) {
      return paramm9.at;
   }

   public double GetprevPosX() {
      return GetPlayer().a4;
   }

   public double GetprevPosY() {
      return GetPlayer().L;
   }

   public static double GetprevPosZ() {
      return GetPlayer().at;
   }

   public static List loadedEntityList() {
      return GetWorld().g;
   }

   public static List playerEntities() {
      return GetWorld().H;
   }

   public static String getEntityDisplayName(m9 paramm9) {
      String str = "null";

      try {
         Class<?> clazz = Class.forName("com.craftrise.m9");
         Method[] var3 = clazz.getDeclaredMethods();
         int var4 = var3.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            Method method = var3[var5];
            if (method.getReturnType().toString().contains("cr.launcher.IChatComponent")) {
               method.setAccessible(true);
               IChatComponent iChatComponent = (IChatComponent)method.invoke(paramm9);
               str = iChatComponent.getFormattedText();
            }
         }
      } catch (Exception var8) {
         addChatMessage(var8.toString() + " yaa");
      }

      return str;
   }

   public static String getUnformattedEntityDisplayName(m9 paramm9) {
      String str = "null";

      try {
         Class<?> clazz = Class.forName("com.craftrise.m9");
         Method[] var3 = clazz.getDeclaredMethods();
         int var4 = var3.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            Method method = var3[var5];
            if (method.getReturnType().toString().contains("cr.launcher.IChatComponent")) {
               method.setAccessible(true);
               IChatComponent iChatComponent = (IChatComponent)method.invoke(paramm9);
               str = iChatComponent.getUnformattedText();
            }
         }
      } catch (Exception var8) {
         addChatMessage(var8.toString() + " yaa");
      }

      return str;
   }

   public static dG getCurrentScreen() {
      return Config.getMinecraft().bw;
   }

   public static lU getInventory(mg parammg) {
      return parammg.J;
   }

   public static lU getInventoryPlayerObj() {
      return GetPlayer().J;
   }

   public static ez GetPlayerControllerMp() {
      return GetMinecraft().b;
   }

   public static d0 GetFontRendererObj() {
      return GetMinecraft().j;
   }

   public static lU getInventory() {
      return getInventory(GetPlayer());
   }

   public static qJ getInventoryContainer(mg parammg) {
      return parammg.b1;
   }

   public static qJ getInventoryContainer() {
      return getInventoryContainer(GetPlayer());
   }

   public static boolean isMoving() {
      return GetPlayer() != null && (GetPlayer().l.b.a(5L) != 0.0F || GetPlayer().l.c.a(5L) != 0.0F);
   }

   public static boolean onGround() {
      return GetPlayer().s.a(522424L);
   }

   public static int GethurtResistantTime() {
      return GetPlayer().bK;
   }

   public static boolean isCollidedHorizontally() {
      return GetPlayer().ax;
   }

   public static boolean isCollidedVertically() {
      return GetPlayer().aL;
   }

   public static double GetMotionX() {
      return GetPlayer().bh.b(5L);
   }

   public static void RemoveEntity(Object paramObject) {
      try {
         Class<?> clazz = Class.forName("com.craftrise.client.cf");
         Method method = clazz.getDeclaredMethod("b", m9.class, Long.TYPE);
         method.invoke(GetWorld(), paramObject, 5L);
      } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException | ClassNotFoundException var3) {
         var3.printStackTrace();
      }

   }

   public static double GetMotionY() {
      return GetPlayer().aT.b(5L);
   }

   public static double GetMotionZ() {
      return GetPlayer().bf.b(5L);
   }

   public static float FallDistance() {
      try {
         Class<m9> clazz = m9.class;
         Field field = clazz.getDeclaredField("c");
         field.setAccessible(true);
         fa fa = GetPlayer();
         return field.getFloat(fa);
      } catch (NoSuchFieldException | IllegalAccessException var3) {
         var3.printStackTrace();
         return -1.0F;
      }
   }

   public static void SetflySpeed(float paramFloat) {
      try {
         Class<mg> clazz = mg.class;
         Field field1 = clazz.getDeclaredField("S");
         field1.setAccessible(true);
         Object object = field1.get(a.q);
         Field field2 = object.getClass().getDeclaredField("c");
         field2.setAccessible(true);
         field2.set(object, new de(paramFloat));
      } catch (Exception var5) {
         var5.printStackTrace();
      }

   }

   public static float degreesToRadians(float paramFloat) {
      return paramFloat * 0.017453292F;
   }

   public static void SetPosition(double paramDouble1, double paramDouble2, double paramDouble3) {
      try {
         Class<m9> clazz = m9.class;
         Method method = clazz.getMethod("b", Double.TYPE, Double.TYPE, Double.TYPE, Long.TYPE);
         method.invoke(a.q, paramDouble1, paramDouble2, paramDouble3, 5L);
      } catch (Exception var8) {
         var8.printStackTrace();
      }

   }

   public static void SetisDead(boolean paramBoolean) {
      GetPlayer().d = paramBoolean;
   }

   public static boolean isDead(mg parammg) {
      return parammg.d;
   }

   public static boolean isMoving(mg parammg) {
      return parammg.aZ.a(5L) != 0.0F || parammg.cm.a(5L) != 0.0F;
   }

   public static boolean isFalseFlaggable(mg parammg) {
      return parammg.z(5L) || parammg.Z < 10;
   }

   public static int displayWidth() {
      return GetMinecraft().aK;
   }

   public static int displayHeight() {
      return GetMinecraft().bF;
   }

   public static void setSpeed(double paramDouble1, float paramFloat, double paramDouble2, double paramDouble3) {
      if (paramDouble3 != 0.0D) {
         if (paramDouble2 > 0.0D) {
            paramFloat += (float)(paramDouble3 > 0.0D ? -45 : 45);
         } else if (paramDouble2 < 0.0D) {
            paramFloat += (float)(paramDouble3 > 0.0D ? 45 : -45);
         }

         paramDouble2 = 0.0D;
         if (paramDouble3 > 0.0D) {
            paramDouble3 = 1.0D;
         } else if (paramDouble3 < 0.0D) {
            paramDouble3 = -1.0D;
         }
      }

      if (paramDouble2 > 0.0D) {
         paramDouble2 = 1.0D;
      } else if (paramDouble2 < 0.0D) {
         paramDouble2 = -1.0D;
      }

      double d1 = Math.cos(Math.toRadians((double)(paramFloat + 90.0F)));
      double d2 = Math.sin(Math.toRadians((double)(paramFloat + 90.0F)));
      a.q.bh = new dR(paramDouble3 * paramDouble1 * d1 + paramDouble2 * paramDouble1 * d2);
      a.q.bf = new dR(paramDouble3 * paramDouble1 * d2 - paramDouble2 * paramDouble1 * d1);
   }

   public static double getBaseMoveSpeed() {
      return (double)a.q.S.b(5L) * 2.873D;
   }

   public static void setSpeed(double paramDouble) {
      setSpeed(paramDouble, a.q.bL, (double)a.q.l.c.a(5L), (double)a.q.l.b.a(5L));
   }

   public static p jumpMovementFactor(float paramFloat) {
      return m9.R;
   }

   public static double Direction() {
      float f1 = GetrotationYaw();
      if (GetPlayer().l.b.a(5L) < 0.0F) {
         f1 += 180.0F;
      }

      float f2 = 1.0F;
      if (GetPlayer().l.b.a(5L) < 0.0F) {
         f2 = -0.5F;
      } else if (GetPlayer().l.b.a(5L) > 0.0F) {
         f2 = 0.5F;
      }

      if (GetPlayer().l.c.a(5L) > 0.0F) {
         f1 -= 90.0F * f2;
      }

      if (GetPlayer().l.c.a(5L) < 0.0F) {
         f1 += 90.0F * f2;
      }

      return Math.toRadians((double)f1);
   }

   public static void Strafe(float paramFloat) {
      if (isMoving()) {
         SetMotionX(-Math.sin(Direction()) * (double)paramFloat);
         SetMotionZ(Math.cos(Direction()) * (double)paramFloat);
      }
   }

   public int GetticksExisted() {
      return GetPlayer().Z;
   }

   public static void setPressed(boolean paramBoolean) {
      try {
         Class<?> clazz = Class.forName("com.craftrise.client.gR");
         Field[] var2 = clazz.getDeclaredFields();
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            Field field = var2[var4];
            if (field.getName().equals("b")) {
               field.setAccessible(true);
               field.set(keybindSneak, paramBoolean);
            }
         }
      } catch (Exception var6) {
         addChatMessage(var6.toString() + " Exception");
      }

   }

   public boolean GetisCollided() {
      return GetPlayer().a1;
   }

   public static void SetisInWeb(boolean paramBoolean) {
      GetPlayer().al = paramBoolean;
   }

   public static boolean GetisInWeb() {
      return GetPlayer().al;
   }

   public static void SetrenderArmYaw(float paramFloat) {
      GetPlayer().bb = paramFloat;
   }

   public static void SetrenderArmPitch(float paramFloat) {
      GetPlayer().aG = paramFloat;
   }

   public static void SetprevRenderArmYaw(float paramFloat) {
      GetPlayer().aO = paramFloat;
   }

   public static void SetprevRenderArmPitch(float paramFloat) {
      GetPlayer().t = paramFloat;
   }

   public void setEntitySize(double paramDouble1, double paramDouble2) {
      this.boundingBox.setMinX(0.0D);
      this.boundingBox.setMinY(0.0D);
      this.boundingBox.setMinZ(0.0D);
      this.boundingBox.setMaxX(paramDouble1);
      this.boundingBox.setMaxY(paramDouble2);
      this.boundingBox.setMaxZ(paramDouble1);
   }

   public static ah getEntityBoundingBox(m9 paramm9) {
      Object object = null;

      try {
         Field[] var2 = paramm9.getClass().getDeclaredFields();
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            Field field = var2[var4];
            if (field.getName().equals("aW")) {
               field.setAccessible(true);
               object = field.get(paramm9);
            }
         }
      } catch (Exception var6) {
         addChatMessage(var6.toString());
      }

      return (ah)object;
   }

   public static float getEntityBoundingBox2(m9 paramm9) {
      Object object = null;

      try {
         Field[] var2 = paramm9.getClass().getDeclaredFields();
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            Field field = var2[var4];
            if (field.getName().equals("aW")) {
               field.setAccessible(true);
               object = field.get(paramm9);
            }
         }
      } catch (Exception var6) {
         addChatMessage(var6.toString());
      }

      return (Float)object;
   }

   public static g8 getRenderManager() {
      Object object = null;

      try {
         Method[] var1 = GetMinecraft().getClass().getDeclaredMethods();
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            Method method = var1[var3];
            if (method.getName().equals("a") && method.getReturnType().toString().contains("com.craftrise.client.g8")) {
               method.setAccessible(true);
               object = method.invoke(GetMinecraft());
            }
         }
      } catch (Exception var5) {
         addChatMessage(var5.toString());
      }

      return (g8)object;
   }

   public static fV getResourceManager() {
      Object object = null;

      try {
         Method[] var1 = GetMinecraft().getClass().getDeclaredMethods();
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            Method method = var1[var3];
            if (method.getName().equals("a") && method.getReturnType().toString().contains("com.craftrise.client.fV")) {
               method.setAccessible(true);
               object = method.invoke(GetMinecraft());
            }
         }
      } catch (Exception var5) {
         addChatMessage(var5.toString());
      }

      return (fV)object;
   }

   public static int getScreenWidth() {
      int i = 31;

      try {
         Class<?> clazz = Class.forName("com.craftrise.client.y");
         Method[] var2 = clazz.getDeclaredMethods();
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            Method method = var2[var4];
            if (method.getName().equals("a") && method.getParameterCount() == 0 && method.getReturnType().equals(Integer.TYPE)) {
               Object object = method.invoke(new y(Config.getMinecraft()));
               i = (Integer)object;
            }
         }
      } catch (IllegalAccessException | InvocationTargetException | ClassNotFoundException var7) {
         Config.warn(var7.getMessage());
      }

      return i;
   }

   public static int getScreenHeight() {
      int i = 31;

      try {
         Class<?> clazz = Class.forName("com.craftrise.client.y");
         Method[] var2 = clazz.getDeclaredMethods();
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            Method method = var2[var4];
            if (method.getName().equals("c") && method.getParameterCount() == 0 && method.getReturnType().equals(Integer.TYPE)) {
               Object object = method.invoke(new y(Config.getMinecraft()));
               i = (Integer)object;
            }
         }
      } catch (IllegalAccessException | InvocationTargetException | ClassNotFoundException var7) {
         Config.warn(var7.getMessage());
      }

      return i;
   }

   public static int getDebugFPS() {
      int i = 31;

      try {
         Class<?> clazz = Class.forName("com.craftrise.client.S");
         Method[] var2 = clazz.getDeclaredMethods();
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            Method method = var2[var4];
            if (method.getName().equals("b") && method.getParameterCount() == 0 && method.getReturnType().equals(Integer.TYPE)) {
               Object object = method.invoke(new y(Config.getMinecraft()));
               i = (Integer)object;
            }
         }
      } catch (IllegalAccessException | InvocationTargetException | ClassNotFoundException var7) {
         System.out.println(var7);
      }

      return i;
   }

   public static void scaffoldjump() {
      try {
         Class<?> clazz = Class.forName("com.craftrise.mg");
         Method method = clazz.getMethod("y", Long.TYPE);
         method.setAccessible(true);
         method.invoke(GetPlayer(), 8L);
      } catch (Exception var2) {
         addChatMessage(var2.toString() + " Exception");
      }

   }

   public static void sendMessage(String paramString) {
      GetPlayer().b(paramString, 31L);
   }

   public static Object C07PacketPlayerDigging(Object paramObject1, BlockPos paramBlockPos, Object paramObject2) {
      Object object = null;

      try {
         Class<?> clazz = Class.forName("com.craftrise.kh");
         Class[] arrayOfClass = new Class[]{Class.forName("com.craftrise.kh$a"), BlockPos.class, lG.class};
         Constructor<?> constructor = clazz.getConstructor(arrayOfClass);
         constructor.setAccessible(true);
         Object object1 = constructor.newInstance(paramObject1, paramBlockPos, paramObject2);
         object = object1;
      } catch (Exception var8) {
         addChatMessage(var8.toString());
      }

      return object;
   }

   public static Object C08PacketPlayerBlockPlacement(Object paramObject1, BlockPos paramBlockPos, Object paramObject2) {
      Object object = null;

      try {
         Class<?> clazz = Class.forName("com.craftrise.qd");
         Class[] arrayOfClass = new Class[]{Class.forName("com.craftrise.kh$a"), BlockPos.class, lG.class};
         Constructor<?> constructor = clazz.getConstructor(arrayOfClass);
         constructor.setAccessible(true);
         Object object1 = constructor.newInstance(paramObject1, paramBlockPos, paramObject2);
         object = object1;
      } catch (Exception var8) {
         addChatMessage(var8.toString());
      }

      return object;
   }

   public static Object EnumFacingUp() {
      try {
         Class<?> clazz = Class.forName("com.craftrise.lG");
         Field field = clazz.getField("UP");
         return field.get((Object)null);
      } catch (NoSuchFieldException | IllegalAccessException | ClassNotFoundException var2) {
         Config.warn(var2.getMessage());
         return null;
      }
   }

   public static Class<?> loadLGClass() {
      try {
         return Class.forName("com.craftrise.lG");
      } catch (ClassNotFoundException var1) {
         Config.warn(var1.getMessage());
         return null;
      }
   }

   public static Object EnumFacingDown() {
      try {
         Class<?> clazz = Class.forName("com.craftrise.lG");
         Field field = clazz.getField("DOWN");
         return field.get((Object)null);
      } catch (NoSuchFieldException | IllegalAccessException | ClassNotFoundException var2) {
         Config.warn(var2.getMessage());
         return null;
      }
   }

   public static Object C07PacketPlayerDiggingAbortDestroyBlockEnum() {
      try {
         Class<?> clazz = Class.forName("com.craftrise.kh$a");
         Field field = clazz.getField("ABORT_DESTROY_BLOCK");
         return field.get((Object)null);
      } catch (NoSuchFieldException | IllegalAccessException | ClassNotFoundException var2) {
         Config.warn(var2.getMessage());
         return null;
      }
   }

   public static Object C07PacketPlayerDiggingReleaseUseItem() {
      try {
         Class<?> clazz = Class.forName("com.craftrise.kh$a");
         Field field = clazz.getField("RELEASE_USE_ITEM");
         return field.get((Object)null);
      } catch (NoSuchFieldException | IllegalAccessException | ClassNotFoundException var2) {
         Config.warn(var2.getMessage());
         return null;
      }
   }

   public static Object C05PacketPlayerLook(float paramFloat1, float paramFloat2, boolean paramBoolean) {
      Object object = null;

      try {
         Class<?> clazz = Class.forName("com.craftrise.lE$b");
         Class[] arrayOfClass = new Class[]{Float.TYPE, Float.TYPE, Boolean.TYPE};
         Constructor<?> constructor = clazz.getConstructor(arrayOfClass);
         Object object1 = constructor.newInstance(paramFloat1, paramFloat2, paramBoolean);
         object = object1;
      } catch (Exception var8) {
      }

      return object;
   }

   public static Object C0BPacketEntityAction(fa paramfa, Object paramObject) {
      try {
         Class<?> clazz = Class.forName("com.craftrise.pN$a");
         Field field = clazz.getField("C0BPacketEntityAction$Action");
         return field.get((Object)null);
      } catch (NoSuchFieldException | IllegalAccessException | ClassNotFoundException var4) {
         Config.warn(var4.getMessage());
         return null;
      }
   }

   public static Object C0BPacketEntityActionStartSprint() {
      try {
         Class<?> clazz = Class.forName("com.craftrise.pN$a");
         Field field = clazz.getField("START_SPRINTING");
         return field.get((Object)null);
      } catch (NoSuchFieldException | IllegalAccessException | ClassNotFoundException var2) {
         Config.warn(var2.getMessage());
         return null;
      }
   }

   public static Object C0BPacketEntityActionStopSprint() {
      try {
         Class<?> clazz = Class.forName("com.craftrise.pN$a");
         Field field = clazz.getField("STOP_SPRINTING");
         return field.get((Object)null);
      } catch (NoSuchFieldException | IllegalAccessException | ClassNotFoundException var2) {
         Config.warn(var2.getMessage());
         return null;
      }
   }

   public static void setRightClickDelayTimer() {
      try {
         Class<?> clazz = Class.forName("com.craftrise.client.S");
         Field[] var1 = clazz.getDeclaredFields();
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            Field field = var1[var3];
            if (field.getName().equals("cB")) {
               field.setAccessible(true);
               field.set(GetMinecraft(), 0);
            }
         }
      } catch (IllegalAccessException | ClassNotFoundException var5) {
      }

   }

   public static void setGammaSetting(int paramInt) {
      try {
         Class<?> clazz = Class.forName("com.craftrise.client.cz");
         Field[] var2 = clazz.getDeclaredFields();
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            Field field = var2[var4];
            if (field.getName().equals("y")) {
               field.setAccessible(true);
               field.set(Config.getGameSettings(), paramInt);
            }
         }
      } catch (IllegalAccessException | ClassNotFoundException var6) {
      }

   }

   public static dt InGameGui() {
      return GetMinecraft().K;
   }

   public static void setInGameGui(dt paramdt) {
      GetMinecraft().K = paramdt;
   }

   public static void drawStrHook(d0 paramd0) {
      GetMinecraft().j = paramd0;
   }

   public static void setEffectRenderer(EffectRenderer paramArticEffectRenderer) {
      GetMinecraft().V = paramArticEffectRenderer;
   }

   public static void setPlayerController(PlayerController paramSagoPlayerController) {
      GetMinecraft().b = paramSagoPlayerController;
   }

   public static ez getPlayerController2() {
      return Config.getMinecraft().b;
   }

   static {
      keybindSneak = Config.getGameSettings().a4;
      targetForROT = null;
   }

   public static class AxisAlignedBB {
      public double minX;
      public double minY;
      public double minZ;
      public double maxX;
      public double maxY;
      public double maxZ;

      public AxisAlignedBB(double param1Double1, double param1Double2, double param1Double3, double param1Double4, double param1Double5, double param1Double6) {
         this.minX = Math.min(param1Double1, param1Double4);
         this.minY = Math.min(param1Double2, param1Double5);
         this.minZ = Math.min(param1Double3, param1Double6);
         this.maxX = Math.max(param1Double1, param1Double4);
         this.maxY = Math.max(param1Double2, param1Double5);
         this.maxZ = Math.max(param1Double3, param1Double6);
      }

      public CustomMapper.AxisAlignedBB addCoord(double param1Double1, double param1Double2, double param1Double3) {
         double d1 = this.minX;
         double d2 = this.minY;
         double d3 = this.minZ;
         double d4 = this.maxX;
         double d5 = this.maxY;
         double d6 = this.maxZ;
         if (param1Double1 < 0.0D) {
            d1 += param1Double1;
         } else if (param1Double1 > 0.0D) {
            d4 += param1Double1;
         }

         if (param1Double2 < 0.0D) {
            d2 += param1Double2;
         } else if (param1Double2 > 0.0D) {
            d5 += param1Double2;
         }

         if (param1Double3 < 0.0D) {
            d3 += param1Double3;
         } else if (param1Double3 > 0.0D) {
            d6 += param1Double3;
         }

         return new CustomMapper.AxisAlignedBB(d1, d2, d3, d4, d5, d6);
      }

      public CustomMapper.AxisAlignedBB expand(double param1Double1, double param1Double2, double param1Double3) {
         double d1 = this.minX - param1Double1;
         double d2 = this.minY - param1Double2;
         double d3 = this.minZ - param1Double3;
         double d4 = this.maxX + param1Double1;
         double d5 = this.maxY + param1Double2;
         double d6 = this.maxZ + param1Double3;
         return new CustomMapper.AxisAlignedBB(d1, d2, d3, d4, d5, d6);
      }

      public CustomMapper.AxisAlignedBB union(CustomMapper.AxisAlignedBB param1AxisAlignedBB) {
         double d1 = Math.min(this.minX, param1AxisAlignedBB.minX);
         double d2 = Math.min(this.minY, param1AxisAlignedBB.minY);
         double d3 = Math.min(this.minZ, param1AxisAlignedBB.minZ);
         double d4 = Math.max(this.maxX, param1AxisAlignedBB.maxX);
         double d5 = Math.max(this.maxY, param1AxisAlignedBB.maxY);
         double d6 = Math.max(this.maxZ, param1AxisAlignedBB.maxZ);
         return new CustomMapper.AxisAlignedBB(d1, d2, d3, d4, d5, d6);
      }

      public static CustomMapper.AxisAlignedBB fromBounds(double param1Double1, double param1Double2, double param1Double3, double param1Double4, double param1Double5, double param1Double6) {
         double d1 = Math.min(param1Double1, param1Double4);
         double d2 = Math.min(param1Double2, param1Double5);
         double d3 = Math.min(param1Double3, param1Double6);
         double d4 = Math.max(param1Double1, param1Double4);
         double d5 = Math.max(param1Double2, param1Double5);
         double d6 = Math.max(param1Double3, param1Double6);
         return new CustomMapper.AxisAlignedBB(d1, d2, d3, d4, d5, d6);
      }

      public CustomMapper.AxisAlignedBB offset(double param1Double1, double param1Double2, double param1Double3) {
         return new CustomMapper.AxisAlignedBB(this.minX + param1Double1, this.minY + param1Double2, this.minZ + param1Double3, this.maxX + param1Double1, this.maxY + param1Double2, this.maxZ + param1Double3);
      }

      public double calculateXOffset(CustomMapper.AxisAlignedBB param1AxisAlignedBB, double param1Double) {
         if (param1AxisAlignedBB.maxY > this.minY && param1AxisAlignedBB.minY < this.maxY && param1AxisAlignedBB.maxZ > this.minZ && param1AxisAlignedBB.minZ < this.maxZ) {
            double d;
            if (param1Double > 0.0D && param1AxisAlignedBB.maxX <= this.minX) {
               d = this.minX - param1AxisAlignedBB.maxX;
               if (d < param1Double) {
                  param1Double = d;
               }
            } else if (param1Double < 0.0D && param1AxisAlignedBB.minX >= this.maxX) {
               d = this.maxX - param1AxisAlignedBB.minX;
               if (d > param1Double) {
                  param1Double = d;
               }
            }

            return param1Double;
         } else {
            return param1Double;
         }
      }

      public double calculateYOffset(CustomMapper.AxisAlignedBB param1AxisAlignedBB, double param1Double) {
         if (param1AxisAlignedBB.maxX > this.minX && param1AxisAlignedBB.minX < this.maxX && param1AxisAlignedBB.maxZ > this.minZ && param1AxisAlignedBB.minZ < this.maxZ) {
            double d;
            if (param1Double > 0.0D && param1AxisAlignedBB.maxY <= this.minY) {
               d = this.minY - param1AxisAlignedBB.maxY;
               if (d < param1Double) {
                  param1Double = d;
               }
            } else if (param1Double < 0.0D && param1AxisAlignedBB.minY >= this.maxY) {
               d = this.maxY - param1AxisAlignedBB.minY;
               if (d > param1Double) {
                  param1Double = d;
               }
            }

            return param1Double;
         } else {
            return param1Double;
         }
      }

      public double calculateZOffset(CustomMapper.AxisAlignedBB param1AxisAlignedBB, double param1Double) {
         if (param1AxisAlignedBB.maxX > this.minX && param1AxisAlignedBB.minX < this.maxX && param1AxisAlignedBB.maxY > this.minY && param1AxisAlignedBB.minY < this.maxY) {
            double d;
            if (param1Double > 0.0D && param1AxisAlignedBB.maxZ <= this.minZ) {
               d = this.minZ - param1AxisAlignedBB.maxZ;
               if (d < param1Double) {
                  param1Double = d;
               }
            } else if (param1Double < 0.0D && param1AxisAlignedBB.minZ >= this.maxZ) {
               d = this.maxZ - param1AxisAlignedBB.minZ;
               if (d > param1Double) {
                  param1Double = d;
               }
            }

            return param1Double;
         } else {
            return param1Double;
         }
      }

      public boolean intersectsWith(CustomMapper.AxisAlignedBB param1AxisAlignedBB) {
         return param1AxisAlignedBB.maxX > this.minX && param1AxisAlignedBB.minX < this.maxX && param1AxisAlignedBB.maxY > this.minY && param1AxisAlignedBB.minY < this.maxY && param1AxisAlignedBB.maxZ > this.minZ && param1AxisAlignedBB.minZ < this.maxZ;
      }

      public boolean isVecInside(Vec3 param1Vec3) {
         return param1Vec3.xCoord > this.minX && param1Vec3.xCoord < this.maxX && param1Vec3.yCoord > this.minY && param1Vec3.yCoord < this.maxY && param1Vec3.zCoord > this.minZ && param1Vec3.zCoord < this.maxZ;
      }

      public double getAverageEdgeLength() {
         double d1 = this.maxX - this.minX;
         double d2 = this.maxY - this.minY;
         double d3 = this.maxZ - this.minZ;
         return (d1 + d2 + d3) / 3.0D;
      }

      public CustomMapper.AxisAlignedBB contract(double param1Double1, double param1Double2, double param1Double3) {
         double d1 = this.minX + param1Double1;
         double d2 = this.minY + param1Double2;
         double d3 = this.minZ + param1Double3;
         double d4 = this.maxX - param1Double1;
         double d5 = this.maxY - param1Double2;
         double d6 = this.maxZ - param1Double3;
         return new CustomMapper.AxisAlignedBB(d1, d2, d3, d4, d5, d6);
      }

      public String toString() {
         return "box[" + this.minX + ", " + this.minY + ", " + this.minZ + " -> " + this.maxX + ", " + this.maxY + ", " + this.maxZ + "]";
      }

      public boolean func_181656_b() {
         return Double.isNaN(this.minX) || Double.isNaN(this.minY) || Double.isNaN(this.minZ) || Double.isNaN(this.maxX) || Double.isNaN(this.maxY) || Double.isNaN(this.maxZ);
      }

      private boolean isVecInYZ(Vec3 param1Vec3) {
         return param1Vec3 != null && param1Vec3.yCoord >= this.minY && param1Vec3.yCoord <= this.maxY && param1Vec3.zCoord >= this.minZ && param1Vec3.zCoord <= this.maxZ;
      }

      private boolean isVecInXZ(Vec3 param1Vec3) {
         return param1Vec3 != null && param1Vec3.xCoord >= this.minX && param1Vec3.xCoord <= this.maxX && param1Vec3.zCoord >= this.minZ && param1Vec3.zCoord <= this.maxZ;
      }

      private boolean isVecInXY(Vec3 param1Vec3) {
         return param1Vec3 != null && param1Vec3.xCoord >= this.minX && param1Vec3.xCoord <= this.maxX && param1Vec3.yCoord >= this.minY && param1Vec3.yCoord <= this.maxY;
      }

      public double getMinX() {
         return this.minX;
      }

      public void setMinX(double param1Double) {
         this.minX = param1Double;
      }

      public double getMinY() {
         return this.minY;
      }

      public void setMinY(double param1Double) {
         this.minY = param1Double;
      }

      public double getMinZ() {
         return this.minZ;
      }

      public void setMinZ(double param1Double) {
         this.minZ = param1Double;
      }

      public double getMaxX() {
         return this.maxX;
      }

      public void setMaxX(double param1Double) {
         this.maxX = param1Double;
      }

      public double getMaxY() {
         return this.maxY;
      }

      public void setMaxY(double param1Double) {
         this.maxY = param1Double;
      }

      public double getMaxZ() {
         return this.maxZ;
      }

      public void setMaxZ(double param1Double) {
         this.maxZ = param1Double;
      }
   }
}
