package today.makrit.utils.Helper;

import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import com.craftrise.b3;
import com.craftrise.gM;

import java.lang.reflect.Method;

import static today.makrit.module.impl.player.InvManager.getStackTraceAsString;
import static today.makrit.utils.proutils.filterMethodFromReturnTypeAndParams;

public class InventoryHelper
{
    public static int getCurrentItemSlot(final com.craftrise.lU inventoryPlayer) {
        return inventoryPlayer.c;
    }

    public static int getCurrentItemSlot(final com.craftrise.mg entityPlayer) {
        return getCurrentItemSlot(ThePlayer.getInventory(entityPlayer));
    }

    public static int getCurrentItemSlot() {
        return getCurrentItemSlot((com.craftrise.mg) Minecraft.GetPlayer());
    }

    public static void setCurrentItemSlot(final com.craftrise.lU inventoryPlayer, final int slot) {
        inventoryPlayer.c = slot;
    }

    public static void setCurrentItemSlot(final com.craftrise.mg entityPlayer, final int slot) {
        setCurrentItemSlot(ThePlayer.getInventory(entityPlayer), slot);
    }

    public static void setCurrentItemSlot(final int slot) {
        setCurrentItemSlot((com.craftrise.mg) Minecraft.GetPlayer(), slot);
    }

    public static com.craftrise.gM[] getMainInventory(final com.craftrise.lU inventoryPlayer) {
        return inventoryPlayer.e;
    }

    public static com.craftrise.gM[] getMainInventory(final com.craftrise.mg entityPlayer) {
        return getMainInventory(ThePlayer.getInventory(entityPlayer));
    }

    public static com.craftrise.gM[] getMainInventory() {
        return getMainInventory((com.craftrise.mg) Minecraft.GetPlayer());
    }

    public static com.craftrise.gM getMainInventorySlot(final com.craftrise.lU inventoryPlayer, final int slot) {
        return getMainInventory(inventoryPlayer)[slot];
    }

    public static com.craftrise.gM getMainInventorySlot(final com.craftrise.mg entityPlayer, final int slot) {
        return getMainInventorySlot(ThePlayer.getInventory(entityPlayer), slot);
    }

    public static com.craftrise.gM getMainInventorySlot(final int slot) {
        return getMainInventorySlot((com.craftrise.mg) Minecraft.GetPlayer(), slot);
    }

    public static com.craftrise.gM[] getArmorInventory(final com.craftrise.lU inventoryPlayer) {
        return inventoryPlayer.f;
    }

    public static com.craftrise.gM[] getArmorInventory(final com.craftrise.mg entityPlayer) {
        return getArmorInventory(ThePlayer.getInventory(entityPlayer));
    }

    public static com.craftrise.gM[] getArmorInventory() {
        return getArmorInventory((com.craftrise.mg) Minecraft.GetPlayer());
    }


    public static com.craftrise.gM getArmorInventorySlot(final com.craftrise.lU inventoryPlayer, final int slot) {
        return getArmorInventory(inventoryPlayer)[slot];
    }

    public static com.craftrise.gM getArmorInventorySlot(final com.craftrise.mg entityPlayer, final int slot) {
        return getArmorInventorySlot(entityPlayer.J, slot);
    }

    public static com.craftrise.gM getArmorInventorySlot(final int slot) {
        return getArmorInventorySlot((com.craftrise.mg) Minecraft.GetPlayer(), slot);
    }

    public static com.craftrise.gM getCurrentItemStack(final com.craftrise.lU inventoryPlayer) {
        if (getCurrentItemSlot(inventoryPlayer) < 0) {
            return null;
        }
        return getMainInventory(inventoryPlayer)[getCurrentItemSlot(inventoryPlayer)];
    }

    public static com.craftrise.gM getCurrentItemStack(final com.craftrise.mg entityPlayer) {
        return getCurrentItemStack(ThePlayer.getInventory(entityPlayer));
    }

    public static com.craftrise.gM getCurrentItemStack() {
        return getCurrentItemStack((com.craftrise.mg) Minecraft.GetPlayer());
    }

    public static int findItemInInventory(final int... itemIDs) {
        final com.craftrise.gM currentItemStack = getCurrentItemStack();
        if (currentItemStack != null) {
            int currentItemID = 0;

            try {
                Method getItem = filterMethodFromReturnTypeAndParams(b3.class, gM.class);
                Method getItemId = filterMethodFromReturnTypeAndParams(int.class , b3.class , b3.class);

                b3 itemobjj = (b3) getItem.invoke(currentItemStack);
                int id = (int) getItemId.invoke(null, itemobjj);
                currentItemID = id;

            }catch (Exception e)
            {
                Minecraft.addChatMessage(getStackTraceAsString(e));
            }

            for (final int itemID : itemIDs) {
                if (currentItemID == itemID) {
                    return getCurrentItemSlot();
                }
            }
        }
        for (int slot = 0; slot < 9; ++slot) {
            if (getCurrentItemSlot() != slot) {
                final com.craftrise.gM mainInventorySlot = getMainInventorySlot(slot);
                if (mainInventorySlot != null) {
                    int itemID = 0;

                    try {
                        Method getItem = filterMethodFromReturnTypeAndParams(b3.class, gM.class);
                        Method getItemId = filterMethodFromReturnTypeAndParams(int.class , b3.class , b3.class);

                        b3 itemobjj = (b3) getItem.invoke(mainInventorySlot);
                        int id = (int) getItemId.invoke(null, itemobjj);
                        itemID = id;

                    }catch (Exception e)
                    {
                        Minecraft.addChatMessage(getStackTraceAsString(e));
                    }

                    for (final int item : itemIDs) {
                        if (itemID == item) {
                            return slot;
                        }
                    }
                }
            }
        }
        return -1;
    }
}
