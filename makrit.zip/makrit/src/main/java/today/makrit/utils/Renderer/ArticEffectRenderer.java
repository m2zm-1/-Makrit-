package today.makrit.utils.Renderer;

import today.makrit.module.Module;
import today.makrit.utils.Helper.RenderHelper;
import today.makrit.utils.ReflectFields;

public class ArticEffectRenderer extends com.craftrise.client.fN {
    public ArticEffectRenderer(final com.craftrise.client.fN effectRenderer) {
        super(null, null);
        ReflectFields.copyNonStaticField(this, effectRenderer);
    }

    @Override
    public void a(final com.craftrise.m9 entity, final float float2, long l2) {
        RenderHelper.enableTransparencyAndBlend();
        Module.renderParticlesEvent(float2);
        RenderHelper.disableTransparencyAndEnableDepth();
        super.a(entity, float2, l2);
    }
}