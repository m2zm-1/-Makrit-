package today.makrit.utils.mapper;

import com.craftrise.m9;
import com.craftrise.mg;
import java.util.List;

public class TheWorld {
    public static List<m9> loadedEntityList() {
        return Minecraft.GetWorld().g;
    }

    public static List<mg> playerEntities() {
        return Minecraft.GetWorld().H;
    }
}
