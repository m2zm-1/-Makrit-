package today.makrit.utils.mapper;

import com.craftrise.dR;
import com.craftrise.m9;
import com.craftrise.mg;
import cr.launcher.BlockPos;
import cr.p;
import today.makrit.Main;
import today.net.minecraft.util.Vec3;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import static today.makrit.utils.mapper.Minecraft.GetMinecraft;

public class ThePlayer {
    private float yaw, pitch;
    public static int GetticksExisted;

    public static com.craftrise.client.dn getTeam() {
        Object result = null;

        try {
            for (Method m : GetMinecraft().getClass().getDeclaredMethods()) {
                if (m.getName().equals("b") && com.craftrise.client.dn.class.isAssignableFrom(m.getReturnType())) {
                    m.setAccessible(true);
                    result = m.invoke(GetMinecraft());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return (com.craftrise.client.dn) result;
    }


    public static double GetPosX(com.craftrise.m9 entity) {
        return entity.bE;
    }

    public static double GetPosY(com.craftrise.m9 entity) {
        return entity.aY;
    }

    public static double GetPosZ(com.craftrise.m9 entity) {
        return entity.bH;
    }

    public static double GetPosX() {
        return Minecraft.GetPlayer().bE;
    }

    public static double GetPosY() {
        return Minecraft.GetPlayer().aY;
    }

    public static double GetPosZ() {
        return Minecraft.GetPlayer().bH;
    }

    public static float GetRotationPitch() {
        return Minecraft.GetPlayer().N;
    }

    public static float GetrotationYaw(m9 entity) {
        return entity.bL;
    }

    public static float GetrotationYaw() {
        return Minecraft.GetPlayer().bL;
    }

    public static void sendMessage(final String message) {
        Minecraft.GetPlayer().b(message, 31);
    }

    public static void setPositionAndRotation(final double x, final double y, final double z, final float yaw, final float pitch) {
        setPositionAndRotation(Minecraft.GetPlayer(), x, y, z, yaw, pitch);
    }

    public static void setPositionAndRotation(final m9 entity, final double x, final double y, final double z, final float yaw, final float pitch) {
        entity.b(x, y, z, yaw, pitch, 31);
    }

    public static void setPositionAndRotation2(final m9 entity, final double x, final double y, final double z, final float yaw, final float pitch) {
        entity.b(x, y, z, yaw, pitch, 31);
    }

    public static double GetMotionX() {
        return Minecraft.GetPlayer().bh.b(5L);
    }

    public static double GetMotionY() {
        return Minecraft.GetPlayer().aT.b(5L);
    }

    public static double GetMotionZ() {
        return Minecraft.GetPlayer().bf.b(5L);
    }

    public static double removeEntity(com.craftrise.m9 entity) {
        return entity.b;
    }

    public static void SetMotionX(double d) {
        Minecraft.GetPlayer().bh = new dR(d);
    }

    public static void SetMotionY(double d) {
        Minecraft.GetPlayer().aT = new dR(d);
    }

    public static void SetMotionZ(double d) {
        Minecraft.GetPlayer().bf = new dR(d);
    }

    public static float renderYawOffset(float yaw) {
        Minecraft.GetPlayer().a = yaw;
        return yaw;
    }

    public static void rotationYawHead(float f) {
        Minecraft.GetPlayer().ap = f;
    }

    public static p jumpMovementFactor(float f) {
        return m9.R;
    }

    public static void rotationYawHead2(final BlockPos blockPos, final com.craftrise.lG enumFacing, final com.craftrise.k3 vec3, float f) {
        Minecraft.GetPlayer().ap = f;
    }

    public static void SetRotationYaw(float f) {
        Minecraft.GetPlayer().bL = f;
    }

    public static void SetRotationPitch(float f) {
        Minecraft.GetPlayer().N = f;
    }

    public static void setRotations(float yaw, float pitch) {
        ThePlayer.SetRotationYaw(yaw);
        ThePlayer.SetRotationPitch(pitch);
    }

    public static class AxisAlignedBB {
        public double minX;
        public double minY;
        public double minZ;
        public double maxX;
        public double maxY;
        public double maxZ;

        public AxisAlignedBB(final double x1, final double y1, final double z1, final double x2, final double y2,
                             final double z2) {
            this.minX = Math.min(x1, x2);
            this.minY = Math.min(y1, y2);
            this.minZ = Math.min(z1, z2);
            this.maxX = Math.max(x1, x2);
            this.maxY = Math.max(y1, y2);
            this.maxZ = Math.max(z1, z2);
        }

        /**
         * Adds the coordinates to the bounding box extending it if the point lies
         * outside the current ranges. Args: x, y, z
         */
        public AxisAlignedBB addCoord(final double x, final double y, final double z) {
            double d0 = this.minX;
            double d1 = this.minY;
            double d2 = this.minZ;
            double d3 = this.maxX;
            double d4 = this.maxY;
            double d5 = this.maxZ;

            if (x < 0.0D) {
                d0 += x;
            } else if (x > 0.0D) {
                d3 += x;
            }

            if (y < 0.0D) {
                d1 += y;
            } else if (y > 0.0D) {
                d4 += y;
            }

            if (z < 0.0D) {
                d2 += z;
            } else if (z > 0.0D) {
                d5 += z;
            }

            return new AxisAlignedBB(d0, d1, d2, d3, d4, d5);
        }

        /**
         * Returns a bounding box expanded by the specified vector (if negative numbers
         * are given it will shrink). Args: x, y, z
         */
        public AxisAlignedBB expand(final double x, final double y, final double z) {
            final double d0 = this.minX - x;
            final double d1 = this.minY - y;
            final double d2 = this.minZ - z;
            final double d3 = this.maxX + x;
            final double d4 = this.maxY + y;
            final double d5 = this.maxZ + z;
            return new AxisAlignedBB(d0, d1, d2, d3, d4, d5);
        }

        public AxisAlignedBB union(final AxisAlignedBB other) {
            final double d0 = Math.min(this.minX, other.minX);
            final double d1 = Math.min(this.minY, other.minY);
            final double d2 = Math.min(this.minZ, other.minZ);
            final double d3 = Math.max(this.maxX, other.maxX);
            final double d4 = Math.max(this.maxY, other.maxY);
            final double d5 = Math.max(this.maxZ, other.maxZ);
            return new AxisAlignedBB(d0, d1, d2, d3, d4, d5);
        }

        /**
         * returns an AABB with corners x1, y1, z1 and x2, y2, z2
         */
        public static AxisAlignedBB fromBounds(final double x1, final double y1, final double z1, final double x2,
                                               final double y2, final double z2) {
            final double d0 = Math.min(x1, x2);
            final double d1 = Math.min(y1, y2);
            final double d2 = Math.min(z1, z2);
            final double d3 = Math.max(x1, x2);
            final double d4 = Math.max(y1, y2);
            final double d5 = Math.max(z1, z2);
            return new AxisAlignedBB(d0, d1, d2, d3, d4, d5);
        }

        /**
         * Offsets the current bounding box by the specified coordinates. Args: x, y, z
         */
        public AxisAlignedBB offset(final double x, final double y, final double z) {
            return new AxisAlignedBB(this.minX + x, this.minY + y, this.minZ + z, this.maxX + x, this.maxY + y,
                    this.maxZ + z);
        }

        /**
         * if instance and the argument bounding boxes overlap in the Y and Z
         * dimensions, calculate the offset between them in the X dimension. return var2
         * if the bounding boxes do not overlap or if var2 is closer to 0 then the
         * calculated offset. Otherwise return the calculated offset.
         */
        public double calculateXOffset(final AxisAlignedBB other, double offsetX) {
            if (other.maxY > this.minY && other.minY < this.maxY && other.maxZ > this.minZ && other.minZ < this.maxZ) {
                if (offsetX > 0.0D && other.maxX <= this.minX) {
                    final double d1 = this.minX - other.maxX;

                    if (d1 < offsetX) {
                        offsetX = d1;
                    }
                } else if (offsetX < 0.0D && other.minX >= this.maxX) {
                    final double d0 = this.maxX - other.minX;

                    if (d0 > offsetX) {
                        offsetX = d0;
                    }
                }

                return offsetX;
            } else {
                return offsetX;
            }
        }

        /**
         * if instance and the argument bounding boxes overlap in the X and Z
         * dimensions, calculate the offset between them in the Y dimension. return var2
         * if the bounding boxes do not overlap or if var2 is closer to 0 then the
         * calculated offset. Otherwise return the calculated offset.
         */
        public double calculateYOffset(final AxisAlignedBB other, double offsetY) {
            if (other.maxX > this.minX && other.minX < this.maxX && other.maxZ > this.minZ && other.minZ < this.maxZ) {
                if (offsetY > 0.0D && other.maxY <= this.minY) {
                    final double d1 = this.minY - other.maxY;

                    if (d1 < offsetY) {
                        offsetY = d1;
                    }
                } else if (offsetY < 0.0D && other.minY >= this.maxY) {
                    final double d0 = this.maxY - other.minY;

                    if (d0 > offsetY) {
                        offsetY = d0;
                    }
                }

                return offsetY;
            } else {
                return offsetY;
            }
        }

        /**
         * if instance and the argument bounding boxes overlap in the Y and X
         * dimensions, calculate the offset between them in the Z dimension. return var2
         * if the bounding boxes do not overlap or if var2 is closer to 0 then the
         * calculated offset. Otherwise return the calculated offset.
         */
        public double calculateZOffset(final AxisAlignedBB other, double offsetZ) {
            if (other.maxX > this.minX && other.minX < this.maxX && other.maxY > this.minY && other.minY < this.maxY) {
                if (offsetZ > 0.0D && other.maxZ <= this.minZ) {
                    final double d1 = this.minZ - other.maxZ;

                    if (d1 < offsetZ) {
                        offsetZ = d1;
                    }
                } else if (offsetZ < 0.0D && other.minZ >= this.maxZ) {
                    final double d0 = this.maxZ - other.minZ;

                    if (d0 > offsetZ) {
                        offsetZ = d0;
                    }
                }

                return offsetZ;
            } else {
                return offsetZ;
            }
        }

        /**
         * Returns whether the given bounding box intersects with this one. Args:
         * axisAlignedBB
         */
        public boolean intersectsWith(final AxisAlignedBB other) {
            return other.maxX > this.minX && other.minX < this.maxX && (other.maxY > this.minY && other.minY < this.maxY
                    && other.maxZ > this.minZ && other.minZ < this.maxZ);
        }


        /**
         * Returns if the supplied Vec3D is completely inside the bounding box
         */
        public boolean isVecInside(final Vec3 vec) {
            return vec.xCoord > this.minX && vec.xCoord < this.maxX && (vec.yCoord > this.minY && vec.yCoord < this.maxY
                    && vec.zCoord > this.minZ && vec.zCoord < this.maxZ);
        }

        /**
         * Returns the average length of the edges of the bounding box.
         */
        public double getAverageEdgeLength() {
            final double d0 = this.maxX - this.minX;
            final double d1 = this.maxY - this.minY;
            final double d2 = this.maxZ - this.minZ;
            return (d0 + d1 + d2) / 3.0D;
        }

        /**
         * Returns a bounding box that is inset by the specified amounts
         */
        public AxisAlignedBB contract(final double x, final double y, final double z) {
            final double d0 = this.minX + x;
            final double d1 = this.minY + y;
            final double d2 = this.minZ + z;
            final double d3 = this.maxX - x;
            final double d4 = this.maxY - y;
            final double d5 = this.maxZ - z;
            return new AxisAlignedBB(d0, d1, d2, d3, d4, d5);
        }

        public String toString() {
            return "box[" + this.minX + ", " + this.minY + ", " + this.minZ + " -> " + this.maxX + ", " + this.maxY + ", "
                    + this.maxZ + "]";
        }

        public boolean func_181656_b() {
            return Double.isNaN(this.minX) || Double.isNaN(this.minY) || Double.isNaN(this.minZ) || Double.isNaN(this.maxX)
                    || Double.isNaN(this.maxY) || Double.isNaN(this.maxZ);
        }

        /**
         * Checks if the specified vector is within the YZ dimensions of the bounding box. Args: Vec3D
         */
        private boolean isVecInYZ(Vec3 vec) {
            return vec != null && vec.yCoord >= this.minY && vec.yCoord <= this.maxY && vec.zCoord >= this.minZ && vec.zCoord <= this.maxZ;
        }

        /**
         * Checks if the specified vector is within the XZ dimensions of the bounding box. Args: Vec3D
         */
        private boolean isVecInXZ(Vec3 vec) {
            return vec != null && vec.xCoord >= this.minX && vec.xCoord <= this.maxX && vec.zCoord >= this.minZ && vec.zCoord <= this.maxZ;
        }

        /**
         * Checks if the specified vector is within the XY dimensions of the bounding box. Args: Vec3D
         */
        private boolean isVecInXY(Vec3 vec) {
            return vec != null && vec.xCoord >= this.minX && vec.xCoord <= this.maxX && vec.yCoord >= this.minY && vec.yCoord <= this.maxY;
        }

        // Getter ve Setter metotları

        public double getMinX() {
            return minX;
        }

        public void setMinX(double minX) {
            this.minX = minX;
        }

        public double getMinY() {
            return minY;
        }

        public void setMinY(double minY) {
            this.minY = minY;
        }

        public double getMinZ() {
            return minZ;
        }

        public void setMinZ(double minZ) {
            this.minZ = minZ;
        }

        public double getMaxX() {
            return maxX;
        }

        public void setMaxX(double maxX) {
            this.maxX = maxX;
        }

        public double getMaxY() {
            return maxY;
        }

        public void setMaxY(double maxY) {
            this.maxY = maxY;
        }

        public double getMaxZ() {
            return maxZ;
        }

        public void setMaxZ(double maxZ) {
            this.maxZ = maxZ;
        }

    }

    private AxisAlignedBB boundingBox;

    public void setEntitySize(double width, double height) {
        this.boundingBox.setMinX(0.0);
        this.boundingBox.setMinY(0.0);
        this.boundingBox.setMinZ(0.0);
        this.boundingBox.setMaxX(width);
        this.boundingBox.setMaxY(height);
        this.boundingBox.setMaxZ(width);
    }

    public static int GethurtResistantTime() {
        return Minecraft.GetPlayer().bK;
    }

    public static int setHurtTime(double d) {
        return Minecraft.GetPlayer().a5;
    }

    public double GetprevPosX(com.craftrise.m9 entity) {
        return entity.a4;
    }


    public double GetprevPosY(com.craftrise.m9 entity) {
        return entity.L;
    }

    public static double GetprevPosZ(com.craftrise.m9 entity) {
        return entity.at;
    }

    public double GetprevPosX() {
        return Minecraft.GetPlayer().a4;
    }


    public double GetprevPosY() {
        return Minecraft.GetPlayer().L;
    }

    public static double GetprevPosZ() {
        return Minecraft.GetPlayer().at;
    }

    public float GetprevRotationYaw() {
        return Minecraft.GetPlayer().C;
    }

    public float GetprevRotationPitch() {
        return Minecraft.GetPlayer().aM;
    }

    public int Getdimension() {
        return Minecraft.GetPlayer().ac;
    }

    public int GetportalCounter() {
        return Minecraft.GetPlayer().m;
    }

    public int GetchunkCoordX() {
        return Minecraft.GetPlayer().aV;
    }

    public int GetfireResistance() {
        return Minecraft.GetPlayer().aE;
    }

    public int Getfire() {
        return Minecraft.GetPlayer().aN;
    }

    public static int GetticksExisted() {
        return Minecraft.GetPlayer().Z;
    }

    public float GetentityCollisionReduction() {
        return Minecraft.GetPlayer().ap;
    }

    public boolean GetnoClip() {
        return Minecraft.GetPlayer().by;
    }

    public static double GetlastTickPosX(com.craftrise.m9 entity) {
        return entity.a6;
    }

    public static double GetlastTickPosY(com.craftrise.m9 entity) {
        return entity.h;
    }

    public static double GetlastTickPosZ(com.craftrise.m9 entity) {
        return entity.G;
    }


    public static com.craftrise.lU getInventory(final com.craftrise.mg entityPlayer) {
        return entityPlayer.J;
    }

    public static com.craftrise.lU getInventory() {
        return getInventory(Minecraft.GetPlayer());
    }

    public static com.craftrise.qJ getInventoryContainer(final com.craftrise.mg entityPlayer) {
        return entityPlayer.b1;
    }

    public static com.craftrise.qJ getInventoryContainer() {
        return getInventoryContainer(Minecraft.GetPlayer());
    }

    public static com.craftrise.qJ openContainer(final com.craftrise.mg entityPlayer) {
        return entityPlayer.T;
    }

    public static boolean checkAdjacentAndPerformAction(final com.craftrise.gM itemStack, final int x, final int y, final int z) {
        for (int i = 0; i < 6; ++i) {
            int newX = x;
            int newY = y;
            int newZ = z;
            if (i == 0) {
                ++newY;
            } else if (i == 1) {
                --newY;
            } else if (i == 2) {
                ++newZ;
            } else if (i == 3) {
                --newZ;
            } else if (i == 4) {
                ++newX;
            } else {
                --newX;
            }
            final BlockPos blockPos = new BlockPos(newX, newY, newZ);
            //if (BlockHelper.getBlockID(blockPos) != 0) {
            //    if (NeptunePlayerController.onPlayerRightClick(itemStack, blockPos, EnumFacing.values()[i], new Vec3((double) newX, (double) newY, (double) newZ))) {
            //        swingItem();
            //    }
            //    return true;
            //}
        }
        return false;
    }

    public static double GetlastTickPosX() {
        return Minecraft.GetPlayer().a6;
    }

    public static double GetlastTickPosY() {
        return Minecraft.GetPlayer().h;
    }

    public static double GetlastTickPosZ() {
        return Minecraft.GetPlayer().G;
    }

    public static float Getwidth() {
        return Minecraft.GetPlayer().aw;
    }

    public static float Getheight() {
        return Minecraft.GetPlayer().t;
    }

    public float GetprevDistanceWalkedModified() {
        return Minecraft.GetPlayer().aG;
    }

    public boolean GetisCollided() {
        return Minecraft.GetPlayer().a1;
    }

    public static boolean GetisInWeb() {
        return Minecraft.GetPlayer().al;
    }

    public static boolean isCollidedHorizontally() {
        return Minecraft.GetPlayer().ax;
    }

    public static boolean isCollidedVertically() {
        return Minecraft.GetPlayer().aL;
    }

    public boolean GetisDead() {
        return Minecraft.GetPlayer().d;
    }

    public static void SetprevPosX(double d) {
        Minecraft.GetPlayer().a4 = d;
    }

    public static void SetprevPosY(double d) {
        Minecraft.GetPlayer().L = d;
    }

    public static void SetprevPosZ(double d) {
        Minecraft.GetPlayer().at = d;
    }

    public static void SetprevRotationYaw(float f) {
        Minecraft.GetPlayer().C = f;
    }

    public static void SetprevRotationPitch(float f) {
        Minecraft.GetPlayer().aM = f;
    }

    public static void Setdimension(int n) {
        Minecraft.GetPlayer().ac = n;
    }

    public static void SetportalCounter(int n) {
        Minecraft.GetPlayer().m = n;
    }

    public static void SetchunkCoordX(int n) {
        Minecraft.GetPlayer().aV = n;
    }

    public static void SetfireResistance(int n) {
        Minecraft.GetPlayer().aE = n;
    }

    public static void Setfire(int n) {
        Minecraft.GetPlayer().aN = n;
    }

    public static void SetticksExisted(int n) {
        Minecraft.GetPlayer().Z = n;
    }

    public static void SetentityCollisionReduction(float f) {
        Minecraft.GetPlayer().ap = f;
    }

    public static void SetnoClip(boolean bl) {
        Minecraft.GetPlayer().by = bl;
    }

    public static void SetlastTickPosX(double d) {
        Minecraft.GetPlayer().a6 = d;
    }

    public static void SetlastTickPosY(double d) {
        Minecraft.GetPlayer().h = d;
    }

    public static void SetlastTickPosZ(double d) {
        Minecraft.GetPlayer().G = d;
    }

    public static void Setwidth(float f) {
        Minecraft.GetPlayer().aw = f;
    }

    public static void Setheight(float f) {
        Minecraft.GetPlayer().t = f;
    }

    public static void SetprevDistanceWalkedModified(float f) {
        Minecraft.GetPlayer().aG = f;
    }

    public static void SetisCollidedHorizontally(boolean bl) {
        Minecraft.GetPlayer().ax = bl;
    }

    public static void SetisCollidedVertically(boolean bl) {
        Minecraft.GetPlayer().aL = bl;
    }

    public static void SetisCollided(boolean bl) {
        Minecraft.GetPlayer().a1 = bl;
    }

    public static void SetisInWeb(boolean bl) {
        Minecraft.GetPlayer().al = bl;
    }

    public static void SetisDead(boolean bl) {
        Minecraft.GetPlayer().d = bl;
    }

    public static boolean isDead(mg target) {
        return target.d;
    }

    public int GetsprintingTicksLeft() {
        return Minecraft.GetPlayer().m;
    }

    public float GetrenderArmYaw() {
        return Minecraft.GetPlayer().bb;
    }

    public float GetrenderArmPitch() {
        return Minecraft.GetPlayer().aG;
    }

    public float GetprevRenderArmYaw() {
        return Minecraft.GetPlayer().aO;
    }

    public float GetprevRenderArmPitch() {
        return Minecraft.GetPlayer().t;
    }

    public float GettimeInPortal() {
        return Minecraft.GetPlayer().bg;
    }

    public float GetprevTimeInPortal() {
        return Minecraft.GetPlayer().bC;
    }

    public static void SetsprintingTicksLeft(int n) {
        Minecraft.GetPlayer().m = n;
    }

    public static void SetrenderArmYaw(float f) {
        Minecraft.GetPlayer().bb = f;
    }

    public static void SetrenderArmPitch(float f) {
        Minecraft.GetPlayer().aG = f;
    }

    public static void SetprevRenderArmYaw(float f) {
        Minecraft.GetPlayer().aO = f;
    }

    public static void SetprevRenderArmPitch(float f) {
        Minecraft.GetPlayer().t = f;
    }

    public static void SettimeInPortal(float f) {
        Minecraft.GetPlayer().bg = f;
    }

    public static void SetprevTimeInPortal(float f) {
        Minecraft.GetPlayer().bC = f;
    }

    public int GetsleepTimer() {
        return Minecraft.GetPlayer().m;
    }

    public float GetrenderOffsetY() {
        return Minecraft.GetPlayer().aO;
    }

    public float GetrenderOffsetZ() {
        return Minecraft.GetPlayer().bb;
    }

    public int GetexperienceLevel() {
        return Minecraft.GetPlayer().a9;
    }

    public int GetexperienceTotal() {
        return Minecraft.GetPlayer().aW;
    }

    public float Getexperience() {
        return Minecraft.GetPlayer().cB;
    }

    public int GetxpCooldown() {
        return Minecraft.GetPlayer().br;
    }

    public double GetprevChasingPosY() {
        return Minecraft.GetPlayer().ch;
    }

    public double GetchasingPosZ() {
        return Minecraft.GetPlayer().cI;
    }

    public float GetprevCameraYaw() {
        return Minecraft.GetPlayer().b_;
    }

    public static void SetsleepTimer(int n) {
        Minecraft.GetPlayer().m = n;
    }

    public static void SetrenderOffsetY(float f) {
        Minecraft.GetPlayer().aO = f;
    }

    public static void SetrenderOffsetZ(float f) {
        Minecraft.GetPlayer().bb = f;
    }

    public static void SetexperienceLevel(int n) {
        Minecraft.GetPlayer().a9 = n;
    }

    public static void SetexperienceTotal(int n) {
        Minecraft.GetPlayer().aW = n;
    }

    public static void Setexperience(float f) {
        Minecraft.GetPlayer().cB = f;
    }

    public static void SetxpCooldown(int n) {
        Minecraft.GetPlayer().br = n;
    }

    public static void SetprevChasingPosY(double d) {
        Minecraft.GetPlayer().ch = d;
    }

    public static void SetchasingPosZ(double d) {
        Minecraft.GetPlayer().cI = d;
    }

    public static void SetprevCameraYaw(float f) {
        Minecraft.GetPlayer().b_ = f;
    }

    public static float GetDistanceToEntity(m9 m92) throws InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        Class<?> clazz = m92.getClass();
        Method method = clazz.getMethod("a", m9.class);
        float f = ((Float) method.invoke((Object) m92, new Object[0])).floatValue();
        return f;
    }

    public static double Direction() {
        float f = ThePlayer.GetrotationYaw();
        if (Minecraft.GetPlayer().l.b.a(5L) < 0.0f) {
            f += 180.0f;
        }
        float f2 = 1.0f;
        if (Minecraft.GetPlayer().l.b.a(5L) < 0.0f) {
            f2 = -0.5f;
        } else if (Minecraft.GetPlayer().l.b.a(5L) > 0.0f) {
            f2 = 0.5f;
        }
        if (Minecraft.GetPlayer().l.c.a(5L) > 0.0f) {
            f -= 90.0f * f2;
        }
        if (Minecraft.GetPlayer().l.c.a(5L) < 0.0f) {
            f += 90.0f * f2;
        }
        return Math.toRadians(f);
    }

    public static void Strafe(float f) {
        if (!ThePlayer.isMoving()) {
            return;
        }
        ThePlayer.SetMotionX(-Math.sin(ThePlayer.Direction()) * (double) f);
        ThePlayer.SetMotionZ(Math.cos(ThePlayer.Direction()) * (double) f);
    }

    public static float GetSpeed() {
        return (float) Math.sqrt(ThePlayer.GetMotionX() * ThePlayer.GetMotionX() + ThePlayer.GetMotionZ() * ThePlayer.GetMotionZ());
    }

    public static boolean isMoving() {
        return Minecraft.GetPlayer() != null && (Minecraft.GetPlayer().l.b.a(5L) != 0.0f || Minecraft.GetPlayer().l.c.a(5L) != 0.0f);
    }

    public static boolean onGround() {
        return Minecraft.GetPlayer().s.a(522424L);
    }

    public static boolean onGround2(boolean bl) {
        return Minecraft.GetPlayer().s.a(522424L);
    }
    public static void scaffoldjump() {
        try {
            Class<?> clazz = Class.forName("com.craftrise.mg");
            Method method = clazz.getMethod("y", Long.TYPE);
            method.setAccessible(true);
            method.invoke(Minecraft.GetPlayer(), 8L);
        }
        catch (Exception exception) {
            Minecraft.addChatMessage(exception.toString() + " Exception");
        }
    }
    public static void jump() {
        try {
            Class<?> clazz = Class.forName("com.craftrise.mg");
            Method method = clazz.getMethod("y", Long.TYPE);
            method.setAccessible(true);
            method.invoke((Object) Minecraft.GetPlayer(), 5L);
        } catch (Exception exception) {
            Minecraft.addChatMessage(exception.toString() + " Exception");
        }
    }

    public static void setPosition_mid(double d1, double d2, double d3) {
        try {
            Class EntityClazz = Class.forName("com.craftrise.m9");

            for (Method m : EntityClazz.getDeclaredMethods()) {
                if (m.getName().contains("b")) {
                    if (m.getParameterCount() == 4) {
                        m.setAccessible(true);
                        m.invoke((Object) Minecraft.GetPlayer(), d1, d2, d3, Main.idk);
                    }
                }
            }
        } catch (Exception e) {
            Minecraft.addChatMessage(e.toString() + " Exception");
        }
    }
}
