package today.makrit.utils;

import java.lang.reflect.Modifier;
import java.lang.reflect.Field;

public class ReflectFields {
    /*public static FieldHelper renderManager;
    public static FieldHelper itemRenderer;
    public static FieldHelper renderViewEntity;
    public static FieldHelper leftClickCounter;
    public static FieldHelper rightClickDelayTimer;
    public static FieldHelper myNetworkManager;
    public static FieldHelper mcResourceManager;
    public static FieldHelper entityId;
    public static FieldHelper dead;
    public static FieldHelper jumpTicks;
    public static FieldHelper playerInfo;
    public static FieldHelper displayName;
    public static FieldHelper item;
    public static FieldHelper stackTagCompound;
    public static FieldHelper itemDamage;
    public static FieldHelper directionVec;
    public static FieldHelper netClientHandler;
    public static FieldHelper curBlockDamageMP;
    public static FieldHelper blockHitDelay;
    public static FieldHelper action;
    public static FieldHelper keyCode;
    public static FieldHelper isKeyDown;
    public static FieldHelper movementInputForward;
    public static FieldHelper tileEntity_pos;
    public static FieldHelper tileEntity_blockType;
    public static FieldHelper lowerChestInventory;
    public static FieldHelper flySpeed;
    public static FieldHelper resourceManager;
    public static FieldHelper netManager;
    public static FieldHelper isEncrypted;
    public static FieldHelper maxDamage;*/

    public static Field getField(final Class class1, final String string) {
        Field[] declaredFields;
        for (int length = (declaredFields = class1.getDeclaredFields()).length, i = 0; i < length; ++i) {
            final Field field = declaredFields[i];
            if (field.getName().equals(string)) {
                field.setAccessible(true);
                return field;
            }
        }
        return null;
    }

    public static void copyNonStaticField(final Object object1, final Object object2, final Class class3) {
        if (class3 != Object.class) {
            Field[] declaredFields;
            for (int length = (declaredFields = class3.getDeclaredFields()).length, i = 0; i < length; ++i) {
                final Field field = declaredFields[i];
                if (!Modifier.isStatic(field.getModifiers())) {
                    field.setAccessible(true);
                    try {
                        field.set(object1, field.get(object2));
                    } catch (IllegalArgumentException ex) {
                    } catch (IllegalAccessException ex2) {
                    }
                }
            }
            copyNonStaticField(object1, object2, class3.getSuperclass());
        }
    }

    public static void copyNonStaticField(final Object object1, final Object object2) {
        copyNonStaticField(object1, object2, object2.getClass());
    }

    public static Object copyNonStaticField(final Class class1, final Object object) {
        try {
            final Object instance = class1.newInstance();
            if (object.getClass().isInstance(instance)) {
                copyNonStaticField(instance, object);
            }
            return instance;
        } catch (InstantiationException | IllegalAccessException ex) {
            return null;
        }
    }
}
