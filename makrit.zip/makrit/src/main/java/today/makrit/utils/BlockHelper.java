package today.makrit.utils;

import com.craftrise.dN;
import cr.launcher.BlockPos;
import today.makrit.utils.mapper.Minecraft;
import java.util.ArrayList;
import java.util.List;

public class BlockHelper {
   public static int getX(BlockPos pos) {
      return pos.c();
   }

   public static int getY(BlockPos pos) {
      return pos.b();
   }

   public static int getZ(BlockPos pos) {
      return pos.a();
   }

   public static List<BlockPos> getAdjacentBlockPositions(int n, int n2, int n3, char n4) {
      ArrayList<BlockPos> arrayList = new ArrayList();

      for(int n5 = 1; n5 < n4; ++n5) {
         int n6;
         for(int n7 = n6 = n5 * -1; n7 <= n5; ++n7) {
            for(int n8 = n6; n8 <= n5; ++n8) {
               for(int n9 = n6; n9 <= n5; ++n9) {
                  if (Math.abs(n8) + Math.abs(n7) + Math.abs(n9) == n5 && n7 + n2 > 0) {
                     arrayList.add(new BlockPos(n + n8, n2 + n7, n3 + n9));
                  }
               }
            }
         }
      }

      return arrayList;
   }

   public static List<BlockPos> getSurroundingBlockPositions(int x, int y, int z, char limit) {
      ArrayList<BlockPos> positions = new ArrayList();

      int i;
      for(char c = 1; c < limit; ++c) {
         for(int n = i = c * -1; i <= c; ++i) {
            for(int j = n; j <= c; ++j) {
               for(int k = n; k <= c; ++k) {
                  if (Math.abs(j) + Math.abs(i) + Math.abs(k) == c && y + i > 0) {
                     positions.add(new BlockPos(x + j, y + i, z + k));
                  }
               }
            }
         }
      }

      return positions;
   }

   public static List<BlockPos> getBlockPositions(int x, int y, int z, char limit) {
      ArrayList<BlockPos> positions = new ArrayList();

      int i;
      for(char c = 1; c < limit; ++c) {
         for(int n = i = c * -1; i <= c; ++i) {
            for(int j = n; j <= c; ++j) {
               for(int k = n; k <= c; ++k) {
                  if (y + i > 0) {
                     positions.add(new BlockPos(x + j, y + i, z + k));
                  }
               }
            }
         }
      }

      return positions;
   }

   public static int getIdFromBlock(dN block) {
      try {
         return dN.a(block);
      } catch (Exception var2) {
         Minecraft.addChatMessage(var2.toString());
         return 333333;
      }
   }
}
