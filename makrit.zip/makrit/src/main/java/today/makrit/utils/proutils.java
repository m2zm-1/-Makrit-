package today.makrit.utils;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;

public class proutils {
    public static Field getField(final Class class1, final String string) {
        Field[] declaredFields;
        for (int length = (declaredFields = class1.getDeclaredFields()).length, i = 0; i < length; ++i) {
            final Field field = declaredFields[i];
            if (field.getName().equals(string)) {
                field.setAccessible(true);
                return field;
            }
        }
        return null;
    }

    public static void copy(final Object object1, final Object object2, final Class class3, Class... excluded) {
        if (class3 != Object.class) {
            Field[] declaredFields;
            for (int length = (declaredFields = class3.getDeclaredFields()).length, i = 0; i < length; ++i) {
                final Field field = declaredFields[i];
                boolean exc = false;
                for (Class aClass : excluded) {
                    if(field.getType() == aClass) {
                        exc = true;
                        break;
                    }
                }
                if (!Modifier.isStatic(field.getModifiers()) && !exc) {
                    field.setAccessible(true);
                    try {
                        field.set(object1, field.get(object2));
                    } catch (IllegalArgumentException ex) {
                    } catch (IllegalAccessException ex2) {
                    }
                }
            }
            copy(object1, object2, class3.getSuperclass());
        }
    }

    public static void copy(final Object object1, final Object object2) {
        copy(object1, object2, object2.getClass());
    }

    public static Object  copy(final Class class1, final Object object) {
        try {
            final Object instance = class1.newInstance();
            if (object.getClass().isInstance(instance)) {
                copy(instance, object);
            }
            return instance;
        } catch (InstantiationException | IllegalAccessException ex) {
            return null;
        }
    }

    public static Method filterMethodFromReturnTypeAndParams(Class<?> wantedReturnType, Class<?> clazz, Class<?>... params) {
        try {
            asd: for (Method declaredMethod : clazz.getDeclaredMethods()) {
                for (Method method : clazz.getSuperclass().getDeclaredMethods()) {
                    if (declaredMethod.equals(method))
                        continue asd;
                }
                if (declaredMethod.getReturnType().equals(wantedReturnType) && Arrays.equals(declaredMethod.getParameterTypes(), params))
                    return declaredMethod;
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
