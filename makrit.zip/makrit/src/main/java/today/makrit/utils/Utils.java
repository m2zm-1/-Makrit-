package today.makrit.utils;

import today.net.minecraft.client.Minecraft;
import today.net.minecraft.client.gui.FontRenderer;

public interface Utils
{
    Minecraft mc = Minecraft.getMinecraft();
    FontRenderer fr = mc.fontRendererObj;
}
