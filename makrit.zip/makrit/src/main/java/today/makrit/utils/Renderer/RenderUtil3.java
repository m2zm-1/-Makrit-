package today.makrit.utils.Renderer;

import com.craftrise.ah;
import com.craftrise.m9;
import com.craftrise.client.bO;
import com.jhlabs.image.GaussianFilter;
import cr.launcher.Config;
import net.minecraft.util.MathHelper;
import today.makrit.Main;
import today.makrit.font.FontUtil;
import today.makrit.utils.mapper.GlStateManager;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Objects;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.opengl.GL11;

public class RenderUtil3 {
   private static int currentColorIndex = 0;
   private static final HashMap<Integer, Integer> shadowCache = new HashMap();
   public static double ticks = 0.0D;
   public static long lastFrame = 0L;

   public static Color getRainbow(int offset, int speed) {
      float hue = (float)((System.currentTimeMillis() + (long)offset) % (long)speed);
      hue /= (float)speed;
      return Color.getHSBColor(hue, 0.7F, 1.0F);
   }

   public static void drawGradient(double x, double y, double x2, double y2, int col1, int col2) {
      float f = (float)(col1 >> 24 & 255) / 255.0F;
      float f1 = (float)(col1 >> 16 & 255) / 255.0F;
      float f2 = (float)(col1 >> 8 & 255) / 255.0F;
      float f3 = (float)(col1 & 255) / 255.0F;
      float f4 = (float)(col2 >> 24 & 255) / 255.0F;
      float f5 = (float)(col2 >> 16 & 255) / 255.0F;
      float f6 = (float)(col2 >> 8 & 255) / 255.0F;
      float f7 = (float)(col2 & 255) / 255.0F;
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2848);
      GL11.glShadeModel(7425);
      GL11.glPushMatrix();
      GL11.glBegin(7);
      GL11.glColor4f(f1, f2, f3, f);
      GL11.glVertex2d(x2, y);
      GL11.glVertex2d(x, y);
      GL11.glColor4f(f5, f6, f7, f4);
      GL11.glVertex2d(x, y2);
      GL11.glVertex2d(x2, y2);
      GL11.glEnd();
      GL11.glPopMatrix();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glShadeModel(7424);
      GL11.glColor4d(1.0D, 1.0D, 1.0D, 1.0D);
   }

   public static void drawGradientSideways(double left, double top, double right, double bottom, int col1, int col2) {
      float f = (float)(col1 >> 24 & 255) / 255.0F;
      float f1 = (float)(col1 >> 16 & 255) / 255.0F;
      float f2 = (float)(col1 >> 8 & 255) / 255.0F;
      float f3 = (float)(col1 & 255) / 255.0F;
      float f4 = (float)(col2 >> 24 & 255) / 255.0F;
      float f5 = (float)(col2 >> 16 & 255) / 255.0F;
      float f6 = (float)(col2 >> 8 & 255) / 255.0F;
      float f7 = (float)(col2 & 255) / 255.0F;
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2848);
      GL11.glShadeModel(7425);
      GL11.glPushMatrix();
      GL11.glBegin(7);
      GL11.glColor4f(f1, f2, f3, f);
      GL11.glVertex2d(left, top);
      GL11.glVertex2d(left, bottom);
      GL11.glColor4f(f5, f6, f7, f4);
      GL11.glVertex2d(right, bottom);
      GL11.glVertex2d(right, top);
      GL11.glEnd();
      GL11.glPopMatrix();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glShadeModel(7424);
   }

   public static void drawRectBordered(double x, double y, double x1, double y1, double width, int internalColor, int borderColor) {
      drawRect(x + width, y + width, x1 - width, y1 - width, internalColor);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      drawRect(x + width, y, x1 - width, y + width, borderColor);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      drawRect(x, y, x + width, y1, borderColor);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      drawRect(x1 - width, y, x1, y1, borderColor);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      drawRect(x + width, y1 - width, x1 - width, y1, borderColor);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
   }

   public static void drawBorderedRect(int x1, int y1, int x2, int y2, int color) {
      drawRect((double)x1, (double)y1, (double)(x2 + x1), (double)(1 + y1), color);
      drawRect((double)x1, (double)(y1 + 1), (double)(1 + x1), (double)(y2 + y1), color);
      drawRect((double)(x1 + 1), (double)(y1 + y2 - 1), (double)(x2 + x1), (double)(y2 + y1), color);
      drawRect((double)(x1 + x2 - 1), (double)(y1 + 1), (double)(x1 + x2), (double)(y2 + y1 - 1), color);
   }

   public static void drawBorderedRect(double left, double top, double right, double bottom, double borderWidth, int insideColor, int borderColor, boolean borderIncludedInBounds) {
      drawRect(left - (!borderIncludedInBounds ? borderWidth : 0.0D), top - (!borderIncludedInBounds ? borderWidth : 0.0D), right + (!borderIncludedInBounds ? borderWidth : 0.0D), bottom + (!borderIncludedInBounds ? borderWidth : 0.0D), borderColor);
      drawRect(left + (borderIncludedInBounds ? borderWidth : 0.0D), top + (borderIncludedInBounds ? borderWidth : 0.0D), right - (borderIncludedInBounds ? borderWidth : 0.0D), bottom - (borderIncludedInBounds ? borderWidth : 0.0D), insideColor);
   }

   public static void drawRectBetter(double x, double y, double width, double height, int color) {
      drawRect(x, y, x + width, y + height, color);
   }

   public static void drawCircle(m9 entity, float partialTicks, double rad, int color, float alpha) {
      ticks += 0.004D * (double)(System.currentTimeMillis() - lastFrame);
      lastFrame = System.currentTimeMillis();
      GL11.glPushMatrix();
      GL11.glDisable(3553);
      GL11.glEnable(3042);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      GL11.glBlendFunc(770, 771);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      GL11.glShadeModel(7425);
      double x = interpolate(entity.a6, entity.bE, (double)Config.renderPartialTicks) - Minecraft.getRenderManager().j;
      double y = interpolate(entity.h, entity.aY, (double)Config.renderPartialTicks) - Minecraft.getRenderManager().t + Math.sin(ticks) + 1.0D;
      double z = interpolate(entity.G, entity.bH, (double)Config.renderPartialTicks) - Minecraft.getRenderManager().c;
      GL11.glBegin(5);

      for(float i = 0.0F; (double)i < 6.283185307179586D; i = (float)((double)i + 0.09817477042468103D)) {
         double vecX = x + rad * Math.cos((double)i);
         double vecZ = z + rad * Math.sin((double)i);
         color(color, 0.0F);
         GL11.glVertex3d(vecX, y - Math.sin(ticks + 1.0D) / 2.700000047683716D, vecZ);
         color(color, 0.52F * alpha);
         GL11.glVertex3d(vecX, y, vecZ);
      }

      GL11.glEnd();
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(1.5F);
      GL11.glBegin(3);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      color(color, 0.5F * alpha);

      for(int i = 0; i <= 180; ++i) {
         GL11.glVertex3d(x - Math.sin((double)((float)i * MathHelper.PI2 / 90.0F)) * rad, y, z + Math.cos((double)((float)i * MathHelper.PI2 / 90.0F)) * rad);
      }

      GL11.glEnd();
      GL11.glShadeModel(7424);
      GL11.glDepthMask(true);
      GL11.glEnable(2929);
      GL11.glDisable(2848);
      GL11.glEnable(3553);
      GL11.glPopMatrix();
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
   }

   public static void setAlphaLimit(float limit) {
      GlStateManager.enableAlpha();
      GlStateManager.alphaFunc(516, (float)((double)limit * 0.01D));
   }

   public static void scissor(double x, double y, double width, double height, Runnable data) {
      GL11.glEnable(3089);
      scissor(x, y, width, height);
      data.run();
      GL11.glDisable(3089);
   }

   public void polygon(double x, double y, double sideLength, int amountOfSides, boolean filled) {
      polygon(x, y, sideLength, (double)amountOfSides, filled, (Color)null);
   }

   public static void scissorStart(double x, double y, double width, double height) {
      GL11.glEnable(3089);
      ScaledResolution sr = new ScaledResolution(net.minecraft.client.Minecraft.getMinecraft());
      double scale = (double)sr.getScaleFactor();
      double finalHeight = height * scale;
      double finalY = ((double)sr.getScaledHeight() - y) * scale;
      double finalX = x * scale;
      double finalWidth = width * scale;
      GL11.glScissor((int)finalX, (int)(finalY - finalHeight), (int)finalWidth, (int)finalHeight);
   }

   public static void scissorEnd() {
      GL11.glDisable(3089);
   }

   public static void polygon(double x, double y, double sideLength, int amountOfSides, Color color) {
      polygon(x, y, sideLength, (double)amountOfSides, true, color);
   }

   public static void drawBlurredShadow(float x, float y, float width, float height, int blurRadius, Color color) {
      GL11.glPushMatrix();
      GlStateManager.alphaFunc(516, 0.01F);
      width += (float)(blurRadius * 2);
      height += (float)(blurRadius * 2);
      x -= (float)blurRadius;
      y -= (float)blurRadius;
      float _X = x - 0.25F;
      float _Y = y + 0.25F;
      double identifier = (double)((int)((double)(width * height * 13212.0F) / Math.sin((double)blurRadius)));
      GL11.glEnable(3553);
      GL11.glDisable(2884);
      GL11.glEnable(3008);
      GlStateManager.enableBlend();
      int texId;
      if (shadowCache.containsKey(identifier)) {
         texId = (Integer)shadowCache.get(identifier);
         GlStateManager.bindTexture(texId);
      } else {
         BufferedImage original = new BufferedImage((int)width, (int)height, 2);
         Graphics g = original.getGraphics();
         g.setColor(Color.WHITE);
         g.fillRect(blurRadius, blurRadius, (int)(width - (float)(blurRadius * 2)), (int)(height - (float)(blurRadius * 2)));
         g.dispose();
         GaussianFilter op = new GaussianFilter((float)blurRadius);
         BufferedImage blurred = op.filter(original, (BufferedImage)null);
         texId = TextureUtil.uploadTextureImageAllocate(TextureUtil.glGenTextures(), blurred, true, false);
         shadowCache.put((int)identifier, texId);
      }

      GL11.glColor4f((float)color.getRed() / 255.0F, (float)color.getGreen() / 255.0F, (float)color.getBlue() / 255.0F, (float)color.getAlpha() / 255.0F);
      GL11.glBegin(7);
      GL11.glTexCoord2f(0.0F, 0.0F);
      GL11.glVertex2f(_X, _Y);
      GL11.glTexCoord2f(0.0F, 1.0F);
      GL11.glVertex2f(_X, _Y + height);
      GL11.glTexCoord2f(1.0F, 1.0F);
      GL11.glVertex2f(_X + width, _Y + height);
      GL11.glTexCoord2f(1.0F, 0.0F);
      GL11.glVertex2f(_X + width, _Y);
      GL11.glEnd();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
      GL11.glEnable(2884);
      resetColor();
      GL11.glPopMatrix();
   }

   public static void drawGlowHorizontal(float x, float y, float width, float height, int glowRadius, int color1, int color2) {
      BufferedImage original = null;
      GaussianFilter op = null;
      GL11.glPushMatrix();
      GlStateManager.enableBlend();
      GlStateManager.disableAlpha();
      GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
      GlStateManager.shadeModel(7425);
      GlStateManager.alphaFunc(516, 0.01F);
      float _X = x - (float)glowRadius - 0.25F;
      float _Y = y - (float)glowRadius + 0.25F;
      int identifier = Objects.hash(new Object[]{width += (float)(glowRadius * 2), height += (float)(glowRadius * 2), glowRadius});
      GL11.glEnable(3553);
      GL11.glDisable(2884);
      GL11.glEnable(3008);
      GlStateManager.enableBlend();
      int texId;
      if (shadowCache.containsKey(identifier)) {
         texId = (Integer)shadowCache.get(identifier);
         GlStateManager.bindTexture(texId);
      } else {
         if (width <= 0.0F) {
            width = 1.0F;
         }

         if (height <= 0.0F) {
            height = 1.0F;
         }

         original = new BufferedImage((int)width, (int)height, 3);
         Graphics g = original.getGraphics();
         g.setColor(Color.white);
         g.fillRect(glowRadius, glowRadius, (int)width - glowRadius * 2, (int)height - glowRadius * 2);
         g.dispose();
         op = new GaussianFilter((float)glowRadius);
         BufferedImage blurred = op.filter(original, (BufferedImage)null);
         texId = TextureUtil.uploadTextureImageAllocate(TextureUtil.glGenTextures(), blurred, true, false);
         shadowCache.put(identifier, texId);
      }

      GL11.glBegin(7);
      setColor(color1);
      GL11.glTexCoord2f(0.0F, 0.0F);
      GL11.glVertex2f(_X, _Y);
      GL11.glTexCoord2f(0.0F, 1.0F);
      GL11.glVertex2f(_X, _Y + height);
      setColor(color2);
      GL11.glTexCoord2f(1.0F, 1.0F);
      GL11.glVertex2f(_X + width, _Y + height);
      GL11.glTexCoord2f(1.0F, 0.0F);
      GL11.glVertex2f(_X + width, _Y);
      GL11.glEnd();
      GlStateManager.enableTexture2D();
      GlStateManager.shadeModel(7424);
      GlStateManager.disableBlend();
      GlStateManager.enableAlpha();
      resetColor();
      GL11.glEnable(2884);
      GL11.glPopMatrix();
   }

   private static void setColor(int color) {
   }

   public static void drawGlowGradient(float x, float y, float width, float height, int glowRadius, Color color1, Color color2, Color color3, Color color4) {
      if (Minecraft.getCurrentScreen() == null) {
         BufferedImage original = null;
         GaussianFilter op = null;
         GL11.glPushMatrix();
         GlStateManager.enableBlend();
         GlStateManager.disableAlpha();
         GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
         GlStateManager.shadeModel(7425);
         GlStateManager.alphaFunc(516, 0.01F);
         float _X = x - (float)glowRadius - 0.25F;
         float _Y = y - (float)glowRadius + 0.25F;
         int identifier = String.valueOf((width += (float)(glowRadius * 2)) * (height += (float)(glowRadius * 2)) + width + (float)(1000000000 * glowRadius) + (float)glowRadius).hashCode();
         GL11.glEnable(3553);
         GL11.glDisable(2884);
         GL11.glEnable(3008);
         GlStateManager.enableBlend();
         int texId;
         if (shadowCache.containsKey(identifier)) {
            texId = (Integer)shadowCache.get(identifier);
            GlStateManager.bindTexture(texId);
         } else {
            if (width <= 0.0F) {
               width = 1.0F;
            }

            if (height <= 0.0F) {
               height = 1.0F;
            }

            original = new BufferedImage((int)width, (int)height, 3);
            Graphics g = original.getGraphics();
            g.setColor(Color.white);
            g.fillRect(glowRadius, glowRadius, (int)width - glowRadius * 2, (int)height - glowRadius * 2);
            g.dispose();
            op = new GaussianFilter((float)glowRadius);
            BufferedImage blurred = op.filter(original, (BufferedImage)null);
            texId = TextureUtil.uploadTextureImageAllocate(TextureUtil.glGenTextures(), blurred, true, false);
            shadowCache.put(identifier, texId);
         }

         GL11.glBegin(7);
         setColor(color1);
         GL11.glTexCoord2f(0.0F, 0.0F);
         GL11.glVertex2f(_X, _Y);
         setColor(color2);
         GL11.glTexCoord2f(0.0F, 1.0F);
         GL11.glVertex2f(_X, _Y + height);
         setColor(color4);
         GL11.glTexCoord2f(1.0F, 1.0F);
         GL11.glVertex2f(_X + width, _Y + height);
         setColor(color3);
         GL11.glTexCoord2f(1.0F, 0.0F);
         GL11.glVertex2f(_X + width, _Y);
         GL11.glEnd();
         GlStateManager.enableTexture2D();
         GlStateManager.shadeModel(7424);
         GlStateManager.disableBlend();
         GlStateManager.enableAlpha();
         GlStateManager.resetColor();
         GL11.glEnable(2884);
         GL11.glPopMatrix();
      }

   }

   public static void drawGlowGradient2(float x, float y, float width, float height, int glowRadius, int color1, int color2) {
      if (Minecraft.getCurrentScreen() == null) {
         BufferedImage original = null;
         GaussianFilter op = null;
         GL11.glPushMatrix();
         GlStateManager.enableBlend();
         GlStateManager.disableAlpha();
         GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
         GlStateManager.shadeModel(7425);
         GlStateManager.alphaFunc(516, 0.01F);
         float _X = x - (float)glowRadius - 0.25F;
         float _Y = y - (float)glowRadius + 0.25F;
         int identifier = String.valueOf((width += (float)(glowRadius * 2)) * (height += (float)(glowRadius * 2)) + width + (float)(1000000000 * glowRadius) + (float)glowRadius).hashCode();
         GL11.glEnable(3553);
         GL11.glDisable(2884);
         GL11.glEnable(3008);
         GlStateManager.enableBlend();
         int texId;
         if (shadowCache.containsKey(identifier)) {
            texId = (Integer)shadowCache.get(identifier);
            GlStateManager.bindTexture(texId);
         } else {
            if (width <= 0.0F) {
               width = 1.0F;
            }

            if (height <= 0.0F) {
               height = 1.0F;
            }

            original = new BufferedImage((int)width, (int)height, 3);
            Graphics g = original.getGraphics();
            g.setColor(Color.white);
            g.fillRect(glowRadius, glowRadius, (int)width - glowRadius * 2, (int)height - glowRadius * 2);
            g.dispose();
            op = new GaussianFilter((float)glowRadius);
            BufferedImage blurred = op.filter(original, (BufferedImage)null);
            texId = TextureUtil.uploadTextureImageAllocate(TextureUtil.glGenTextures(), blurred, true, false);
            shadowCache.put(identifier, texId);
         }

         GL11.glBegin(7);
         setColor(color1);
         GL11.glTexCoord2f(0.0F, 0.0F);
         GL11.glVertex2f(_X, _Y);
         setColor(color2);
         GL11.glTexCoord2f(0.0F, 1.0F);
         GL11.glVertex2f(_X, _Y + height);
         GL11.glTexCoord2f(1.0F, 1.0F);
         GL11.glVertex2f(_X + width, _Y + height);
         GL11.glTexCoord2f(1.0F, 0.0F);
         GL11.glVertex2f(_X + width, _Y);
         GL11.glEnd();
         GlStateManager.enableTexture2D();
         GlStateManager.shadeModel(7424);
         GlStateManager.disableBlend();
         GlStateManager.enableAlpha();
         GlStateManager.resetColor();
         GL11.glEnable(2884);
         GL11.glPopMatrix();
      }

   }

   public static void drawClickguiGlow(float x, float y, float width, float height, int glowRadius, Color color1, Color color2, Color color3, Color color4) {
      BufferedImage original = null;
      GaussianFilter op = null;
      GL11.glPushMatrix();
      GlStateManager.enableBlend();
      GlStateManager.disableAlpha();
      GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
      GlStateManager.shadeModel(7425);
      GlStateManager.alphaFunc(516, 0.01F);
      float _X = x - (float)glowRadius - 0.25F;
      float _Y = y - (float)glowRadius + 0.25F;
      int identifier = String.valueOf((width += (float)(glowRadius * 2)) * (height += (float)(glowRadius * 2)) + width + (float)(1000000000 * glowRadius) + (float)glowRadius).hashCode();
      GL11.glEnable(3553);
      GL11.glDisable(2884);
      GL11.glEnable(3008);
      GlStateManager.enableBlend();
      int texId;
      if (shadowCache.containsKey(identifier)) {
         texId = (Integer)shadowCache.get(identifier);
         GlStateManager.bindTexture(texId);
      } else {
         if (width <= 0.0F) {
            width = 1.0F;
         }

         if (height <= 0.0F) {
            height = 1.0F;
         }

         original = new BufferedImage((int)width, (int)height, 3);
         Graphics g = original.getGraphics();
         g.setColor(Color.white);
         g.fillRect(glowRadius, glowRadius, (int)width - glowRadius * 2, (int)height - glowRadius * 2);
         g.dispose();
         op = new GaussianFilter((float)glowRadius);
         BufferedImage blurred = op.filter(original, (BufferedImage)null);
         texId = TextureUtil.uploadTextureImageAllocate(TextureUtil.glGenTextures(), blurred, true, false);
         shadowCache.put(identifier, texId);
      }

      GL11.glBegin(7);
      setColor(color1);
      GL11.glTexCoord2f(0.0F, 0.0F);
      GL11.glVertex2f(_X, _Y);
      setColor(color2);
      GL11.glTexCoord2f(0.0F, 1.0F);
      GL11.glVertex2f(_X, _Y + height);
      setColor(color4);
      GL11.glTexCoord2f(1.0F, 1.0F);
      GL11.glVertex2f(_X + width, _Y + height);
      setColor(color3);
      GL11.glTexCoord2f(1.0F, 0.0F);
      GL11.glVertex2f(_X + width, _Y);
      GL11.glEnd();
      GlStateManager.enableTexture2D();
      GlStateManager.shadeModel(7424);
      GlStateManager.disableBlend();
      GlStateManager.enableAlpha();
      GlStateManager.resetColor();
      GL11.glEnable(2884);
      GL11.glPopMatrix();
   }

   public static void setColor(Color color) {
      float alpha = (float)(color.getRGB() >> 24 & 255) / 255.0F;
      float red = (float)(color.getRGB() >> 16 & 255) / 255.0F;
      float green = (float)(color.getRGB() >> 8 & 255) / 255.0F;
      float blue = (float)(color.getRGB() & 255) / 255.0F;
      GL11.glColor4f(red, green, blue, alpha);
   }

   public void polygon(double x, double y, double sideLength, int amountOfSides) {
      polygon(x, y, sideLength, (double)amountOfSides, true, (Color)null);
   }

   public void polygonCentered(double x, double y, double sideLength, int amountOfSides, boolean filled, Color color) {
      x -= sideLength / 2.0D;
      y -= sideLength / 2.0D;
      polygon(x, y, sideLength, (double)amountOfSides, filled, color);
   }

   public void polygonCentered(double x, double y, double sideLength, int amountOfSides, boolean filled) {
      x -= sideLength / 2.0D;
      y -= sideLength / 2.0D;
      polygon(x, y, sideLength, (double)amountOfSides, filled, (Color)null);
   }

   public void polygonCentered(double x, double y, double sideLength, int amountOfSides, Color color) {
      x -= sideLength / 2.0D;
      y -= sideLength / 2.0D;
      polygon(x, y, sideLength, (double)amountOfSides, true, color);
   }

   public void polygonCentered(double x, double y, double sideLength, int amountOfSides) {
      x -= sideLength / 2.0D;
      y -= sideLength / 2.0D;
      polygon(x, y, sideLength, (double)amountOfSides, true, (Color)null);
   }

   public static void circle(double x, double y, double radius, boolean filled, Color color) {
      polygon(x, y, radius, 360.0D, filled, color);
   }

   public void circle(double x, double y, double radius, boolean filled) {
      this.polygon(x, y, radius, 360, filled);
   }

   public static void circle(double x, double y, double radius, Color color) {
      polygon(x, y, radius, 360, color);
   }

   public void circle(double x, double y, double radius) {
      this.polygon(x, y, radius, 360);
   }

   public void circleCentered(double x, double y, double radius, boolean filled, Color color) {
      x -= radius / 2.0D;
      y -= radius / 2.0D;
      polygon(x, y, radius, 360.0D, filled, color);
   }

   public static void polygon(double x, double y, double sideLength, double amountOfSides, boolean filled, Color color) {
      sideLength /= 2.0D;
      start();
      if (color != null) {
         color(color);
      }

      if (!filled) {
         GL11.glLineWidth(2.0F);
      }

      GL11.glEnable(2848);
      begin(filled ? 6 : 3);

      for(double i = 0.0D; i <= amountOfSides / 4.0D; ++i) {
         double angle = i * 4.0D * 6.283185307179586D / 360.0D;
         vertex(x + sideLength * Math.cos(angle) + sideLength, y + sideLength * Math.sin(angle) + sideLength);
      }

      end();
      GL11.glDisable(2848);
      stop();
   }

   public void circleCentered(double x, double y, double radius, boolean filled) {
      x -= radius / 2.0D;
      y -= radius / 2.0D;
      this.polygon(x, y, radius, 360, filled);
   }

   public void circleCentered(double x, double y, double radius, boolean filled, int sides) {
      x -= radius / 2.0D;
      y -= radius / 2.0D;
      this.polygon(x, y, radius, sides, filled);
   }

   public void circleCentered(double x, double y, double radius, Color color) {
      x -= radius / 2.0D;
      y -= radius / 2.0D;
      polygon(x, y, radius, 360, color);
   }

   public void circleCentered(double x, double y, double radius) {
      x -= radius / 2.0D;
      y -= radius / 2.0D;
      this.polygon(x, y, radius, 360);
   }

   public static void scissor(double x, double y, double width, double height) {
      ScaledResolution sr = new ScaledResolution(net.minecraft.client.Minecraft.getMinecraft());
      double scale = (double)sr.getScaleFactor();
      double finalHeight = height * scale;
      double finalY = ((double)sr.getScaledHeight() - y) * scale;
      double finalX = x * scale;
      double finalWidth = width * scale;
      GL11.glScissor((int)finalX, (int)(finalY - finalHeight), (int)finalWidth, (int)finalHeight);
   }

   public static int rainbow(int delay) {
      double rainbowState = Math.ceil((double)(System.currentTimeMillis() + (long)delay) / 20.0D);
      rainbowState %= 360.0D;
      return Color.getHSBColor((float)(rainbowState / 360.0D), 0.8F, 0.7F).getRGB();
   }

   public static void bindTexture(int texture) {
      GL11.glBindTexture(3553, texture);
   }

   public static void resetColor() {
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
   }

   public static int rainbow(int delay, float brightness, float saturation) {
      double rainbowState = Math.ceil((double)(System.currentTimeMillis() + (long)delay) / 20.0D);
      rainbowState %= 360.0D;
      return Color.getHSBColor((float)(rainbowState / 360.0D), saturation, brightness).getRGB();
   }

   public static int getRainbow1(int speed, int offset) {
      float hue = (float)((System.currentTimeMillis() + (long)offset) % (long)speed);
      hue /= (float)speed;
      return Color.getHSBColor(hue, 1.0F, 1.0F).getRGB();
   }

   public static int getRainbow(int speed, int offset, float brightness, float saturation) {
      float hue = (float)((System.currentTimeMillis() + (long)offset) % (long)speed);
      hue /= (float)speed;
      return Color.getHSBColor(hue, saturation, brightness).getRGB();
   }

   private static int shiftHue(int color, float shift) {
      float[] hsb = Color.RGBtoHSB(color >> 16 & 255, color >> 8 & 255, color & 255, (float[])null);
      float newHue = (hsb[0] + shift) % 1.0F;
      return Color.HSBtoRGB(newHue, hsb[1], hsb[2]);
   }

   private static int calculateChangingColor(long currentTime, int speed) {
      float hue = (float)(currentTime % (long)speed) / (float)speed;
      int color = Color.HSBtoRGB(hue, 1.0F, 1.0F);
      int shiftedColor = shiftHue(color, (float)currentColorIndex * 0.1F);
      return shiftedColor;
   }

   public static Color mixColors(Color color1, Color color2, int count, boolean penis) {
      return interpolateColorsBackAndForth(10, 1 * count, color1, color2, true);
   }

   public static Color interpolateColorC(Color color1, Color color2, float amount) {
      amount = Math.min(1.0F, Math.max(0.0F, amount));
      return new Color(interpolateInt(color1.getRed(), color2.getRed(), (double)amount), interpolateInt(color1.getGreen(), color2.getGreen(), (double)amount), interpolateInt(color1.getBlue(), color2.getBlue(), (double)amount), interpolateInt(color1.getAlpha(), color2.getAlpha(), (double)amount));
   }

   public static Color interpolateColorsBackAndForth(int speed, int index, Color start, Color end, boolean trueColor) {
      int angle = (int)((System.currentTimeMillis() / (long)speed + (long)index) % 360L);
      angle = (angle >= 180 ? 360 - angle : angle) * 2;
      return trueColor ? interpolateColorHue(start, end, (float)angle / 360.0F) : interpolateColorC(start, end, (float)angle / 360.0F);
   }

   public static Color interpolateColorHue(Color color1, Color color2, float amount) {
      amount = Math.min(1.0F, Math.max(0.0F, amount));
      float[] color1HSB = Color.RGBtoHSB(color1.getRed(), color1.getGreen(), color1.getBlue(), (float[])null);
      float[] color2HSB = Color.RGBtoHSB(color2.getRed(), color2.getGreen(), color2.getBlue(), (float[])null);
      Color resultColor = Color.getHSBColor(interpolateFloat(color1HSB[0], color2HSB[0], (double)amount), interpolateFloat(color1HSB[1], color2HSB[1], (double)amount), interpolateFloat(color1HSB[2], color2HSB[2], (double)amount));
      return new Color(resultColor.getRed(), resultColor.getGreen(), resultColor.getBlue(), interpolateInt(color1.getAlpha(), color2.getAlpha(), (double)amount));
   }

   public static Double interpolate(double oldValue, double newValue, double interpolationValue) {
      return oldValue + (newValue - oldValue) * interpolationValue;
   }

   public static Double interpolate(double oldValue, double newValue) {
      return oldValue + (newValue - oldValue);
   }

   public static float interpolateFloat(float oldValue, float newValue, double interpolationValue) {
      return interpolate((double)oldValue, (double)newValue, (double)((float)interpolationValue)).floatValue();
   }

   public static int interpolateInt(int oldValue, int newValue, double interpolationValue) {
      return interpolate((double)oldValue, (double)newValue, (double)((float)interpolationValue)).intValue();
   }

   public static int renderText(String text, int x, int y, int color, boolean b) {
      return Minecraft.GetFontRendererObj().a(text, (float)x, (float)y, color, true, Main.idk);
   }

   public static int renderTestText(String text, int x, int y, int color, boolean b) {
      MinecraftFontRenderer fr = FontUtil.comfortaa18;
      return Minecraft.GetFontRendererObj().a(text, (float)x, (float)y, color, true, Main.idk);
   }

   public static void rect(double d, double d2, double d3, double d4, boolean bl, Color color) {
      start();
      if (color != null) {
         color(color);
      }

      begin(bl ? 6 : 1);
      vertex(d, d2);
      vertex(d + d3, d2);
      vertex(d + d3, d2 + d4);
      vertex(d, d2 + d4);
      if (!bl) {
         vertex(d, d2);
         vertex(d, d2 + d4);
         vertex(d + d3, d2);
         vertex(d + d3, d2 + d4);
      }

      end();
      stop();
   }

   public static void begin(int n) {
      GL11.glBegin(n);
   }

   public static void vertex(double d, double d2) {
      GL11.glVertex2d(d, d2);
   }

   public static void start() {
      enable(3042);
      GL11.glBlendFunc(770, 771);
      disable(3553);
      disable(2884);
   }

   public static void enable(int n) {
      GL11.glEnable(n);
   }

   public static void disable(int n) {
      GL11.glDisable(n);
   }

   public static void end() {
      GL11.glEnd();
   }

   public static void stop() {
      enable(2884);
      enable(3553);
      disable(3042);
      color(Color.white);
   }

   public static void color(Color color) {
      if (color == null) {
         color = Color.white;
      }

      color((double)((float)color.getRed() / 255.0F), (double)((float)color.getGreen() / 255.0F), (double)((float)color.getBlue() / 255.0F), (double)((float)color.getAlpha() / 255.0F));
   }

   public static void color(double d, double d2, double d3) {
      color(d, d2, d3, 1.0D);
   }

   public static void color(double d, double d2, double d3, double d4) {
      GL11.glColor4d(d, d2, d3, d4);
   }

   public static int getTextWidth(String text) {
      int width = 0;
      text = text.replace("§0", "").replace("§1", "").replace("§2", "").replace("§3", "").replace("§4", "").replace("§5", "").replace("§6", "").replace("§7", "").replace("§8", "").replace("§9", "").replace("§a", "").replace("§b", "").replace("§c", "").replace("§d", "").replace("§e", "").replace("§f", "").replace("§k", "").replace("§l", "").replace("§m", "").replace("§n", "").replace("§o", "").replace("§r", "");
      char[] var2 = text.toCharArray();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         char c = var2[var4];
         width += Minecraft.GetFontRendererObj().b(c, Main.idk);
      }

      return width;
   }

   public static int getTextHeight() {
      return 6;
   }

   public static void drawRoundedRect2(double x, double y, double endX, double endY, double radius, int color) {
      float f = (float)(color >> 24 & 255) / 255.0F;
      float f2 = (float)(color >> 16 & 255) / 255.0F;
      float f3 = (float)(color >> 8 & 255) / 255.0F;
      float f4 = (float)(color & 255) / 255.0F;
      GL11.glPushAttrib(0);
      GL11.glScaled(0.5D, 0.5D, 0.5D);
      x *= 2.0D;
      y *= 2.0D;
      endX *= 2.0D;
      endY *= 2.0D;
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glColor4f(f2, f3, f4, f);
      GL11.glEnable(2848);
      GL11.glBegin(9);

      int n2;
      for(n2 = 0; n2 <= 90; n2 += 3) {
         GL11.glVertex2d(x + radius + Math.sin((double)n2 * 3.141592653589793D / 180.0D) * radius * -1.0D, y + radius + Math.cos((double)n2 * 3.141592653589793D / 180.0D) * radius * -1.0D);
      }

      for(n2 = 90; n2 <= 180; n2 += 3) {
         GL11.glVertex2d(x + 0.0D + Math.sin((double)n2 * 3.141592653589793D / 180.0D) * -0.0D, endY - 0.0D + Math.cos((double)n2 * 3.141592653589793D / 180.0D) * -0.0D);
      }

      for(n2 = 0; n2 <= 90; n2 += 3) {
         GL11.glVertex2d(endX - 0.0D + Math.sin((double)n2 * 3.141592653589793D / 180.0D) * -0.0D, endY - 0.0D + Math.cos((double)n2 * 3.141592653589793D / 180.0D) * -0.0D);
      }

      for(n2 = 90; n2 <= 180; n2 += 3) {
         GL11.glVertex2d(endX - radius + Math.sin((double)n2 * 3.141592653589793D / 180.0D) * radius, y + radius + Math.cos((double)n2 * 3.141592653589793D / 180.0D) * radius);
      }

      GL11.glEnd();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glDisable(3042);
      GL11.glEnable(3553);
      GL11.glScaled(2.0D, 2.0D, 2.0D);
      GL11.glPopAttrib();
   }

   public static void drawRoundedRect(double x, double y, double endX, double endY, double radius, int color) {
      float f = (float)(color >> 24 & 255) / 255.0F;
      float f2 = (float)(color >> 16 & 255) / 255.0F;
      float f3 = (float)(color >> 8 & 255) / 255.0F;
      float f4 = (float)(color & 255) / 255.0F;
      GL11.glPushAttrib(0);
      GL11.glScaled(0.5D, 0.5D, 0.5D);
      x *= 2.0D;
      y *= 2.0D;
      endX *= 2.0D;
      endY *= 2.0D;
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glColor4f(f2, f3, f4, f);
      GL11.glEnable(2848);
      GL11.glBegin(9);

      int n2;
      for(n2 = 0; n2 <= 90; n2 += 3) {
         GL11.glVertex2d(x + radius + Math.sin((double)n2 * 3.141592653589793D / 180.0D) * radius * -1.0D, y + radius + Math.cos((double)n2 * 3.141592653589793D / 180.0D) * radius * -1.0D);
      }

      for(n2 = 90; n2 <= 180; n2 += 3) {
         GL11.glVertex2d(x + radius + Math.sin((double)n2 * 3.141592653589793D / 180.0D) * radius * -1.0D, endY - radius + Math.cos((double)n2 * 3.141592653589793D / 180.0D) * radius * -1.0D);
      }

      for(n2 = 0; n2 <= 90; n2 += 3) {
         GL11.glVertex2d(endX - radius + Math.sin((double)n2 * 3.141592653589793D / 180.0D) * radius, endY - radius + Math.cos((double)n2 * 3.141592653589793D / 180.0D) * radius);
      }

      for(n2 = 90; n2 <= 180; n2 += 3) {
         GL11.glVertex2d(endX - radius + Math.sin((double)n2 * 3.141592653589793D / 180.0D) * radius, y + radius + Math.cos((double)n2 * 3.141592653589793D / 180.0D) * radius);
      }

      GL11.glEnd();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glDisable(3042);
      GL11.glEnable(3553);
      GL11.glScaled(2.0D, 2.0D, 2.0D);
      GL11.glPopAttrib();
   }

   public static void drawRect(double x, double y, double endX, double endY, int color) {
      drawRoundedRect(x, y, endX, endY, 1.0D, color);
   }

   public static ah calculateAdjustedEntityBoundingBox(m9 entity, double offsetX, double offsetY, double offsetZ) {
      ah entityBoundingBox = Minecraft.getEntityBoundingBox(entity);
      offsetX -= ThePlayer.GetPosX(entity);
      offsetY -= ThePlayer.GetPosY(entity);
      offsetZ -= ThePlayer.GetprevPosZ(entity);
      return new ah(entityBoundingBox.c + offsetX, entityBoundingBox.a + offsetY, entityBoundingBox.f + offsetZ, entityBoundingBox.e + offsetX, entityBoundingBox.g + offsetY, entityBoundingBox.d + offsetZ);
   }

   public static ah calculateAdjustedEntityBoundingBox(m9 entity, float partialTicks) {
      return calculateAdjustedEntityBoundingBox(entity, ThePlayer.GetlastTickPosX(entity) + (ThePlayer.GetPosX(entity) - ThePlayer.GetlastTickPosX(entity)) * (double)partialTicks - Minecraft.getRenderManager().j, ThePlayer.GetlastTickPosY(entity) + (ThePlayer.GetPosY(entity) - ThePlayer.GetlastTickPosY(entity)) * (double)partialTicks - Minecraft.getRenderManager().t, ThePlayer.GetlastTickPosZ(entity) + (ThePlayer.GetprevPosZ(entity) - ThePlayer.GetlastTickPosZ(entity)) * (double)partialTicks - Minecraft.getRenderManager().c);
   }

   public static boolean basicCollisionCheck(double mouseX, double mouseY, double x, double y, double endX, double endY) {
      return mouseX >= x & mouseX <= endX & mouseY >= y & mouseY <= endY;
   }

   public static int applyOpacity(int color, float opacity) {
      Color old = new Color(color);
      return applyOpacity(old, opacity).getRGB();
   }

   public static Color applyOpacity(Color color, float opacity) {
      opacity = Math.min(1.0F, Math.max(0.0F, opacity));
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)((float)color.getAlpha() * opacity));
   }

   public static Color brighter(Color color, float FACTOR) {
      int r = color.getRed();
      int g = color.getGreen();
      int b = color.getBlue();
      int alpha = color.getAlpha();
      int i = (int)(1.0D / (1.0D - (double)FACTOR));
      if (r == 0 && g == 0 && b == 0) {
         return new Color(i, i, i, alpha);
      } else {
         if (r > 0 && r < i) {
            r = i;
         }

         if (g > 0 && g < i) {
            g = i;
         }

         if (b > 0 && b < i) {
            b = i;
         }

         return new Color(Math.min((int)((float)r / FACTOR), 255), Math.min((int)((float)g / FACTOR), 255), Math.min((int)((float)b / FACTOR), 255), alpha);
      }
   }

   public static void drawCircle(m9 entity, double rad, boolean shade) {
      GL11.glPushMatrix();
      GL11.glDisable(3553);
      GL11.glEnable(2848);
      GL11.glEnable(2832);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glHint(3154, 4354);
      GL11.glHint(3155, 4354);
      GL11.glHint(3153, 4354);
      GL11.glDepthMask(false);
      bO.a(516, 0.0F);
      if (shade) {
         GL11.glShadeModel(7425);
      }

      bO.K();
      GL11.glBegin(5);
      double x = entity.a6 + (entity.bE - entity.a6) * 0.8999999761581421D - Minecraft.getRenderManager().h;
      double y = entity.h + (entity.aY - entity.h) * 0.8999999761581421D - Minecraft.getRenderManager().n + 1.0D;
      double z = entity.G + (entity.bH - entity.G) * 0.8999999761581421D - Minecraft.getRenderManager().g;

      for(float i = 0.0F; (double)i < 6.283185307179586D; i = (float)((double)i + 0.09817477042468103D)) {
         double vecX = x + rad * Math.cos((double)i);
         double vecZ = z + rad * Math.sin((double)i);
         Color c = new Color(255, 255, 255, 255);
         if (shade) {
            GL11.glColor4f((float)c.getRed() / 255.0F, (float)c.getGreen() / 255.0F, (float)c.getBlue() / 255.0F, 0.0F);
            GL11.glVertex3d(vecX, y - Math.cos((double)System.currentTimeMillis() / 200.0D) / 2.0D, vecZ);
            GL11.glColor4f((float)c.getRed() / 255.0F, (float)c.getGreen() / 255.0F, (float)c.getBlue() / 255.0F, 0.85F);
         }

         GL11.glVertex3d(vecX, y, vecZ);
      }

      GL11.glEnd();
      if (shade) {
         GL11.glShadeModel(7424);
      }

      GL11.glDepthMask(true);
      GL11.glEnable(2929);
      bO.a(516, 0.1F);
      bO.q();
      GL11.glDisable(2848);
      GL11.glDisable(2848);
      GL11.glEnable(2832);
      GL11.glEnable(3553);
      GL11.glPopMatrix();
      GL11.glColor3f(255.0F, 255.0F, 255.0F);
   }

   public static void color(int color, float alpha) {
      float r = (float)(color >> 16 & 255) / 255.0F;
      float g = (float)(color >> 8 & 255) / 255.0F;
      float b = (float)(color & 255) / 255.0F;
      GlStateManager.color(r, g, b, alpha);
   }

   public static void color(int color) {
      color(color, (float)(color >> 24 & 255) / 255.0F);
   }
}
