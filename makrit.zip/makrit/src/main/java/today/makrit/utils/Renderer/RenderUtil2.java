package today.makrit.utils.Renderer;

import com.jhlabs.image.GaussianFilter;
import cr.launcher.Config;
import org.lwjgl.opengl.GL11;
import today.makrit.Main;
import today.makrit.utils.Helper.MathHelper;
import today.makrit.utils.mapper.GlStateManager;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.HashMap;

import static org.lwjgl.opengl.GL11.*;
public class RenderUtil2 {

    private static int currentColorIndex = 0;
    private static final HashMap<Integer, Integer> shadowCache = new HashMap();
    public static Color getRainbow(int offset, int speed) {
        float hue = (float)((System.currentTimeMillis() + (long)offset) % (long)speed);
        hue /= (float)speed;
        return Color.getHSBColor(hue, 0.7F, 1.0F);
    }
    public static void drawBorderedRect(final int x1, final int y1, final int x2, final int y2, final int color) {
        RenderUtil.drawRect(x1, y1, x2 + x1, 1 + y1, color);
        RenderUtil.drawRect(x1, y1 + 1, 1 + x1, y2 + y1, color);
        RenderUtil.drawRect(x1 + 1, y1 + y2 - 1, x2 + x1, y2 + y1, color);
        RenderUtil.drawRect(x1 + x2 - 1, y1 + 1, x1 + x2, y2 + y1 - 1, color);
    }
    public static void drawBorderedRect(double left, double top, double right, double bottom, double borderWidth, int insideColor, int borderColor, boolean borderIncludedInBounds) {
        drawRect(left - (!borderIncludedInBounds ? borderWidth : 0.0), top - (!borderIncludedInBounds ? borderWidth : 0.0), right + (!borderIncludedInBounds ? borderWidth : 0.0), bottom + (!borderIncludedInBounds ? borderWidth : 0.0), borderColor);
        drawRect(left + (borderIncludedInBounds ? borderWidth : 0.0), top + (borderIncludedInBounds ? borderWidth : 0.0), right - (borderIncludedInBounds ? borderWidth : 0.0), bottom - (borderIncludedInBounds ? borderWidth : 0.0), insideColor);
    }
    public static void drawRectBetter(double x, double y, double width, double height, int color) {
        drawRect(x, y, x + width, y + height, color);
    }
    public static double ticks = 0;
    public static long lastFrame = 0;
    public static void drawCircle(com.craftrise.m9 entity, float partialTicks, double rad, int color, float alpha) {
        /*Got this from the people I made the Gui for*/
        ticks += .004 * (System.currentTimeMillis() - lastFrame);

        lastFrame = System.currentTimeMillis();

        glPushMatrix();
        glDisable(GL_TEXTURE_2D);
        glEnable(GL_BLEND);
        GlStateManager.color(1, 1, 1, 1);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glDisable(GL_DEPTH_TEST);
        glDepthMask(false);
        glShadeModel(GL_SMOOTH);
        // GlStateManager.disableCull();

        final double x = interpolate(entity.a6, entity.bE, Config.renderPartialTicks) - Minecraft.getRenderManager().j;
        final double y = interpolate(entity.h, entity.aY, Config.renderPartialTicks) - Minecraft.getRenderManager().t + Math.sin(ticks) + 1;
        final double z = interpolate(entity.G, entity.bH, Config.renderPartialTicks) - Minecraft.getRenderManager().c;

        glBegin(GL_TRIANGLE_STRIP);

        for (float i = 0; i < (Math.PI * 2); i += (Math.PI * 2) / 64.F) {

            final double vecX = x + rad * Math.cos(i);
            final double vecZ = z + rad * Math.sin(i);

            color(color, 0);

            glVertex3d(vecX, y - Math.sin(ticks + 1) / 2.7f, vecZ);

            color(color, .52f * alpha);


            glVertex3d(vecX, y, vecZ);
        }

        glEnd();


        glEnable(GL_LINE_SMOOTH);
        glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
        glLineWidth(1.5f);
        glBegin(GL_LINE_STRIP);
        GlStateManager.color(1, 1, 1, 1);
        color(color, .5f * alpha);
        for (int i = 0; i <= 180; i++) {
            glVertex3d(x - Math.sin(i * MathHelper.PI2 / 90) * rad, y, z + Math.cos(i * MathHelper.PI2 / 90) * rad);
        }
        glEnd();

        glShadeModel(GL_FLAT);
        glDepthMask(true);
        glEnable(GL_DEPTH_TEST);
        //    GlStateManager.enableCull();
        glDisable(GL_LINE_SMOOTH);
        glEnable(GL_TEXTURE_2D);
        glPopMatrix();
        glColor4f(1f, 1f, 1f, 1f);
    }
    public static void setAlphaLimit(float limit) {
        GlStateManager.enableAlpha();
        GlStateManager.alphaFunc(GL_GREATER, (float) (limit * .01));
    }
    public static void scissor(double x, double y, double width, double height, Runnable data) {
        glEnable(GL_SCISSOR_TEST);
        scissor(x, y, width, height);
        data.run();
        glDisable(GL_SCISSOR_TEST);
    }
    public void polygon(final double x, final double y, final double sideLength, final int amountOfSides, final boolean filled) {
        polygon(x, y, sideLength, amountOfSides, filled, null);
    }

    public static void scissorStart(double x, double y, double width, double height) {
      //  glEnable(GL_SCISSOR_TEST);
     //   ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
     //   final double scale = sr.getScaleFactor();
     //   double finalHeight = height * scale;
     //   double finalY = (sr.getScaledHeight() - y) * scale;
     //   double finalX = x * scale;
     //   double finalWidth = width * scale;
     //   glScissor((int) finalX, (int) (finalY - finalHeight), (int) finalWidth, (int) finalHeight);
    }

    public static void scissorEnd() {
        glDisable(GL_SCISSOR_TEST);
    }

    public static void polygon(final double x, final double y, final double sideLength, final int amountOfSides, final Color color) {
        polygon(x, y, sideLength, amountOfSides, true, color);
    }
    public static void drawBlurredShadow(float x, float y, float width, float height, int blurRadius, Color color) {
        GL11.glPushMatrix();
        GlStateManager.alphaFunc(516, 0.01F);
        width += (float)(blurRadius * 2);
        height += (float)(blurRadius * 2);
        x -= (float)blurRadius;
        y -= (float)blurRadius;
        float _X = x - 0.25F;
        float _Y = y + 0.25F;
        double identifier = (double)((int)((double)(width * height * 13212.0F) / Math.sin((double)blurRadius)));
        GL11.glEnable(3553);
        GL11.glDisable(2884);
        GL11.glEnable(3008);
        GlStateManager.enableBlend();
        int texId;
        if (shadowCache.containsKey(identifier)) {
            texId = (Integer)shadowCache.get(identifier);
            GlStateManager.bindTexture(texId);
        } else {
            BufferedImage original = new BufferedImage((int)width, (int)height, 2);
            Graphics g = original.getGraphics();
            g.setColor(Color.WHITE);
            g.fillRect(blurRadius, blurRadius, (int)(width - (float)(blurRadius * 2)), (int)(height - (float)(blurRadius * 2)));
            g.dispose();
            GaussianFilter op = new GaussianFilter((float)blurRadius);
            BufferedImage blurred = op.filter(original, (BufferedImage)null);
            texId = TextureUtil.uploadTextureImageAllocate(TextureUtil.glGenTextures(), blurred, true, false);
            shadowCache.put((int) identifier, texId);
        }

        GL11.glColor4f((float)color.getRed() / 255.0F, (float)color.getGreen() / 255.0F, (float)color.getBlue() / 255.0F, (float)color.getAlpha() / 255.0F);
        GL11.glBegin(7);
        GL11.glTexCoord2f(0.0F, 0.0F);
        GL11.glVertex2f(_X, _Y);
        GL11.glTexCoord2f(0.0F, 1.0F);
        GL11.glVertex2f(_X, _Y + height);
        GL11.glTexCoord2f(1.0F, 1.0F);
        GL11.glVertex2f(_X + width, _Y + height);
        GL11.glTexCoord2f(1.0F, 0.0F);
        GL11.glVertex2f(_X + width, _Y);
        GL11.glEnd();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GL11.glEnable(2884);
        RenderUtil.resetColor();
        GL11.glPopMatrix();
    }

    public static void drawGlowGradient(float x, float y, float width, float height, int glowRadius, Color color1, Color color2, Color color3, Color color4) {
        if (Minecraft.getCurrentScreen() == null){
            BufferedImage original = null;
            GaussianFilter op = null;
            GL11.glPushMatrix();
            GlStateManager.enableBlend();
            GlStateManager.disableAlpha();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            GlStateManager.shadeModel(7425);
            GlStateManager.alphaFunc(516, 0.01f);
            float _X = (x -= (float) glowRadius) - 0.25f;
            float _Y = (y -= (float) glowRadius) + 0.25f;
            int identifier = String.valueOf((width += (float) (glowRadius * 2)) * (height += (float) (glowRadius * 2)) + width + (float) (1000000000 * glowRadius) + (float) glowRadius).hashCode();
            GL11.glEnable(3553);
            GL11.glDisable(2884);
            GL11.glEnable(3008);
            GlStateManager.enableBlend();
            int texId = -1;
            if (shadowCache.containsKey(identifier)) {
                texId = shadowCache.get(identifier);
                GlStateManager.bindTexture(texId);
            } else {
                if (width <= 0.0f) {
                    width = 1.0f;
                }
                if (height <= 0.0f) {
                    height = 1.0f;
                }
                original = new BufferedImage((int) width, (int) height, 3);
                Graphics g = original.getGraphics();
                g.setColor(Color.white);
                g.fillRect(glowRadius, glowRadius, (int) width - glowRadius * 2, (int) height - glowRadius * 2);
                g.dispose();
                op = new GaussianFilter(glowRadius);
                BufferedImage blurred = op.filter(original, null);
                texId = TextureUtil.uploadTextureImageAllocate(TextureUtil.glGenTextures(), blurred, true, false);
                shadowCache.put(identifier, texId);
            }
            GL11.glBegin(7);
            setColor(color1);
            GL11.glTexCoord2f(0.0f, 0.0f);
            GL11.glVertex2f(_X, _Y);
            setColor(color2);
            GL11.glTexCoord2f(0.0f, 1.0f);
            GL11.glVertex2f(_X, _Y + height);
            setColor(color4);
            GL11.glTexCoord2f(1.0f, 1.0f);
            GL11.glVertex2f(_X + width, _Y + height);
            setColor(color3);
            GL11.glTexCoord2f(1.0f, 0.0f);
            GL11.glVertex2f(_X + width, _Y);
            GL11.glEnd();
            GlStateManager.enableTexture2D();
            GlStateManager.shadeModel(7424);
            GlStateManager.disableBlend();
            GlStateManager.enableAlpha();
            GlStateManager.resetColor();
            GL11.glEnable(2884);
            GL11.glPopMatrix();
        }
    }

    public static void setColor(Color color) {
        float alpha = (color.getRGB() >> 24 & 0xFF) / 255.0F;
        float red = (color.getRGB() >> 16 & 0xFF) / 255.0F;
        float green = (color.getRGB() >> 8 & 0xFF) / 255.0F;
        float blue = (color.getRGB() & 0xFF) / 255.0F;
        GL11.glColor4f(red, green, blue, alpha);
    }

    public void polygon(final double x, final double y, final double sideLength, final int amountOfSides) {
        polygon(x, y, sideLength, amountOfSides, true, null);
    }

    public void polygonCentered(double x, double y, final double sideLength, final int amountOfSides, final boolean filled, final Color color) {
        x -= sideLength / 2;
        y -= sideLength / 2;
        polygon(x, y, sideLength, amountOfSides, filled, color);
    }

    public void polygonCentered(double x, double y, final double sideLength, final int amountOfSides, final boolean filled) {
        x -= sideLength / 2;
        y -= sideLength / 2;
        polygon(x, y, sideLength, amountOfSides, filled, null);
    }

    public void polygonCentered(double x, double y, final double sideLength, final int amountOfSides, final Color color) {
        x -= sideLength / 2;
        y -= sideLength / 2;
        polygon(x, y, sideLength, amountOfSides, true, color);
    }

    public void polygonCentered(double x, double y, final double sideLength, final int amountOfSides) {
        x -= sideLength / 2;
        y -= sideLength / 2;
        polygon(x, y, sideLength, amountOfSides, true, null);
    }

    public static void circle(final double x, final double y, final double radius, final boolean filled, final Color color) {
        polygon(x, y, radius, 360, filled, color);
    }

    public void circle(final double x, final double y, final double radius, final boolean filled) {
        polygon(x, y, radius, 360, filled);
    }

    public static void circle(final double x, final double y, final double radius, final Color color) {
        polygon(x, y, radius, 360, color);
    }

    public void circle(final double x, final double y, final double radius) {
        polygon(x, y, radius, 360);
    }

    public void circleCentered(double x, double y, final double radius, final boolean filled, final Color color) {
        x -= radius / 2;
        y -= radius / 2;
        polygon(x, y, radius, 360, filled, color);
    }
    public static void polygon(final double x, final double y, double sideLength, final double amountOfSides, final boolean filled, final Color color) {
        sideLength /= 2;
        start();
        if (color != null)
            color(color);
        if (!filled) GL11.glLineWidth(2);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        begin(filled ? GL11.GL_TRIANGLE_FAN : GL11.GL_LINE_STRIP);
        {
            for (double i = 0; i <= amountOfSides / 4; i++) {
                final double angle = i * 4 * (Math.PI * 2) / 360;
                vertex(x + (sideLength * Math.cos(angle)) + sideLength, y + (sideLength * Math.sin(angle)) + sideLength);
            }
        }
        end();
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        stop();
    }
    public void circleCentered(double x, double y, final double radius, final boolean filled) {
        x -= radius / 2;
        y -= radius / 2;
        polygon(x, y, radius, 360, filled);
    }

    public void circleCentered(double x, double y, final double radius, final boolean filled, final int sides) {
        x -= radius / 2;
        y -= radius / 2;
        polygon(x, y, radius, sides, filled);
    }

    public void circleCentered(double x, double y, final double radius, final Color color) {
        x -= radius / 2;
        y -= radius / 2;
        polygon(x, y, radius, 360, color);
    }

    public void circleCentered(double x, double y, final double radius) {
        x -= radius / 2;
        y -= radius / 2;
        polygon(x, y, radius, 360);
    }


    public static void scissor(double x, double y, double width, double height) {
       // ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
   //     final double scale = sr.getScaleFactor();
     //   double finalHeight = height * scale;
     //   double finalY = (sr.getScaledHeight() - y) * scale;
     //   double finalX = x * scale;
     //   double finalWidth = width * scale;
     //   glScissor((int) finalX, (int) (finalY - finalHeight), (int) finalWidth, (int) finalHeight);
    }

    public static int rainbow(int delay) {
        double rainbowState = Math.ceil((double)(System.currentTimeMillis() + (long)delay) / 20.0D);
        rainbowState %= 360.0D;
        return Color.getHSBColor((float)(rainbowState / 360.0D), 0.8F, 0.7F).getRGB();
    }

    public static void bindTexture(int texture)
    {
        glBindTexture(GL_TEXTURE_2D, texture);
    }

    public static void resetColor()
    {
        GlStateManager.color(1, 1, 1, 1);
    }

    public static int rainbow(int delay, float brightness, float saturation) {
        double rainbowState = Math.ceil((double)(System.currentTimeMillis() + (long)delay) / 20.0D);
        rainbowState %= 360.0D;
        return Color.getHSBColor((float)(rainbowState / 360.0D), saturation, brightness).getRGB();
    }

    public static int getRainbow1(int speed, int offset) {
        float hue = (float)((System.currentTimeMillis() + (long)offset) % (long)speed);
        hue /= (float)speed;
        return Color.getHSBColor(hue, 1.0F, 1.0F).getRGB();
    }

    public static int getRainbow(int speed, int offset, float brightness, float saturation) {
        float hue = (float)((System.currentTimeMillis() + (long)offset) % (long)speed);
        hue /= (float)speed;
        return Color.getHSBColor(hue, saturation, brightness).getRGB();
    }
    private static int shiftHue(int color, float shift) {
        float[] hsb = Color.RGBtoHSB(color >> 16 & 0xFF, color >> 8 & 0xFF, color & 0xFF, null);
        float newHue = (hsb[0] + shift) % 1.0f;
        return Color.HSBtoRGB(newHue, hsb[1], hsb[2]);
    }
    private static int calculateChangingColor(long currentTime, int speed) {
        float hue = (float)(currentTime % (long)speed) / (float)speed;
        int color = Color.HSBtoRGB(hue, 1.0f, 1.0f);
        int shiftedColor = shiftHue(color, (float)currentColorIndex * 0.1f);
        return shiftedColor;
    }

    public static Color mixColors(Color color1, Color color2, int count, boolean penis) {
        return interpolateColorsBackAndForth(10, 1 * count, color1, color2, true);
    }

    public static Color interpolateColorC(Color color1, Color color2, float amount) {
        amount = Math.min(1.0F, Math.max(0.0F, amount));
        return new Color(interpolateInt(color1.getRed(), color2.getRed(), (double)amount), interpolateInt(color1.getGreen(), color2.getGreen(), (double)amount), interpolateInt(color1.getBlue(), color2.getBlue(), (double)amount), interpolateInt(color1.getAlpha(), color2.getAlpha(), (double)amount));
    }

    public static Color interpolateColorsBackAndForth(int speed, int index, Color start, Color end, boolean trueColor) {
        int angle = (int)((System.currentTimeMillis() / (long)speed + (long)index) % 360L);
        angle = (angle >= 180 ? 360 - angle : angle) * 2;
        return trueColor ? interpolateColorHue(start, end, (float)angle / 360.0F) : interpolateColorC(start, end, (float)angle / 360.0F);
    }

    public static Color interpolateColorHue(Color color1, Color color2, float amount) {
        amount = Math.min(1.0F, Math.max(0.0F, amount));
        float[] color1HSB = Color.RGBtoHSB(color1.getRed(), color1.getGreen(), color1.getBlue(), (float[])null);
        float[] color2HSB = Color.RGBtoHSB(color2.getRed(), color2.getGreen(), color2.getBlue(), (float[])null);
        Color resultColor = Color.getHSBColor(interpolateFloat(color1HSB[0], color2HSB[0], (double)amount), interpolateFloat(color1HSB[1], color2HSB[1], (double)amount), interpolateFloat(color1HSB[2], color2HSB[2], (double)amount));
        return new Color(resultColor.getRed(), resultColor.getGreen(), resultColor.getBlue(), interpolateInt(color1.getAlpha(), color2.getAlpha(), (double)amount));
    }

    public static Double interpolate(double oldValue, double newValue, double interpolationValue) {
        return oldValue + (newValue - oldValue) * interpolationValue;
    }
    public static Double interpolate(double oldValue, double newValue) {
        return oldValue + (newValue - oldValue);
    }
    public static float interpolateFloat(float oldValue, float newValue, double interpolationValue) {
        return interpolate((double)oldValue, (double)newValue, (double)((float)interpolationValue)).floatValue();
    }

    public static int interpolateInt(int oldValue, int newValue, double interpolationValue) {
        return interpolate((double)oldValue, (double)newValue, (double)((float)interpolationValue)).intValue();
    }

    public static int renderText(String text, int x, int y, int color, boolean b) {
        return Minecraft.GetFontRendererObj().a(text, x, y, color, true, Main.idk);
    }

    public static int renderTestText(String text, int x, int y, int color, boolean b) {
        MinecraftFontRenderer fr = FontUtil.tff;
        return Minecraft.GetFontRendererObj().a(text, x, y, color, true, Main.idk);
    }
    public static void rect(double d, double d2, double d3, double d4, boolean bl, Color color) {
        RenderUtil.start();
        if (color != null) {
            RenderUtil.color(color);
        }
        RenderUtil.begin(bl ? 6 : 1);
        RenderUtil.vertex(d, d2);
        RenderUtil.vertex(d + d3, d2);
        RenderUtil.vertex(d + d3, d2 + d4);
        RenderUtil.vertex(d, d2 + d4);
        if (!bl) {
            RenderUtil.vertex(d, d2);
            RenderUtil.vertex(d, d2 + d4);
            RenderUtil.vertex(d + d3, d2);
            RenderUtil.vertex(d + d3, d2 + d4);
        }
        RenderUtil.end();
        RenderUtil.stop();
    }

    public static void begin(int n) {
        GL11.glBegin(n);
    }

    public static void vertex(double d, double d2) {
        GL11.glVertex2d(d, d2);
    }

    public static void start() {
        RenderUtil.enable(3042);
        GL11.glBlendFunc(770, 771);
        RenderUtil.disable(3553);
        RenderUtil.disable(2884);
    }

    public static void enable(int n) {
        GL11.glEnable(n);
    }

    public static void disable(int n) {
        GL11.glDisable(n);
    }

    public static void end() {
        GL11.glEnd();
    }

    public static void stop() {
        RenderUtil.enable(2884);
        RenderUtil.enable(3553);
        RenderUtil.disable(3042);
        RenderUtil.color(Color.white);
    }

    public static void color(Color color) {
        if (color == null) {
            color = Color.white;
        }
        RenderUtil.color((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)color.getAlpha() / 255.0f);
    }

    public static void color(double d, double d2, double d3) {
        RenderUtil.color(d, d2, d3, 1.0);
    }

    public static void color(double d, double d2, double d3, double d4) {
        GL11.glColor4d(d, d2, d3, d4);
    }

    public static int getTextWidth(String text) {
        int width = 0;
        text = text.replace("§0", "").replace("§1", "").replace("§2", "").replace("§3", "").replace("§4", "").replace("§5", "").replace("§6", "").replace("§7", "").replace("§8", "").replace("§9", "").replace("§a", "").replace("§b", "").replace("§c", "").replace("§d", "").replace("§e", "").replace("§f", "").replace("§k", "").replace("§l", "").replace("§m", "").replace("§n", "").replace("§o", "").replace("§r", "");
        for(char c : text.toCharArray()) {
            width += Minecraft.GetFontRendererObj().b(c, Main.idk);
        }

        return width;
    }

    public static int getTextHeight() {
        return 6;
    }

    public static void drawRoundedRect2(double x, double y, double endX, double endY, double radius, int color) {
        int n2;
        float f = (float) (color >> 24 & 0xFF) / (float) 255;
        float f2 = (float) (color >> 16 & 0xFF) / (float) 255;
        float f3 = (float) (color >> 8 & 0xFF) / (float) 255;
        float f4 = (float) (color & 0xFF) / (float) 255;
        glPushAttrib(0);
        glScaled(0.5, 0.5, 0.5);
        x *= 2;
        y *= 2;
        endX *= 2;
        endY *= 2;
        glEnable(3042);
        glDisable(3553);
        glColor4f(f2, f3, f4, f);
        glEnable(2848);
        glBegin(9);
        for (n2 = 0; n2 <= 90; n2 += 3) {
            glVertex2d(x + radius + Math.sin((double) n2 * (6.5973445528769465 * 0.4761904776096344) / (double) 180) * (radius * (double) -1), y + radius + Math.cos((double) n2 * (42.5 * 0.07391982714328925) / (double) 180) * (radius * (double) -1));
        }
        for (n2 = 90; n2 <= 180; n2 += 3) {
            glVertex2d(x + 0f + Math.sin((double) n2 * (0.5711986642890533 * 5.5) / (double) 180) * (0f * (double) -1), endY - 0f + Math.cos((double) n2 * (0.21052631735801697 * 14.922564993369743) / (double) 180) * (0f * (double) -1));
        }
        for (n2 = 0; n2 <= 90; n2 += 3) {
            glVertex2d(endX - 0f + Math.sin((double) n2 * (4.466951941998311 * 0.7032967209815979) / (double) 180) * (0f * (double) -1), endY - 0f + Math.cos((double) n2 * (28.33333396911621 * 0.11087973822685955) / (double) 180) * (0f * (double) -1));
        }
        for (n2 = 90; n2 <= 180; n2 += 3) {
            glVertex2d(endX - radius + Math.sin((double) n2 * ((double) 0.6f * 5.2359875479235365) / (double) 180) * radius, y + radius + Math.cos((double) n2 * (2.8529412746429443 * 1.1011767685204017) / (double) 180) * radius);
        }
        glEnd();
        glEnable(3553);
        glDisable(3042);
        glDisable(2848);
        glDisable(3042);
        glEnable(3553);
        glScaled(2, 2, 2);
        glPopAttrib();
    }

    public static void drawRoundedRect(double x, double y, double endX, double endY, double radius, int color) {
        int n2;
        float f = (float) (color >> 24 & 0xFF) / (float) 255;
        float f2 = (float) (color >> 16 & 0xFF) / (float) 255;
        float f3 = (float) (color >> 8 & 0xFF) / (float) 255;
        float f4 = (float) (color & 0xFF) / (float) 255;
        glPushAttrib(0);
        glScaled(0.5, 0.5, 0.5);
        x *= 2;
        y *= 2;
        endX *= 2;
        endY *= 2;
        glEnable(3042);
        glDisable(3553);
        glColor4f(f2, f3, f4, f);
        glEnable(2848);
        glBegin(9);
        for (n2 = 0; n2 <= 90; n2 += 3) {
            glVertex2d(x + radius + Math.sin((double) n2 * (6.5973445528769465 * 0.4761904776096344) / (double) 180) * (radius * (double) -1), y + radius + Math.cos((double) n2 * (42.5 * 0.07391982714328925) / (double) 180) * (radius * (double) -1));
        }
        for (n2 = 90; n2 <= 180; n2 += 3) {
            glVertex2d(x + radius + Math.sin((double) n2 * (0.5711986642890533 * 5.5) / (double) 180) * (radius * (double) -1), endY - radius + Math.cos((double) n2 * (0.21052631735801697 * 14.922564993369743) / (double) 180) * (radius * (double) -1));
        }
        for (n2 = 0; n2 <= 90; n2 += 3) {
            glVertex2d(endX - radius + Math.sin((double) n2 * (4.466951941998311 * 0.7032967209815979) / (double) 180) * radius, endY - radius + Math.cos((double) n2 * (28.33333396911621 * 0.11087973822685955) / (double) 180) * radius);
        }
        for (n2 = 90; n2 <= 180; n2 += 3) {
            glVertex2d(endX - radius + Math.sin((double) n2 * ((double) 0.6f * 5.2359875479235365) / (double) 180) * radius, y + radius + Math.cos((double) n2 * (2.8529412746429443 * 1.1011767685204017) / (double) 180) * radius);
        }
        glEnd();
        glEnable(3553);
        glDisable(3042);
        glDisable(2848);
        glDisable(3042);
        glEnable(3553);
        glScaled(2, 2, 2);
        glPopAttrib();
    }
    public static void drawRect(double x, double y, double endX, double endY, int color) {
        drawRoundedRect(x, y, endX, endY, 1f, color);
    }

    public static com.craftrise.ah calculateAdjustedEntityBoundingBox(final com.craftrise.m9 entity, double offsetX, double offsetY, double offsetZ) {
        final com.craftrise.ah entityBoundingBox = Minecraft.getEntityBoundingBox(entity);
        offsetX -= ThePlayer.GetPosX(entity);
        offsetY -= ThePlayer.GetPosY(entity);
        offsetZ -= ThePlayer.GetprevPosZ(entity);
        return new com.craftrise.ah(entityBoundingBox.c + offsetX, entityBoundingBox.a + offsetY, entityBoundingBox.f + offsetZ, entityBoundingBox.e + offsetX, entityBoundingBox.g + offsetY, entityBoundingBox.d + offsetZ);
    }

    public static com.craftrise.ah calculateAdjustedEntityBoundingBox(final com.craftrise.m9 entity, final float partialTicks) {
        return calculateAdjustedEntityBoundingBox(entity, ThePlayer.GetlastTickPosX(entity) + (ThePlayer.GetPosX(entity) - ThePlayer.GetlastTickPosX(entity)) * partialTicks - Minecraft.getRenderManager().j, ThePlayer.GetlastTickPosY(entity) + (ThePlayer.GetPosY(entity) - ThePlayer.GetlastTickPosY(entity)) * partialTicks - Minecraft.getRenderManager().t, ThePlayer.GetlastTickPosZ(entity) + (ThePlayer.GetprevPosZ(entity) - ThePlayer.GetlastTickPosZ(entity)) * partialTicks - Minecraft.getRenderManager().c);
    }


    public static boolean basicCollisionCheck(double mouseX, double mouseY, double x, double y, double endX, double endY) {
        return mouseX >= x & mouseX <= endX & mouseY >= y & mouseY <= endY;
    }

    public static int applyOpacity(int color, float opacity) {
        Color old = new Color(color);
        return applyOpacity(old, opacity).getRGB();
    }


    public static Color applyOpacity(Color color, float opacity) {
        opacity = Math.min(1.0f, Math.max(0.0f, opacity));
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int) ((float) color.getAlpha() * opacity));
    }

    public static Color brighter(Color color, float FACTOR) {
        int r = color.getRed();
        int g = color.getGreen();
        int b = color.getBlue();
        int alpha = color.getAlpha();
        int i = (int) (1.0 / (1.0 - FACTOR));
        if (r == 0 && g == 0 && b == 0) {
            return new Color(i, i, i, alpha);
        }
        if (r > 0 && r < i) r = i;
        if (g > 0 && g < i) g = i;
        if (b > 0 && b < i) b = i;

        return new Color(Math.min((int) (r / FACTOR), 255),
                Math.min((int) (g / FACTOR), 255),
                Math.min((int) (b / FACTOR), 255),
                alpha);
    }

    public static void drawCircle(final com.craftrise.m9 entity, final double rad, final boolean shade) {
        GL11.glPushMatrix();
        GL11.glDisable(3553);
        GL11.glEnable(2848);
        GL11.glEnable(2832);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glHint(3154, 4354);
        GL11.glHint(3155, 4354);
        GL11.glHint(3153, 4354);
        GL11.glDepthMask(false);
        com.craftrise.client.bO.a(GL11.GL_GREATER, 0.0F);
        if (shade) GL11.glShadeModel(GL11.GL_SMOOTH);
        com.craftrise.client.bO.K();
        GL11.glBegin(GL11.GL_TRIANGLE_STRIP);

        final double x = entity.a6 + (entity.bE - entity.a6) * 0.9F - Minecraft.getRenderManager().h;
        final double y = (entity.h + (entity.aY - entity.h) * 0.9F - Minecraft.getRenderManager().n) + 1;
        final double z = entity.G + (entity.bH - entity.G) * 0.9F - Minecraft.getRenderManager().g;

        Color c;

        for (float i = 0; i < Math.PI * 2; i += Math.PI * 2 / 64.F) {
            final double vecX = x + rad * Math.cos(i);
            final double vecZ = z + rad * Math.sin(i);

            c = new Color(255,255,255,255);

            if (shade) {
                GL11.glColor4f(c.getRed() / 255.F,
                        c.getGreen() / 255.F,
                        c.getBlue() / 255.F,
                        0
                );
                GL11.glVertex3d(vecX, y - Math.cos(System.currentTimeMillis() / 2E+2) / 2.0F, vecZ);
                GL11.glColor4f(c.getRed() / 255.F,
                        c.getGreen() / 255.F,
                        c.getBlue() / 255.F,
                        0.85F
                );
            }
            GL11.glVertex3d(vecX, y, vecZ);
        }

        GL11.glEnd();
        if (shade) GL11.glShadeModel(GL11.GL_FLAT);
        GL11.glDepthMask(true);
        GL11.glEnable(2929);
        com.craftrise.client.bO.a(GL11.GL_GREATER, 0.1F);
        com.craftrise.client.bO.q();
        GL11.glDisable(2848);
        GL11.glDisable(2848);
        GL11.glEnable(2832);
        GL11.glEnable(3553);
        GL11.glPopMatrix();
        GL11.glColor3f(255, 255, 255);
    }

    public static void color(int color, float alpha)
    {
        float r = (float)(color >> 16 & 255) / 255.0F;
        float g = (float)(color >> 8 & 255) / 255.0F;
        float b = (float)(color & 255) / 255.0F;
        GlStateManager.color(r, g, b, alpha);
    }

    // Colors the next texture without a specified alpha value
    public static void color(int color)
    {
        color(color, (float)(color >> 24 & 255) / 255.0F);
    }
}
