package today.makrit.utils;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class MathUtils
{

    public static double round(double var0, double var2) {
        if (var2 < 0.0D) {
            throw new IllegalArgumentException();
        } else {
            BigDecimal var4 = new BigDecimal(var0);
            var4 = var4.setScale((int)var2, RoundingMode.HALF_UP);
            return var4.doubleValue();
        }
    }

    public static double square(double var0) {
        var0 *= var0;
        return var0;
    }
    public static float roundToFloat(double d)
    {
        return (float)((double)Math.round(d * 1.0E8D) / 1.0E8D);
    }
    public static int getAverage(int[] vals)
    {
        if (vals.length <= 0)
        {
            return 0;
        }
        else
        {
            int sum = 0;
            int avg;

            for (avg = 0; avg < vals.length; ++avg)
            {
                int val = vals[avg];
                sum += val;
            }

            avg = sum / vals.length;
            return avg;
        }
    }
}
