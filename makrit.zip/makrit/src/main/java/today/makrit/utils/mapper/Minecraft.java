package today.makrit.utils.mapper;

import today.makrit.Main;
import today.makrit.gui.ArticPlayerController;
import today.makrit.utils.Helper.BlockHelper;
import today.makrit.utils.Renderer.ArticEffectRenderer;
import com.craftrise.client.*;
import com.craftrise.lG;
import com.craftrise.lU;
import com.craftrise.on;
import cr.launcher.BlockPos;
import cr.launcher.Config;
import cr.launcher.IChatComponent;
import cr.launcher.ResourceLocation;
import cr.launcher.main.a;
import com.craftrise.client.dt;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Minecraft {
    public static fa GetPlayer() {
        return a.q;
    }

    public static com.craftrise.qJ openContainer(final com.craftrise.mg entityPlayer) {
        return entityPlayer.T;
    }

    public static S GetMinecraft() {
        return Config.getMinecraft();
    }

    public be getFramebuffer() {
        try {
            Field fi = S.class.getDeclaredField("ak");
            fi.setAccessible(true);
            return (be)fi.get(Config.getMinecraft());
        } catch (Exception var2) {
            var2.printStackTrace();
            return null;
        }
    }
    public static be frameBufferClear() {
        try {
            Class classMethod = Class.forName("com.craftrise.client.be");
            Field fieldMethod = classMethod.getDeclaredField("b");
            fieldMethod.setAccessible(true);
            return (be)fieldMethod.get(Config.getMinecraft());
        } catch (Exception var2) {
            return null;
        }
    }
    public static be getFrameBuffer() {
        be frameBuffer = null;

        try {
            Class<?> sClass = Class.forName("com.craftrise.client.S");
            Method aMethod = sClass.getDeclaredMethod("a");
            Object result = aMethod.invoke((Object)null);
            frameBuffer = (be)result;
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException | ClassNotFoundException var4) {
            var4.printStackTrace();
        }

        return frameBuffer;
    }

    public static cf GetWorld() {
        return Minecraft.GetMinecraft().bu;
    }

    public static int displayWidth() {
        return Minecraft.GetMinecraft().aK;
    }

    public static int displayHeight() {
        return Minecraft.GetMinecraft().bF;
    }

    public static lU getInventoryPlayerObj() { return Minecraft.GetPlayer().J; }

    public static ez GetPlayerControllerMp() {
        return Minecraft.GetMinecraft().b;
    }

    public static d0 GetFontRendererObj() {
        return Minecraft.GetMinecraft().j;
    }

    public static dt InGameGui() {
        return Minecraft.GetMinecraft().K;
    }

    public static void setInGameGui(com.craftrise.client.dt gui) {
        Minecraft.GetMinecraft().K = gui;
    }

    public static void  drawStrHook(com.craftrise.client.d0 hook) {
        Minecraft.GetMinecraft().j = hook;
    }


    public static void setEffectRenderer(ArticEffectRenderer hook) {
        Minecraft.GetMinecraft().V = hook;
    }

    public static void setPlayerController(ArticPlayerController hook) {
        Minecraft.GetMinecraft().b = hook;
    }

//    public static int getSizeInventory(){
//        return getInventoryPlayerObj().d();
//    }

    public static Object START_DESTROY_BLOCK() {
        try {
            Class<?> enumClass = Class.forName("com.craftrise.kh$a");
            Field attackField = enumClass.getField("START_DESTROY_BLOCK");

            Object StartDestroyBlockEnum = attackField.get(null);

            return StartDestroyBlockEnum;
        } catch (ClassNotFoundException | NoSuchFieldException | IllegalAccessException e) {
            Config.warn(e.getMessage());
            return null;
        }
    }

    public static Object STOP_DESTROY_BLOCK() {
        try {
            Class<?> enumClass = Class.forName("com.craftrise.kh$a");
            Field attackField = enumClass.getField("STOP_DESTROY_BLOCK");

            Object StopDestroyBlockEnum = attackField.get(null);

            return StopDestroyBlockEnum;
        } catch (ClassNotFoundException | NoSuchFieldException | IllegalAccessException e) {
            Config.warn(e.getMessage());
            return null;
        }
    }

    public static com.craftrise.client.gD getTextureManager() {
        return Config.getTextureManager();
    }

    public ResourceLocation getLocationSkin(Object target) {
        ResourceLocation result = null;
        try {
            Class<?> AbstractClientPlayerClazz = Class.forName("com.craftrise.client.f1");

            for (Method m : AbstractClientPlayerClazz.getDeclaredMethods()) {
                if (m.getName().equals("b")) {
                    if (m.getParameterCount() == 0) {
                        if (m.getReturnType().toString().contains("ResourceLocation")) {
                            m.setAccessible(true);
                            result = (ResourceLocation) m.invoke(target);
                        }
                    }
                }
            }
        } catch (ClassNotFoundException | IllegalAccessException | InvocationTargetException e) {
            Minecraft.addChatMessage(e.toString());
        }
        return result;
    }



    public static ResourceLocation getLocationSkin2(Object target) {
        ResourceLocation result = null;
        try {
            Class<?> AbstractClientPlayerClazz = Class.forName("com.craftrise.client.f1");

            for (Method m : AbstractClientPlayerClazz.getDeclaredMethods()) {
                if (m.getName().equals("b")) {
                    if (m.getParameterCount() == 0) {
                        if (m.getReturnType().toString().contains("ResourceLocation")) {
                            m.setAccessible(true);
                            result = (ResourceLocation) m.invoke(target);
                        }
                    }
                }
            }
        } catch (ClassNotFoundException | IllegalAccessException | InvocationTargetException e) {
            Minecraft.addChatMessage(e.toString());
        }
        return result;
    }

    public static String getCommandSenderName(Object target) {
        String result = null;
        try {
            Class<?> AbstractClientPlayerClazz = Class.forName("com.craftrise.client.f1");

            for (Method m : AbstractClientPlayerClazz.getDeclaredMethods()) {
                if (m.getName().equals("a")) {
                    if (m.getParameterCount() == 0) {
                        if (m.getReturnType().toString().contains("(J)Ljava/lang/String")) {
                            m.setAccessible(true);
                            result = (String) m.invoke(target);
                        }
                    }
                }
            }
        } catch (ClassNotFoundException | IllegalAccessException | InvocationTargetException e) {
            Minecraft.addChatMessage(e.toString());
        }
        return result;
    }

    public static Object getMinecraftObj() {
        Object result = null;
        try {
            Class MinecraftClazz = Class.forName("com.craftrise.client.S");
            Field theMinecraftField = MinecraftClazz.getDeclaredField("cj");
            theMinecraftField.setAccessible(true);
            Object theMinecraft = theMinecraftField.get(null);

            result = theMinecraft;
        } catch (ClassNotFoundException | NoSuchFieldException | IllegalAccessException e) {
            Config.warn(e.getMessage());
        }

        return result;
    }

    public static Object getPlayerController() {
        Object result = null;

        try {
            Class MinecraftClazz = Class.forName("com.craftrise.client.S");
            Field f = MinecraftClazz.getDeclaredField("b");
            f.setAccessible(true);
            result = f.get(getMinecraftObj());
        } catch (ClassNotFoundException | NoSuchFieldException | IllegalAccessException e) {
            Config.warn(e.getMessage());
        }


        return result;
    }

    public static Object getNetClientHandler() {
        Object result = null;

        try {
            Class PlayerControllerClazz = Class.forName("com.craftrise.client.ez");
            Field netClientHandlerField = PlayerControllerClazz.getDeclaredField("a");
            netClientHandlerField.setAccessible(true);
            result = netClientHandlerField.get(getPlayerController());
        } catch (ClassNotFoundException | NoSuchFieldException | IllegalAccessException e) {
            Config.warn(e.getMessage());
        }

        return result;
    }

    public static void addChatMessage(String message) {
        try {
            Class EntityPlayerSpClazz = Class.forName("com.craftrise.client.fa");

            Class<?>[] paramTypes = {IChatComponent.class, long.class};

            Method adddMessage = EntityPlayerSpClazz.getDeclaredMethod("a", paramTypes);
            Method adddMessage2 = EntityPlayerSpClazz.getDeclaredMethod("a", paramTypes);

            Class<?>[] paramTypesChatCompoent = {IChatComponent.class, long.class};

            Class IChatComponentClazz = Class.forName("cr.launcher.ChatComponentText");
            Constructor<?> stringChatText = IChatComponentClazz.getConstructor(String.class);
            Object chatComponent = stringChatText.newInstance(message);

            adddMessage.invoke((Object) GetPlayer(), chatComponent, Main.idk);
        } catch (Exception e) {
            Config.warn("Exception: " + e.getMessage());
        }
    }

    public static void addChatMessage2(String message) {
        try {
            message = String.format("%s" , message);
            Class EntityPlayerSpClazz = Class.forName("com.craftrise.client.fa");

            Class<?>[] paramTypes = {IChatComponent.class, long.class};

            Method adddMessage = EntityPlayerSpClazz.getDeclaredMethod("a", paramTypes);
            Method adddMessage2 = EntityPlayerSpClazz.getDeclaredMethod("a", paramTypes);

            Class<?>[] paramTypesChatCompoent = {IChatComponent.class, long.class};

            Class IChatComponentClazz = Class.forName("cr.launcher.ChatComponentText");
            Constructor<?> stringChatText = IChatComponentClazz.getConstructor(String.class);
            Object chatComponent = stringChatText.newInstance(message);

            adddMessage.invoke((Object) GetPlayer(), chatComponent, Main.idk);
        } catch (Exception e) {
            Config.warn("Exception: " + e.getMessage());
        }
    }

    public static void addToSendQueue(Object packet) {
        try {
            Class NetClientHandlerClazz = Class.forName("com.craftrise.client.c9");
            Class<?>[] paramTypes = {com.craftrise.lv.class, long.class};
            Method m = NetClientHandlerClazz.getDeclaredMethod("a", paramTypes);
            m.invoke(getNetClientHandler(), packet, Main.idk);
        } catch (Exception e) {
            Config.warn(e.getMessage());
        }
    }
    public static String addToSendQueue2(Object packet) {
        try {
            Class NetClientHandlerClazz = Class.forName("com.craftrise.client.c9");
            Class<?>[] paramTypes = {com.craftrise.lv.class, long.class};
            Method m = NetClientHandlerClazz.getDeclaredMethod("a", paramTypes);
            m.invoke(getNetClientHandler(), packet, Main.idk);
        } catch (Exception e) {
            Config.warn(e.getMessage());
        }
        return null;
    }
    public static Object getAttackAction() {
        try {
            Class<?> enumClass = Class.forName("com.craftrise.on$a");
            Field attackField = enumClass.getField("ATTACK");

            Object attackEnum = attackField.get(null);

            return attackEnum;
        } catch (ClassNotFoundException | NoSuchFieldException | IllegalAccessException e) {
            Config.warn(e.getMessage());
            return null;
        }
    }
    public static Object C02EntityUseAttack(Object entity) {
        Object result = null;

        try {
            Class C02EntityUse = Class.forName("com.craftrise.on");

            Class<?>[] paramTypes = {com.craftrise.m9.class, on.a.class};

            Constructor<?> constructor = C02EntityUse.getConstructor(paramTypes);

            Object instance = constructor.newInstance(entity, getAttackAction());

            result = instance;
        } catch (Exception e) {
            Config.warn(e.getMessage());
        }

        return result;
    }

    public static Object C05PacketPlayerLook(float playerYaw, float playerPitch, boolean isOnGround) {
        Object result = null;
        try {
            Class C02EntityUse = Class.forName("com.craftrise.lE$b");

            Class<?>[] paramTypes = {float.class, float.class, boolean.class};

            Constructor<?> constructor = C02EntityUse.getConstructor(paramTypes);

            Object instance = constructor.newInstance(playerYaw, playerPitch, isOnGround);

            result = instance;
        } catch (Exception e) {
            //addChatMessage(e.getMessage());
            //Config.warn(e.getMessage());
        }
        return result;
    }

    public static Object SO8PacketPlayerPOSLook(float playerYaw, float playerPitch, boolean isOnGround) {
        Object result = null;
        try {
            Class C02EntityUse = Class.forName("com.craftrise.lE$b");

            Class<?>[] paramTypes = {float.class, float.class, boolean.class};

            Constructor<?> constructor = C02EntityUse.getConstructor(paramTypes);

            Object instance = constructor.newInstance(playerYaw, playerPitch, isOnGround);

            result = instance;
        } catch (Exception e) {
            //addChatMessage(e.getMessage());
            //Config.warn(e.getMessage());
        }
        return result;
    }

    public static Object S08PacketPlayerPosLook(float playerYaw, float playerPitch, boolean isOnGround) {
        Object result = null;

        try {
            Class C02EntityUse = Class.forName("com.craftrise.gy$a");

            Class<?>[] paramTypes = {float.class, float.class, boolean.class};

            Constructor<?> constructor = C02EntityUse.getConstructor(paramTypes);

            Object instance = constructor.newInstance(playerYaw, playerPitch, isOnGround);

            result = instance;
        } catch (Exception e) {
            //addChatMessage(e.getMessage());
            Config.warn(e.getMessage());
        }

        return result;
    }

    public static Object C06PacketPlayerPosLook(float playerYaw, float playerPitch, boolean isOnGround) {
        Object result = null;

        try {
            Class C02EntityUse = Class.forName("com.craftrise.lE$c");

            Class<?>[] paramTypes = {float.class, float.class, boolean.class};

            Constructor<?> constructor = C02EntityUse.getConstructor(paramTypes);

            Object instance = constructor.newInstance(playerYaw, playerPitch, isOnGround);

            result = instance;
        } catch (Exception e) {
            //addChatMessage(e.getMessage());
            Config.warn(e.getMessage());
        }

        return result;
    }



    public static Object S19PacketEntityHeadLook(float playerYaw, float playerPitch, boolean isOnGround) {
        Object result = null;

        try {
            Class C02EntityUse = Class.forName("com.craftrise.p_");

            Class<?>[] paramTypes = {float.class, float.class, boolean.class};

            Constructor<?> constructor = C02EntityUse.getConstructor(paramTypes);

            Object instance = constructor.newInstance(playerYaw, playerPitch, isOnGround);

            result = instance;
        } catch (Exception e) {
            //addChatMessage(e.getMessage());
            Config.warn(e.getMessage());
        }

        return result;
    }
    public static Object S02PacketChat() {
        Object result = null;

        try {
            Class<?> S02PacketChatClass = Class.forName("com.craftrise.pT");

            // Assuming that your pT and on.a classes are correctly imported and defined
            Class<?> onAClass = Class.forName("on.a");

            // You only need pT class as a parameter
            Class<?>[] paramTypes = {onAClass};
            Constructor<?> constructor = S02PacketChatClass.getConstructor(paramTypes);

            on.a onAInstance = null;  // Replace null with an actual instance of on.a

            Object instance = constructor.newInstance(onAInstance);
            result = instance;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }
    public static void sendSwing() {
        try {
            Class EntityLivingBaseClazz = Class.forName("com.craftrise.mj");

            for (Method m : EntityLivingBaseClazz.getDeclaredMethods()) {
                if(m.getName().equals("G") && m.getParameterCount() == 1) {
                    m.invoke((Object) GetPlayer(), Main.idk);
                }
            }
        } catch (ClassNotFoundException | IllegalAccessException | InvocationTargetException e) {
            Config.warn(e.getMessage());
        }
    }

    public static float getEntityHealth(Object entity) {
        float healht = 31;

        try {
            Class EntityLivingBaseClazz = Class.forName("com.craftrise.mj");

            for(Method m : EntityLivingBaseClazz.getDeclaredMethods()) {
                if(m.getName().equals("k") && m.getParameterCount() == 0 && m.getReturnType().equals(float.class)) {
                    Object result = m.invoke(entity);
                    healht = (float) result;
                }
            }
        } catch (ClassNotFoundException | IllegalAccessException | InvocationTargetException e) {
            Config.warn(e.getMessage());
        }

        return  healht;
    }

    public static com.craftrise.client.dG getCurrentScreen() {
        return Config.getMinecraft().bw;
    }

    public static int getScreenWidth() {
        int health = 31;

        try {
            Class<?> entityLivingBaseClazz = Class.forName("com.craftrise.client.y");

            for (Method m : entityLivingBaseClazz.getDeclaredMethods()) {
                if (m.getName().equals("a") && m.getParameterCount() == 0 && m.getReturnType().equals(int.class)) {
                    Object result = m.invoke(new com.craftrise.client.y(Config.getMinecraft()) );
                    health = (int)result;
                }
            }
        } catch (ClassNotFoundException | IllegalAccessException | InvocationTargetException e) {
            Config.warn(e.getMessage());
        }

        return health;
    }

    public static int getScreenHeight() {
        int health = 31;

        try {
            Class<?> entityLivingBaseClazz = Class.forName("com.craftrise.client.y");

            for (Method m : entityLivingBaseClazz.getDeclaredMethods()) {
                if (m.getName().equals("c") && m.getParameterCount() == 0 && m.getReturnType().equals(int.class)) {
                    Object result = m.invoke(new com.craftrise.client.y(Config.getMinecraft()) );
                    health = (int)result;
                }
            }
        } catch (ClassNotFoundException | IllegalAccessException | InvocationTargetException e) {
            Config.warn(e.getMessage());
        }

        return health;
    }

    public static void setRightClickDelayTimer() {
        try {
            Class MinecraftClazz = Class.forName("com.craftrise.client.S");

            for(Field f : MinecraftClazz.getDeclaredFields()) {
                if(f.getName().equals("cB")) {
                    f.setAccessible(true);
                    f.set((Object) Minecraft.GetMinecraft(), 0);
                }
            }
        } catch (ClassNotFoundException | IllegalAccessException e) {
            //Handle Exception
        }
    }

    public static void windowClick() {
        try {
            Class MinecraftClazz = Class.forName("com.craftrise.gM");

            for (Field f : MinecraftClazz.getDeclaredFields()) {
                if (f.getName().equals("a")) {
                    f.setAccessible(true);
                    f.set((Object) Minecraft.GetMinecraft(), 0);
                }
            }
        } catch (ClassNotFoundException | IllegalAccessException e) {
            //Handle Exception
        }
    }

    public static void setGammaSetting(int value) {
        try {
            Class MinecraftClazz = Class.forName("com.craftrise.client.cz");

            for(Field f : MinecraftClazz.getDeclaredFields()) {
                if(f.getName().equals("y")) {
                    f.setAccessible(true);
                    f.set((Object) Config.getGameSettings(), value);
                }
            }
        } catch (ClassNotFoundException | IllegalAccessException e) {
            //Handle Exception
        }
    }

    public static int getDebugFPS() {
        int fps = 31;

        try {
            Class<?> MinecraftClazz = Class.forName("com.craftrise.client.S");
            for (Method m : MinecraftClazz.getDeclaredMethods()) {
                if (m.getName().equals("b") && m.getParameterCount() == 0 && m.getReturnType().equals(int.class)) {
                    Object result = m.invoke(new com.craftrise.client.y(Config.getMinecraft()) );
                    fps = (int)result;
                }
            }
        } catch (ClassNotFoundException | IllegalAccessException | InvocationTargetException e) {
            System.out.println(e);
        }

        return fps;
    }


    public static float[] getRotationFromPosition(double x, double z, double y) {
        double xDiff = x - ThePlayer.GetPosY();
        double zDiff = z - ThePlayer.GetPosZ();
        double yDiff = y - ThePlayer.GetPosY() - 0.6;
        double dist = Math.sqrt(xDiff * xDiff + zDiff * zDiff);
        float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(yDiff, dist) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }

    public static float[] getRotations(double d, double d2, double d3) {
        double d4 = d + 0.5 - ThePlayer.GetPosX();
        double d5 = (d2 + 0.5) / 2.0 - (ThePlayer.GetPosY() + 2.0);
        double d6 = d3 + 0.5 - ThePlayer.GetMotionZ();
        double d7 = Math.sqrt(d4 * d4 + d6 * d6);
        float f = (float)(Math.atan2(d6, d4) * 180.0 / Math.PI) - 90.0f;
        float f2 = (float)(-(Math.atan2(d5, d7) * 180.0 / Math.PI));
        return new float[]{f, f2};
    }

    public static synchronized void faceEntity(com.craftrise.m9 m92) {
        double d = m92.bE - ThePlayer.GetPosX();
        double d2 = m92.aY - ThePlayer.GetPosZ();
        double d3 = m92.bH - ThePlayer.GetPosY() + (double)m92.t / 1.5;
        double d4 = Math.sqrt(d * d + d2 * d2);
        float f = (float)(Math.atan2(d2, d) * 180.0 / Math.PI) - 90.0f;
        float f2 = (float)(-(Math.atan2(d3, d4) * 180.0 / Math.PI));
        ThePlayer.SetRotationPitch(ThePlayer.GetRotationPitch() + (f2 - ThePlayer.GetRotationPitch() + 180.0f) % 360.0f - 180.0f);
        ThePlayer.SetRotationYaw(ThePlayer.GetrotationYaw() + (f - ThePlayer.GetrotationYaw() + 180.0f) % 360.0f - 180.0f);
    }

    public static String getEntityDisplayName(com.craftrise.m9 entity) {
        String res = "null";
        try {
            Class EntityClazz = Class.forName("com.craftrise.m9");

            for (Method m : EntityClazz.getDeclaredMethods()) {
                if(m.getReturnType().toString().contains("cr.launcher.IChatComponent")) {
                    m.setAccessible(true);
                    IChatComponent yarrak = (IChatComponent) m.invoke(entity);

                    res = yarrak.getFormattedText();
                }
            }
        } catch (Exception e) {
            Minecraft.addChatMessage(e.toString() + " yaa");
        }

        return res;
    }

    public static String getEntityDisplayName2(String entity) {
        String res = "null";
        try {
            Class EntityClazz = Class.forName("com.craftrise.m9");

            for (Method m : EntityClazz.getDeclaredMethods()) {
                if(m.getReturnType().toString().contains("cr.launcher.IChatComponent")) {
                    m.setAccessible(true);
                    IChatComponent yarrak = (IChatComponent) m.invoke(entity);

                    res = yarrak.getFormattedText();
                }
            }
        } catch (Exception e) {
            Minecraft.addChatMessage(e.toString() + " yaa");
        }

        return res;
    }

    private static String removeColorCodes(String input) {
        return input.replaceAll("§[0-9a-fA-F]", "");
    }


    public static int getBlockID(final BlockPos pos) {
        cf World = GetWorld();
        com.craftrise.pI BlockState = World.getBlockState(pos);
        int idFromBlock = 0;
        Object block = null;

        try {
            for(Method m : BlockState.getClass().getDeclaredMethods()) {
                if(m.getReturnType().toString().contains("com.craftrise.dN")) {
                    m.setAccessible(true);

                    block = m.invoke(BlockState);
                    idFromBlock = BlockHelper.getIdFromBlock((com.craftrise.dN) block);
                }
            }
        } catch (Exception e) {
            Minecraft.addChatMessage(e.toString());
        }

        return idFromBlock;
    }

    public static Object C07PacketPlayerDiggingAbortDestroyBlockEnum() {
        try {
            Class<?> enumClass = Class.forName("com.craftrise.kh$a");
            Field attackField = enumClass.getField("ABORT_DESTROY_BLOCK");

            Object AbortDestroyBlockEnum = attackField.get(null);

            return AbortDestroyBlockEnum;
        } catch (ClassNotFoundException | NoSuchFieldException | IllegalAccessException e) {
            Config.warn(e.getMessage());
            return null;
        }
    }

    public static Object C0BPacketEntityActionSTOPSprint() {
        try {
            Class<?> enumClass = Class.forName("com.craftrise.pN$a");
            Field attackField = enumClass.getField("STOP_SPRINTING");

            Object C0BPacketEntityAction1 = attackField.get(null);

            return C0BPacketEntityAction1;
        } catch (ClassNotFoundException | NoSuchFieldException | IllegalAccessException e) {
            Config.warn(e.getMessage());
            return null;
        }
    }

    public static Object C0BPacketEntityActionSTARTSprint() {
        try {
            Class<?> enumClass = Class.forName("com.craftrise.pN$a");
            Field attackField = enumClass.getField("START_SPRINTING");

            Object C0BPacketEntityAction2 = attackField.get(null);

            return C0BPacketEntityAction2;
        } catch (ClassNotFoundException | NoSuchFieldException | IllegalAccessException e) {
            Config.warn(e.getMessage());
            return null;
        }
    }
    public static Object S19PacketEntityStatus() {
        try {
            Class<?> enumClass = Class.forName("com.craftrise.aW");
            Field attackField = enumClass.getField("ABORT_DESTROY_BLOCK");

            Object AbortDestroyBlockEnum = attackField.get(null);

            return AbortDestroyBlockEnum;
        } catch (ClassNotFoundException | NoSuchFieldException | IllegalAccessException e) {
            Config.warn(e.getMessage());
            return null;
        }
    }

    public static com.craftrise.client.ez getPlayerController2() {
        return Config.getMinecraft().b;
    }

    public static Object EnumFacingUp() {
        try {
            Class<?> enumClass = Class.forName("com.craftrise.lG");
            Field attackField = enumClass.getField("UP");

            Object EnumFacingUp = attackField.get(null);

            return EnumFacingUp;
        } catch (ClassNotFoundException | NoSuchFieldException | IllegalAccessException e) {
            Config.warn(e.getMessage());
            return null;
        }
    }

    public static Object C07PacketPlayerDigging(Object actionEnum, BlockPos blockPos, Object enumFacing) {
        Object result =  null;

        try {
            Class C07PlayerDigging = Class.forName("com.craftrise.kh");

            Class<?>[] paramTypes = {Class.forName("com.craftrise.kh$a"), BlockPos.class, lG.class };

            Constructor<?> constructor = C07PlayerDigging.getConstructor(paramTypes);

            constructor.setAccessible(true);

            Object instance = constructor.newInstance(actionEnum, blockPos, enumFacing);

            result = instance;
        } catch (Exception e) {
            Minecraft.addChatMessage(e.toString());
        }

      return result;
    };

    public static com.craftrise.ah getEntityBoundingBox(com.craftrise.m9 entity) {
        Object result = null;

        try {
            for(Field f : entity.getClass().getDeclaredFields()) {
                if(f.getName().equals("aW")) {
                    f.setAccessible(true);

                    result = f.get(entity);
                }
            }
        } catch (Exception e) {
            Minecraft.addChatMessage(e.toString());
        }

        return (com.craftrise.ah) result;
    }

    public static com.craftrise.client.g8 getRenderManager() {
        Object result = null;

        try {
            for (Method m : Minecraft.GetMinecraft().getClass().getDeclaredMethods()) {
                if(m.getName().equals("a") && m.getReturnType().toString().contains("com.craftrise.client.g8")) {

                    m.setAccessible(true);

                    result = m.invoke(GetMinecraft());
                }
            }
        } catch (Exception e) {
            Minecraft.addChatMessage(e.toString());
        }

        return (com.craftrise.client.g8) result;
    }
    public static com.craftrise.client.fV getResourceManager() {
        Object result = null;

        try {
            for (Method m : Minecraft.GetMinecraft().getClass().getDeclaredMethods()) {
                if(m.getName().equals("a") && m.getReturnType().toString().contains("com.craftrise.client.fV")) {

                    m.setAccessible(true);

                    result = m.invoke(GetMinecraft());
                }
            }
        } catch (Exception e) {
            Minecraft.addChatMessage(e.toString());
        }

        return (com.craftrise.client.fV) result;
    }

    public static Object C06PacketPlayerLook(double d, double d2, double d4, float f, float f2, boolean bl) {
        Object result = null;

        try {
            Class C02EntityUse = Class.forName("com/craftrise/lE$c");

            Class<?>[] paramTypes = {double.class, double.class, double.class,float.class,float.class,boolean.class};

            Constructor<?> constructor = C02EntityUse.getConstructor(paramTypes);

            Object instance = constructor.newInstance(d,d2, d4, f,f2,bl);

            result = instance;
        } catch (Exception e) {
            //addChatMessage(e.getMessage());
            Config.warn(e.getMessage());
        }

        return result;
    }




}
