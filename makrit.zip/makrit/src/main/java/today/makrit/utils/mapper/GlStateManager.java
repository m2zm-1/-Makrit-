package today.makrit.utils.mapper;

import com.craftrise.client.bO;
import org.lwjgl.opengl.GL11;

import java.nio.FloatBuffer;

public class GlStateManager{
    //  private static final GlStateManager.DepthState depthState = new GlStateManager.DepthState();
    private static boolean openGL14 = false;
    public static void pushAttrib(){
        bO.f();
    }
    private static GlStateManager.DepthState depthState = new GlStateManager.DepthState((GlStateManager.SwitchTexGen)null);
    public static void disableTexture2D(){
        bO.r();
    }
    public static void enableTexture2D(){

        try{
            bO.class.getMethod("c").invoke(null);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public static void depthMask(boolean p_179132_0_)
    {
        if (p_179132_0_ != depthState.field_179050_b)
        {
            depthState.field_179050_b = p_179132_0_;
            GL11.glDepthMask(p_179132_0_);
        }
    }
    public static int generateTexture() {
        return GL11.glGenTextures();
    }
    public static void enableDepth()
    {
        depthState.field_179052_a.setEnabled();
    }
    public static void disableDepth()
    {
        depthState.field_179052_a.setDisabled();
    }
    public static void disableLighting()
    {
        bO.I();
    }
    public static void enableCull()
    {
        bO.p();
    }

    public static void disableCull()
    {
        bO.u();
    }

    public static void setActiveTexture(int texture){
        bO.m(texture);
    }
    public static void deleteTexture(int texture){
        bO.b(texture);
    }

    public static void bindTexture(int texture){
        bO.l(texture);
    }
    public static void enableNormalize(){
        bO.o();
    }
    public static void disableNormalize(){
        bO.E();
    }
    public static void shadeModel(int mode){
        bO.o(mode);
    }

    public static void enableRescaleNormal(){
        bO.G();
    }
    public static void disableRescaleNormal(){
        bO.J();
    }
    public static void viewport(int x, int y, int width, int height){
        bO.a(x,y,width,height);
    }

    public static void colorMask(boolean red, boolean green, boolean blue, boolean alpha){
        bO.a(red,green,blue,alpha);
    }
    public static void clearDepth(double depth){
        bO.a(depth);
    }
    public static void clear(int mask){
        bO.g(mask);
    }
    public static void blendFunc(int srcFactor, int dstFactor){
        bO.b(srcFactor,dstFactor);
    }
    public static void tryBlendFuncSeparate(int srcFactor, int dstFactor, int srcFactorAlpha, int dstFactorAlpha){
        bO.b(srcFactor, dstFactor, srcFactorAlpha, dstFactorAlpha);
    }
    public static void alphaFunc(int func, float ref){
        bO.a(func, ref);
    }
    public static void disableAlpha(){
        bO.t();
    }
    public static void enableAlpha(){
        bO.h();
    }
    public static void disableBlend(){
        bO.l();
    }
    public static void enableBlend()
    {
        bO.e();
    }
    public static void matrixMode(int mode){
        bO.n(mode);
    }
    public static void loadIdentity(){
        bO.z();
    }
    public static void pushMatrix(){
        bO.H();
    }
    public static void popMatrix(){
        bO.y();
    }
    public static void ortho(double left, double right, double bottom, double top, double zNear, double zFar){
        bO.a(left,right,bottom,top,zNear,zFar);
    }
    public static void rotate(float angle, float x, float y, float z){
        bO.a(angle,x,y,z);
    }
    public static void scale(double x, double y, double z){
        bO.a(x,y,z);
    }
    public static void translate(float x, float y, float z){
        bO.b(x,y,z);
    }
    public static void translate(double x, double y, double z){
        bO.b(x,y,z);
    }
    public static void multMatrix(FloatBuffer matrix){
        bO.a(matrix);
    }
    public static void resetColor(){
        bO.x();
    }
    public static void color(float colorRed, float colorGreen, float colorBlue, float colorAlpha){
        bO.b(colorRed,colorGreen,colorBlue,colorAlpha);
    }
    public static void color(float colorRed, float colorGreen, float colorBlue){
        bO.b(colorRed, colorGreen, colorBlue, 1.0f);
    }
    static class DepthState
    {
        public GlStateManager.BooleanState field_179052_a;
        public boolean field_179050_b;
        public int field_179051_c;
        private static final String __OBFID = "CL_00002547";

        private DepthState()
        {
            this.field_179052_a = new GlStateManager.BooleanState(2929);
            this.field_179050_b = true;
            this.field_179051_c = 513;
        }

        DepthState(GlStateManager.SwitchTexGen p_i46260_1_)
        {
            this();
        }
    }
    static final class SwitchTexGen
    {
        static final int[] field_179175_a = new int[GlStateManager.TexGen.values().length];
        private static final String __OBFID = "CL_00002557";

        static
        {
            try
            {
                field_179175_a[GlStateManager.TexGen.S.ordinal()] = 1;
            }
            catch (NoSuchFieldError var4)
            {
                ;
            }

            try
            {
                field_179175_a[GlStateManager.TexGen.T.ordinal()] = 2;
            }
            catch (NoSuchFieldError var3)
            {
                ;
            }

            try
            {
                field_179175_a[GlStateManager.TexGen.R.ordinal()] = 3;
            }
            catch (NoSuchFieldError var2)
            {
                ;
            }

            try
            {
                field_179175_a[GlStateManager.TexGen.Q.ordinal()] = 4;
            }
            catch (NoSuchFieldError var1)
            {
                ;
            }
        }
    }
    public static enum TexGen
    {
        S("S", 0),
        T("T", 1),
        R("R", 2),
        Q("Q", 3);

        private static final GlStateManager.TexGen[] $VALUES = new GlStateManager.TexGen[]{S, T, R, Q};
        private static final String __OBFID = "CL_00002542";

        private TexGen(String p_i46255_1_, int p_i46255_2_) {}
    }
    static class BooleanState
    {
        private final int capability;
        private boolean currentState = false;
        private static final String __OBFID = "CL_00002554";

        public BooleanState(int p_i46267_1_)
        {
            this.capability = p_i46267_1_;
        }

        public void setDisabled()
        {
            this.setState(false);
        }

        public void setEnabled()
        {
            this.setState(true);
        }

        public void setState(boolean p_179199_1_)
        {
            if (p_179199_1_ != this.currentState)
            {
                this.currentState = p_179199_1_;

                if (p_179199_1_)
                {
                    GL11.glEnable(this.capability);
                }
                else
                {
                    GL11.glDisable(this.capability);
                }
            }
        }
    }
    static class TexGenCoord
    {
        public GlStateManager.BooleanState field_179067_a;
        public int field_179065_b;
        public int field_179066_c = -1;
        private static final String __OBFID = "CL_00002541";

        public TexGenCoord(int p_i46254_1_, int p_i46254_2_)
        {
            this.field_179065_b = p_i46254_1_;
            this.field_179067_a = new GlStateManager.BooleanState(p_i46254_2_);
        }
    }

    static class TexGenState
    {
        public GlStateManager.TexGenCoord field_179064_a;
        public GlStateManager.TexGenCoord field_179062_b;
        public GlStateManager.TexGenCoord field_179063_c;
        public GlStateManager.TexGenCoord field_179061_d;
        private static final String __OBFID = "CL_00002540";

        private TexGenState()
        {
            this.field_179064_a = new GlStateManager.TexGenCoord(8192, 3168);
            this.field_179062_b = new GlStateManager.TexGenCoord(8193, 3169);
            this.field_179063_c = new GlStateManager.TexGenCoord(8194, 3170);
            this.field_179061_d = new GlStateManager.TexGenCoord(8195, 3171);
        }

        TexGenState(GlStateManager.SwitchTexGen p_i46253_1_)
        {
            this();
        }
    }

}
