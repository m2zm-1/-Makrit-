package today.makrit.utils.Helper;

import java.nio.ByteBuffer;

public class NativeBufferHelper {
    public static byte[] convertIntArrayToByteArray(final int... intArray) {
        final ByteBuffer buffer = ByteBuffer.allocate(intArray.length * 4);
        for (int i = 0; i < intArray.length; ++i) {
            buffer.putInt(i * 4, intArray[i]);
        }
        return buffer.array();
    }

    public static byte[] convertFloatArrayToByteArray(final float... floatArray) {
        final ByteBuffer buffer = ByteBuffer.allocate(floatArray.length * 4);
        for (int i = 0; i < floatArray.length; ++i) {
            buffer.putFloat(i * 4, floatArray[i]);
        }
        return buffer.array();
    }

    public static byte[] convertShortArrayToByteArray(final short... shortArray) {
        final ByteBuffer buffer = ByteBuffer.allocate(shortArray.length * 2);
        for (int i = 0; i < shortArray.length; ++i) {
            buffer.putShort(i * 2, shortArray[i]);
        }
        return buffer.array();
    }

    public static int getIntFromByteArray(final byte[] byteArray, final int index) {
        return ByteBuffer.wrap(byteArray).getInt(index * 4);
    }

    public static int getIntFromByteArray(final byte[] byteArray) {
        return getIntFromByteArray(byteArray, 0);
    }

    public static float getFloatFromByteArray(final byte[] byteArray, final int index) {
        return ByteBuffer.wrap(byteArray).getFloat(index * 4);
    }

    public static float getFloatFromByteArray(final byte[] byteArray) {
        return getFloatFromByteArray(byteArray, 0);
    }

    public static int getShortFromByteArray(final byte[] byteArray, final int index) {
        return ByteBuffer.wrap(byteArray).getShort(index * 2);
    }

    public static int getShortFromByteArray(final byte[] byteArray) {
        return getShortFromByteArray(byteArray, 0);
    }

    public static int getUnsignedByte(final byte byteValue) {
        return (byteValue < 0) ? (256 + byteValue) : byteValue;
    }

    public static int getUnsignedByte(final int intValue) {
        return ((byte) intValue < 0) ? (256 + (byte) intValue) : ((byte) intValue);
    }

    public static int getUnsignedShort(final int intValue) {
        return (intValue < 0) ? (65536 + intValue) : intValue;
    }
}
