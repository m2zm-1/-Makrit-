package today.makrit.utils.Helper;

import today.makrit.Main;
import today.makrit.module.Module;
import today.makrit.utils.Renderer.RenderUtil;
import today.makrit.utils.mapper.Minecraft;
import today.makrit.utils.mapper.ThePlayer;
import cr.launcher.BlockPos;
import org.lwjgl.opengl.GL11;

import java.awt.*;

public class RenderHelper {
    public static com.craftrise.ah calculateAdjustedEntityBoundingBox(final com.craftrise.m9 entity, double offsetX, double offsetY, double offsetZ) {
        final com.craftrise.ah entityBoundingBox = Minecraft.getEntityBoundingBox(entity);
        offsetX -= ThePlayer.GetPosX(entity);
        offsetY -= ThePlayer.GetPosY(entity);
        offsetZ -= ThePlayer.GetprevPosZ(entity);
        return new com.craftrise.ah(entityBoundingBox.c + offsetX, entityBoundingBox.a + offsetY, entityBoundingBox.f + offsetZ, entityBoundingBox.e + offsetX, entityBoundingBox.g + offsetY, entityBoundingBox.d + offsetZ);
    }
    public static com.craftrise.ah calculateAdjustedEntityBoundingBox(final com.craftrise.m9 entity, final float partialTicks) {
        return calculateAdjustedEntityBoundingBox(entity, ThePlayer.GetlastTickPosX(entity) + (ThePlayer.GetPosX(entity) - ThePlayer.GetlastTickPosX(entity)) * partialTicks - Minecraft.getRenderManager().j, ThePlayer.GetlastTickPosY(entity) + (ThePlayer.GetPosY(entity) - ThePlayer.GetlastTickPosY(entity)) * partialTicks - Minecraft.getRenderManager().t, ThePlayer.GetlastTickPosZ(entity) + (ThePlayer.GetprevPosZ(entity) - ThePlayer.GetlastTickPosZ(entity)) * partialTicks - Minecraft.getRenderManager().c);
    }

    public static void enableTransparencyAndBlend() {
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDepthMask(false);
    }

    public static void disableTransparencyAndEnableDepth() {
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDepthMask(true);
    }

    public static void drawBorderedRect(final int x1, final int y1, final int x2, final int y2, final int color) {
        RenderUtil.drawRect(x1, y1, x2 + x1, 1 + y1, color);
        RenderUtil.drawRect(x1, y1 + 1, 1 + x1, y2 + y1, color);
        RenderUtil.drawRect(x1 + 1, y1 + y2 - 1, x2 + x1, y2 + y1, color);
        RenderUtil.drawRect(x1 + x2 - 1, y1 + 1, x1 + x2, y2 + y1 - 1, color);
    }
    public static void drawOutlinedBoundingBox(final com.craftrise.ah axisAlignedBB, final int red, final int green, final int blue, final int alpha) {
        if (alpha > 0 && !Module.drawOutlinedBoundingBoxEvent(axisAlignedBB, red, green, blue, alpha)) {
            GL11.glPushMatrix();
            com.craftrise.client.gE.a(axisAlignedBB, red, green, blue, alpha, Main.idk);
            GL11.glPopMatrix();
        }
    }

    public static void drawOutlinedBoundingBox(final com.craftrise.ah axisAlignedBB, final int rgb) {
        drawOutlinedBoundingBox(axisAlignedBB, NativeBufferHelper.getUnsignedByte(rgb >> 16), NativeBufferHelper.getUnsignedByte(rgb >> 8), NativeBufferHelper.getUnsignedByte(rgb), NativeBufferHelper.getUnsignedByte(rgb >> 24));
    }


    public static void blockESP(BlockPos blockPos) {
        GL11.glPushMatrix();
        double width = 1.0;
        double height = 1.0;
        double depth = 1.0;
        com.craftrise.ah axisAlignedBB = new com.craftrise.ah(
                BlockHelper.getX(blockPos),
                BlockHelper.getY(blockPos),
                BlockHelper.getZ(blockPos),
                BlockHelper.getX(blockPos) + width,
                BlockHelper.getY(blockPos) + height,
                BlockHelper.getZ(blockPos) + depth
        );

        GL11.glBlendFunc(770, 771);
        GL11.glEnable(GL11.GL_BLEND);

        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);

        GL11.glDepthMask(false);
        RenderHelper.drawOutlinedBoundingBox(axisAlignedBB, new Color(255, 106, 0, 255).getRGB());

        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_DEPTH_TEST);

        GL11.glDepthMask(true);

        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }

    public static void drawOutlinedBoundingBox(double x, double y, double z, final double width, final double height, final double depth, final int red, final int green, final int blue, final int alpha) {
        final com.craftrise.client.g8 renderManager = Minecraft.getRenderManager();

        x -= renderManager.j;
        y -= renderManager.t;
        z -= renderManager.c;

        drawOutlinedBoundingBox(new com.craftrise.ah(x, y, z, x + width, y + height, z + depth), red, green, blue, alpha);
    }

    public static void drawOutlinedBoundingBox(double x, double y, double z, final double width, final double height, final double depth, final int color) {
        final com.craftrise.client.g8 renderManager = Minecraft.getRenderManager();

        x -= renderManager.j;
        y -= renderManager.t;
        z -= renderManager.c;

        drawOutlinedBoundingBox(new com.craftrise.ah(x, y, z, x + width, y + height, z + depth), color);
    }

    public static void drawOutlinedBoundingBox(final com.craftrise.m9 entity, final double x, final double y, final double z) {
        drawOutlinedBoundingBox(calculateAdjustedEntityBoundingBox(entity, x, y, z), new Color(0, 255, 0, 192).getRGB());
    }

    public static void calculateAdjustedEntityBoundingBox(final double x, final double y, final double z, final int color) {
        drawOutlinedBoundingBox(x, y, z, 1.0, 1.0, 1.0, color);
    }

    public static void calculateAdjustedEntityBoundingBox(final BlockPos blockPos, final int color) {
        calculateAdjustedEntityBoundingBox(BlockHelper.getX(blockPos), BlockHelper.getY(blockPos), BlockHelper.getZ(blockPos), color);
    }
}
