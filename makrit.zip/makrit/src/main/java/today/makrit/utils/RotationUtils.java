package today.makrit.utils;

import today.makrit.Main;
import today.makrit.event.impl.MotionEvent;
import today.makrit.utils.mapper.ThePlayer;
import today.net.minecraft.client.Minecraft;
import today.net.minecraft.util.MathHelper;
import today.net.minecraft.util.Vec3;
import com.craftrise.gM;
import com.craftrise.lG;
import com.craftrise.m9;
import com.craftrise.mg;
import cr.launcher.BlockPos;
import cr.launcher.Config;
import cr.launcher.main.a;


import java.lang.reflect.Method;

public class RotationUtils implements Utils
{
    private double x, y, z;
    private float yaw, pitch;
    private boolean onGround;

    public RotationUtils(double x, double y, double z, float yaw, float pitch, boolean onGround) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.yaw = yaw;
        this.pitch = pitch;
        this.onGround = onGround;
    }

    public static float[] getFacingRotations2(final int paramInt1, final double d, final int paramInt3) {
        final com.craftrise.n5 localEntityPig = new com.craftrise.n5(Config.getMinecraft().bu);
        localEntityPig.bE = paramInt1 + 0.5;
        localEntityPig.aY = d + 0.5;
        localEntityPig.bH = paramInt3 + 0.5;
        return getRotationsNeeded2(localEntityPig);
    }

    public static float[] getRotationsNeeded2(final m9 entity) {
        if (entity == null) {
            return null;
        }
        Minecraft mc = Minecraft.getMinecraft();
        final double xSize = entity.bE - a.q.bE;
        final double ySize = entity.aY + a.q.aY +1;
        final double zSize = entity.bH - a.q.bH;
        final double theta = MathHelper.sqrt_double(xSize * xSize + zSize * zSize);
        final float yaw = (float) (Math.atan2(zSize, xSize) * 180 / Math.PI) - 90;
        final float pitch = (float) (-(Math.atan2(ySize, theta) * 180 / Math.PI));
        return new float[]{(a.q.bL + MathHelper.wrapAngleTo180_float(yaw - a.q.bL)) % 360, (a.q.N + MathHelper.wrapAngleTo180_float(pitch - a.q.N)) % 360.0f};
    }


    public static float[] getRotationFromPosition(double x, double z, double y) {
        double xDiff = x - ThePlayer.GetPosY();
        double zDiff = z - ThePlayer.GetPosZ();
        double yDiff = y - ThePlayer.GetPosY() - 0.6;
        double dist = Math.sqrt(xDiff * xDiff + zDiff * zDiff);
        float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(yDiff, dist) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }

    public static float clampRotation() {
        float rotationYaw = a.q.bL;
        float n = 1.0f;
        if (a.q.l.b.a(5L) < 0.0f) {
            rotationYaw += 180.0f;
            n = -0.5f;
        }
        else if (a.q.l.b.a(5L) > 0.0f) {
            n = 0.5f;
        }
        if (a.q.l.c.a(5L) > 0.0f) {
            rotationYaw -= 90.0f * n;
        }
        if (a.q.l.c.a(5L) < 0.0f) {
            rotationYaw += 90.0f * n;
        }
        return rotationYaw * 0.017453292f;
    }


    public static Vec3 getPositionVector() {
        return new Vec3(a.q.bE, a.q.aY, a.q.bH);
    }

    public static class BlockCache {
        public BlockPos position;
        public lG facing;

        public BlockCache(final BlockPos position, final lG facing) {
            this.position = position;
            this.facing = facing;
        }

        public BlockPos getPosition() {
            return this.position;
        }

        private lG getFacing() {
            return this.facing;
        }

    }

    public static Vec3 getHypixelVec3(BlockCache data) {
        BlockPos pos = data.position;
        lG face = data.facing;
        double x = (double) pos.d + 0.5, y = (double) pos.c + 0.5, z = (double) pos.a + 0.5;
        if (face != lG.UP && face != lG.DOWN) {
            y += 0.5;
        } else {
            x += 0.3;
            z += 0.3;
        }
        if (face == lG.WEST || face == lG.EAST) {
            z += 0.15;
        }
        if (face == lG.SOUTH || face == lG.NORTH) {
            x += 0.15;
        }
        return new Vec3(x, y, z);
    }

//    public static BlockCache grab() {
//        final lG[] invert = {lG.UP, lG.DOWN, lG.SOUTH, lG.NORTH,
//                lG.EAST, lG.WEST};
//        BlockPos position = new BlockPos(0, 0, 0);
//        if (ThePlayer.isMoving() && !Config.gameSettings.bO.a("Null")) {
//            for (double n2 = Scaffold.extend.getNumber() + 0.0001, n3 = 0.0; n3 <= n2; n3 += n2 / (Math.floor(n2))) {
//                final BlockPos blockPos2 = new BlockPos(
//                        a.q.bE - MathHelper.sin(RotationUtils.clampRotation()) * n3,
//                        a.q.aY - 1.0,
//                        a.q.bH + MathHelper.cos(RotationUtils.clampRotation()) * n3);
//                final pI blockState = Config.getMinecraft().bu.getBlockState(blockPos2);
//                if (blockState != null && blockState.a() == lH.A) {
//                    position = blockPos2;
//                    break;
//                }
//            }
//        } else {
//            position = new BlockPos(new BlockPos(getPositionVector().xCoord,
//                    getPositionVector().yCoord, getPositionVector().zCoord))
//                    .offset(lG.DOWN);
//        }
//        lG[] values;
//        for (int length = (values = lG.values()).length, i = 0; i < length; i++) {
//            final lG facing = values[i];
//            final BlockPos offset = position.offset(facing);
//            return new BlockCache(offset, invert[facing.ordinal()]);
//        }
//        final BlockPos[] offsets = {new BlockPos(-1, 0, 0), new BlockPos(1, 0, 0), new BlockPos(0, 0, -1),
//                new BlockPos(0, 0, 1)};
//        BlockPos[] array;
//        for (int length2 = (array = offsets).length, j = 0; j < length2; ++j) {
//            final BlockPos offset2 = array[j];
//            final BlockPos offsetPos = position.add(offset2.d, 0, offset2.c);
//            lG[] values2;
//            for (int length3 = (values2 = lG.values()).length, k = 0; k < length3; ++k) {
//                final lG facing2 = values2[k];
//                final BlockPos offset3 = offsetPos.offset(facing2);
//                return new BlockCache(offset3, invert[facing2.ordinal()]);
//
//            }
//
//        }
//        return null;
//    }

    public static int grabBlockSlot() {
        int slot = -1;
        int highestStack = -1;
        boolean didGetHotbar = false;
        for (int i = 0; i < 9; ++i) {
            final gM itemStack = a.q.J.e[i];
            if (itemStack != null  && itemStack.a > 0) {
                if (a.q.J.e[i].a > highestStack && i < 9) {
                    highestStack = a.q.J.e[i].a;
                    slot = i;
                    if (slot == getLastHotbarSlot()) {
                        didGetHotbar = true;
                    }
                }
                if (i > 8 && !didGetHotbar) {
                    int hotbarNum = getFreeHotbarSlot();
                    if (hotbarNum != -1 && a.q.J.e[i].a > highestStack) {
                        highestStack = a.q.J.e[i].a;
                        slot = i;
                    }
                }
            }
        }
        if (slot > 8) {
            int hotbarNum = getFreeHotbarSlot();
            if (hotbarNum != -1) {
                Config.getMinecraft().b.a(a.q.b1.i,slot,hotbarNum,2,a.q,5L);
            } else {
                return -1;
            }
        }
        return slot;
    }


    public static int getLastHotbarSlot() {
        int hotbarNum = -1;
        for (int k = 0; k < 9; k++) {
            final gM itemStack = a.q.J.e[k];
            if (itemStack != null && itemStack.a > 1) {
                hotbarNum = k;
                continue;
            }
        }
        return hotbarNum;
    }

    public static int getFreeHotbarSlot() {
        int hotbarNum = -1;
        for (int k = 0; k < 9; k++) {
            if (a.q.J.e[k] == null) {
                hotbarNum = k;
                continue;
            } else {
                hotbarNum = 7;
            }
        }
        return hotbarNum;
    }


    public static float getEyeHeight(com.craftrise.m9 entity) {
        float result = 0.0F;

        try {
            for (Method m : com.craftrise.m9.class.getDeclaredMethods()) {
                if (m.getName().equals("e")) {
                    if (m.getParameterCount() == 1) {
                        if (m.getReturnType().toString().contains("float")) {
                            m.setAccessible(true);

                            result = (Float) m.invoke((Object) entity, Main.idk);
                        }
                    }
                }
            }
        } catch (Exception e) {
            today.makrit.utils.mapper.Minecraft.addChatMessage(e.toString());
        }

        return result;
    }
    public static float[] getRotationsNeeded(mg target) {
        Minecraft mc = Minecraft.getMinecraft();
        final double xSize = ThePlayer.GetPosX(target) - ThePlayer.GetPosX();
        final double ySize = ThePlayer.GetPosY(target) + getEyeHeight(target) / 2 - (ThePlayer.GetPosY() + getEyeHeight(today.makrit.utils.mapper.Minecraft.GetPlayer()));
        final double zSize = ThePlayer.GetPosZ(target) - ThePlayer.GetPosZ();
        final double theta = MathHelper.sqrt_double(xSize * xSize + zSize * zSize);
        final float yaw = (float) (Math.atan2(zSize, xSize) * 180 / Math.PI) - 90;
        final float pitch = (float) (-(Math.atan2(ySize, theta) * 180 / Math.PI));
        return new float[]{(ThePlayer.GetrotationYaw() + MathHelper.wrapAngleTo180_float(yaw - ThePlayer.GetrotationYaw())) % 360, (ThePlayer.GetRotationPitch() + MathHelper.wrapAngleTo180_float(pitch - ThePlayer.GetRotationPitch())) % 360.0f};
    }

   // @Exclude(Strategy.NAME_REMAPPING)
    public void setRotations(float yaw, float pitch) {
        this.yaw = yaw;
        this.pitch = pitch;
    }

   // @Exclude(Strategy.NAME_REMAPPING)
    public static void setVisualRotations(float yaw, float pitch) {
        ThePlayer.rotationYawHead(ThePlayer.renderYawOffset(yaw));
        //ThePlayer.rotationPitchHead = pitch;
    }

    public static void setVisualRotations(float[] rotations) {
        setVisualRotations(rotations[0], rotations[1]);
    }

    public static void setVisualRotations(MotionEvent e) {
        setVisualRotations(e.getYaw(), e.getPitch());
    }
    public static float getYaw(Vec3 to) {
        float x = (float) (to.xCoord - ThePlayer.GetPosX());
        float z = (float) (to.zCoord - ThePlayer.GetPosZ());
        float var1 = (float) (StrictMath.atan2(z, x) * 180.0D / StrictMath.PI) - 90.0F;
        float rotationYaw = ThePlayer.GetrotationYaw();
        return rotationYaw + MathHelper.wrapAngleTo180_float(var1 - rotationYaw);
    }

   // @Exclude(Strategy.NAME_REMAPPING)
    public float getYaw2() {
        return yaw;
    }

   // @Exclude(Strategy.NAME_REMAPPING)
    public float getPitch2() {
        return pitch;
    }
}
