package today.makrit.utils;

import com.craftrise.iE;
import com.craftrise.m9;
import com.craftrise.client.fN;
import com.craftrise.client.gD;
import today.makrit.module.Module;
import today.makrit.utils.Helper.RenderHelper;

public class EffectRenderer extends fN {
   public EffectRenderer(fN effectRenderer) {
      super((iE)null, (gD)null);
      ReflectFields.copyNonStaticField((Object)this, effectRenderer);
   }

   public void a(m9 entity, float float2, long l2) {
      RenderHelper.enableTransparencyAndBlend();
      Module.renderParticlesEvent(float2);
      RenderHelper.disableTransparencyAndEnableDepth();
      super.a(entity, float2, l2);
   }
}
