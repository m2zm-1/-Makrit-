package today.makrit.utils.Renderer;

import com.jhlabs.image.GaussianFilter;
import org.lwjgl.opengl.GL11;
import today.makrit.Main;
import today.makrit.utils.mapper.Minecraft;
import today.net.minecraft.client.renderer.GlStateManager;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.HashMap;

import static org.lwjgl.opengl.GL11.*;

public class RenderUtil {

    private static int currentColorIndex = 0;
    private static final HashMap<Integer, Integer> shadowCache = new HashMap();
    public static void color2(int color, float alpha)
    {
        float r = (float)(color >> 16 & 255) / 255.0F;
        float g = (float)(color >> 8 & 255) / 255.0F;
        float b = (float)(color & 255) / 255.0F;
        GlStateManager.color(r, g, b, alpha);
    }

    // Colors the next texture without a specified alpha value
    public static void color2(int color)
    {
        color2(color, (float)(color >> 24 & 255) / 255.0F);
    }
    public static void setAlphaLimit(float limit)
    {
        GlStateManager.enableAlpha();
        GlStateManager.alphaFunc(GL_GREATER, (float)(limit * .01));
    }
    public static int render3DText(String text, int x, int y, int color, int width, int height) {
        return Minecraft.GetFontRendererObj().a(text, x, y, color, true, Main.idk);
    }
    public static void resetColor()
    {
        GlStateManager.color(1, 1, 1, 1);
    }
    public static Color getRainbow(int offset, int speed) {
        float hue = (float)((System.currentTimeMillis() + (long)offset) % (long)speed);
        hue /= (float)speed;
        return Color.getHSBColor(hue, 0.7F, 1.0F);
    }
    public static void drawFullImage(String imagePath, int x, int y, int width, int height, Graphics graphics) {
        ImageIcon icon = new ImageIcon(imagePath);
        Image image = icon.getImage();
        graphics.drawImage(image, x, y, width, height, null);
    }


    public static void drawGlowGradient(float x, float y, float width, float height, int glowRadius, Color color1, Color color2, Color color3, Color color4) {
        if (Minecraft.getCurrentScreen() != Minecraft.getCurrentScreen()) {
            // Glow effect initialization
            BufferedImage original;
            GaussianFilter op;
            GL11.glPushMatrix();
            GlStateManager.enableBlend();
            GlStateManager.disableAlpha();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            GlStateManager.shadeModel(GL11.GL_SMOOTH);
            GlStateManager.alphaFunc(GL11.GL_GREATER, 0.01f);

            // Adjust positions for the glow effect
            float _X = (x - glowRadius) - 0.25f;
            float _Y = (y - glowRadius) + 0.25f;
            int identifier = String.valueOf((width + (glowRadius * 2)) * (height + (glowRadius * 2)) + width + (1000000000 * glowRadius) + glowRadius).hashCode();

            // Enabling textures
            GL11.glEnable(GL11.GL_TEXTURE_2D);
            GL11.glDisable(GL11.GL_CULL_FACE);
            GL11.glEnable(GL11.GL_ALPHA_TEST);
            GlStateManager.enableBlend();

            int texId = -1;
            if (shadowCache.containsKey(identifier)) {
                texId = shadowCache.get(identifier);
                GlStateManager.bindTexture(texId);
            } else {
                // Create the original image and apply Gaussian blur
                original = new BufferedImage((int) width, (int) height, BufferedImage.TYPE_INT_ARGB);
                Graphics2D g = original.createGraphics();
                g.setColor(Color.WHITE);
                g.fillRect(glowRadius, glowRadius, (int) width - glowRadius * 2, (int) height - glowRadius * 2);
                g.dispose();

                // Apply Gaussian filter to blur the image
                op = new GaussianFilter(glowRadius);
                BufferedImage blurred = op.filter(original, null);

                // Upload the texture to OpenGL
                texId = TextureUtil.uploadTextureImageAllocate(TextureUtil.glGenTextures(), blurred, true, false);
                shadowCache.put(identifier, texId);
            }

            // Draw the gradient with colors
            GL11.glBegin(GL11.GL_QUADS);
            setColor(color1);
            GL11.glTexCoord2f(0.0f, 0.0f);
            GL11.glVertex2f(_X, _Y);

            setColor(color2);
            GL11.glTexCoord2f(0.0f, 1.0f);
            GL11.glVertex2f(_X, _Y + height);

            setColor(color4);
            GL11.glTexCoord2f(1.0f, 1.0f);
            GL11.glVertex2f(_X + width, _Y + height);

            setColor(color3);
            GL11.glTexCoord2f(1.0f, 0.0f);
            GL11.glVertex2f(_X + width, _Y);
            GL11.glEnd();

            // Reset state
            GlStateManager.enableTexture2D();
            GlStateManager.shadeModel(GL11.GL_FLAT);
            GlStateManager.disableBlend();
            GlStateManager.enableAlpha();
            GlStateManager.resetColor();
            GL11.glEnable(GL11.GL_CULL_FACE);
            GL11.glPopMatrix();
        }
    }


    public static void drawBlurredShadow(float x, float y, float width, float height, int blurRadius, Color color) {
        GL11.glPushMatrix();

        // Blur radius eklemesi
        width += blurRadius * 2;
        height += blurRadius * 2;
        x -= blurRadius;
        y -= blurRadius;

        float _X = x - 0.25F;
        float _Y = y + 0.25F;

        // Sıfır kontrolü
        if (blurRadius == 0) {
            blurRadius = 1;
        }

        double identifier = width * height * 13212.0 / Math.sin(blurRadius);

        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_CULL_FACE);
        GL11.glEnable(GL11.GL_ALPHA_TEST);
        GlStateManager.enableBlend();

        int texId;
        if (shadowCache.containsKey(identifier)) {
            texId = shadowCache.get(identifier);
            GlStateManager.bindTexture(texId);
        } else {
            BufferedImage original = new BufferedImage((int) width, (int) height, BufferedImage.TYPE_INT_ARGB);
            Graphics g = original.getGraphics();
            g.setColor(Color.WHITE);
            g.fillRect(blurRadius, blurRadius, (int) (width - blurRadius * 2), (int) (height - blurRadius * 2));
            g.dispose();

            // Gaussian filtre uygulanması
            BufferedImage blurred = new BufferedImage(original.getWidth(), original.getHeight(), original.getType());
            GaussianFilter op = new GaussianFilter(blurRadius);
            op.filter(original, blurred);

            // Texture oluşturma ve cache'e ekleme
            texId = TextureUtil.uploadTextureImageAllocate(TextureUtil.glGenTextures(), blurred, true, false);
            shadowCache.put((int) identifier, texId);
        }

        GL11.glColor4f((float)color.getRed() / 255.0F, (float)color.getGreen() / 255.0F, (float)color.getBlue() / 255.0F, (float)color.getAlpha() / 255.0F);
        GL11.glBegin(GL11.GL_QUADS);
        GL11.glTexCoord2f(0.0F, 0.0F);
        GL11.glVertex2f(_X, _Y);
        GL11.glTexCoord2f(0.0F, 1.0F);
        GL11.glVertex2f(_X, _Y + height);
        GL11.glTexCoord2f(1.0F, 1.0F);
        GL11.glVertex2f(_X + width, _Y + height);
        GL11.glTexCoord2f(1.0F, 0.0F);
        GL11.glVertex2f(_X + width, _Y);
        GL11.glEnd();

        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GL11.glEnable(GL11.GL_CULL_FACE);
        RenderUtil.resetColor();
        GL11.glPopMatrix();
    }


    public static void fakeCircleGlow(float posX, float posY, float radius, Color color, float maxAlpha) {

    }

    private static void color(int rgb, float maxAlpha) {
    }


    private static void setColor(Color color1) {
    }

    public static int rainbow(int delay) {
        double rainbowState = Math.ceil((double)(System.currentTimeMillis() + (long)delay) / 20.0D);
        rainbowState %= 360.0D;
        return Color.getHSBColor((float)(rainbowState / 360.0D), 0.8F, 0.7F).getRGB();
    }
    public static int rainbow(int delay, float brightness, float saturation) {
        double rainbowState = Math.ceil((double)(System.currentTimeMillis() + (long)delay) / 20.0D);
        rainbowState %= 360.0D;
        return Color.getHSBColor((float)(rainbowState / 360.0D), saturation, brightness).getRGB();
    }

    public static int getRainbow1(int speed, int offset) {
        float hue = (float)((System.currentTimeMillis() + (long)offset) % (long)speed);
        hue /= (float)speed;
        return Color.getHSBColor(hue, 1.0F, 1.0F).getRGB();
    }

    public static int getRainbow(int speed, int offset, float brightness, float saturation) {
        float hue = (float)((System.currentTimeMillis() + (long)offset) % (long)speed);
        hue /= (float)speed;
        return Color.getHSBColor(hue, saturation, brightness).getRGB();
    }

    private static int shiftHue(int color, float shift) {
        float[] hsb = Color.RGBtoHSB(color >> 16 & 0xFF, color >> 8 & 0xFF, color & 0xFF, null);
        float newHue = (hsb[0] + shift) % 1.0f;
        return Color.HSBtoRGB(newHue, hsb[1], hsb[2]);
    }
    private static int calculateChangingColor(long currentTime, int speed) {
        float hue = (float)(currentTime % (long)speed) / (float)speed;
        int color = Color.HSBtoRGB(hue, 1.0f, 1.0f);
        int shiftedColor = shiftHue(color, (float)currentColorIndex * 0.1f);
        return shiftedColor;
    }

    public static Color mixColors(Color color1, Color color2, int count, boolean penis) {
        return interpolateColorsBackAndForth(10, 1 * count, color1, color2, true);
    }

    public static Color interpolateColorC(Color color1, Color color2, float amount) {
        amount = Math.min(1.0F, Math.max(0.0F, amount));
        return new Color(interpolateInt(color1.getRed(), color2.getRed(), (double)amount), interpolateInt(color1.getGreen(), color2.getGreen(), (double)amount), interpolateInt(color1.getBlue(), color2.getBlue(), (double)amount), interpolateInt(color1.getAlpha(), color2.getAlpha(), (double)amount));
    }

    public static Color interpolateColorsBackAndForth(int speed, int index, Color start, Color end, boolean trueColor) {
        int angle = (int)((System.currentTimeMillis() / (long)speed + (long)index) % 360L);
        angle = (angle >= 180 ? 360 - angle : angle) * 2;
        return trueColor ? interpolateColorHue(start, end, (float)angle / 360.0F) : interpolateColorC(start, end, (float)angle / 360.0F);
    }

    public static Color interpolateColorHue(Color color1, Color color2, float amount) {
        amount = Math.min(1.0F, Math.max(0.0F, amount));
        float[] color1HSB = Color.RGBtoHSB(color1.getRed(), color1.getGreen(), color1.getBlue(), (float[])null);
        float[] color2HSB = Color.RGBtoHSB(color2.getRed(), color2.getGreen(), color2.getBlue(), (float[])null);
        Color resultColor = Color.getHSBColor(interpolateFloat(color1HSB[0], color2HSB[0], (double)amount), interpolateFloat(color1HSB[1], color2HSB[1], (double)amount), interpolateFloat(color1HSB[2], color2HSB[2], (double)amount));
        return new Color(resultColor.getRed(), resultColor.getGreen(), resultColor.getBlue(), interpolateInt(color1.getAlpha(), color2.getAlpha(), (double)amount));
    }

    public static Double interpolate(double oldValue, double newValue, double interpolationValue) {
        return oldValue + (newValue - oldValue) * interpolationValue;
    }

    public static float interpolateFloat(float oldValue, float newValue, double interpolationValue) {
        return interpolate((double)oldValue, (double)newValue, (double)((float)interpolationValue)).floatValue();
    }

    public static int interpolateInt(int oldValue, int newValue, double interpolationValue) {
        return interpolate((double)oldValue, (double)newValue, (double)((float)interpolationValue)).intValue();
    }

    public static int renderText(String text, int x, int y, int color, boolean rainbow) {
        if(rainbow){
            long currentTime = System.currentTimeMillis();
            int colorSpeed = 8000;
            int colorx = calculateChangingColor(currentTime, colorSpeed);
            //int colorx =  getRainbow(10,25,10,10);
            return Minecraft.GetFontRendererObj().a(text, x, y, colorx, true, Main.idk);
        }else { return Minecraft.GetFontRendererObj().a(text, x, y, color, true, Main.idk); }
    }
    public static int renderTextxx(String text, int x, int y, int color, boolean rainbow) {
        if(rainbow){
            long currentTime = System.currentTimeMillis();
            int colorSpeed = 8000;
            int colorx = calculateChangingColor(currentTime, colorSpeed);
            //int colorx =  getRainbow(10,25,10,10);
            return Minecraft.GetFontRendererObj().a(text, x, y, colorx, false, Main.idk);
        }else { return Minecraft.GetFontRendererObj().a(text, x, y, color, false, Main.idk); }
    }
    public static int drawStringBigWithDropShadow(final String text, final double x, final double y, final int color) {
        for (int i = 0; i < 5; i++) {
            Minecraft.GetFontRendererObj().a(text, (float) x + 0.5f * i, (float) y + 0.5f * i, new Color(0, 0, 0, 100 - i * 20).hashCode(), false ,1 );

        }
        Minecraft.GetFontRendererObj().a(text, (float) x, (float) y, color, false, 1);
        return 31;
    }

    public static int drawStringWithDropShadow(final String text, final double x, final double y, final int color) {
        Minecraft.GetFontRendererObj().a(text, (float) x + 0.6f, (float) y + 0.6f, new Color(0, 0, 0, 100).hashCode(), false, 1);
        Minecraft.GetFontRendererObj().a(text, (float) x, (float) y, color, false, 1);
        return 31;
    }

    public static int renderTextWaterMark(String text, int x, int y, int color) {
        return Minecraft.GetFontRendererObj().a(text, x, y, color, true, Main.idk);
    }

    public static int renderText2(String text, int x, int y, int count) {
        Color textColor = ThemeUtil.getThemeColor(count, ThemeType.ARRAYLIST);
        return Minecraft.GetFontRendererObj().a(text, x, y, Color.WHITE.getRGB(), false, 0);
    }
    private static String getColorCode(Color color) {
        return "§" + Integer.toHexString(color.getRGB()).substring(2, 8).toUpperCase();
    }

    public static void rect(double d, double d2, double d3, double d4, boolean bl, Color color) {
        RenderUtil.start();
        if (color != null) {
            RenderUtil.color(color);
        }
        RenderUtil.begin(bl ? 6 : 1);
        RenderUtil.vertex(d, d2);
        RenderUtil.vertex(d + d3, d2);
        RenderUtil.vertex(d + d3, d2 + d4);
        RenderUtil.vertex(d, d2 + d4);
        if (!bl) {
            RenderUtil.vertex(d, d2);
            RenderUtil.vertex(d, d2 + d4);
            RenderUtil.vertex(d + d3, d2);
            RenderUtil.vertex(d + d3, d2 + d4);
        }
        RenderUtil.end();
        RenderUtil.stop();
    }

    public static void begin(int n) {
        GL11.glBegin(n);
    }

    public static void vertex(double d, double d2) {
        GL11.glVertex2d(d, d2);
    }

    public static void start() {
        RenderUtil.enable(3042);
        GL11.glBlendFunc(770, 771);
        RenderUtil.disable(3553);
        RenderUtil.disable(2884);
    }

    public static void enable(int n) {
        GL11.glEnable(n);
    }

    public static void disable(int n) {
        GL11.glDisable(n);
    }

    public static void end() {
        GL11.glEnd();
    }

    public static void stop() {
        RenderUtil.enable(2884);
        RenderUtil.enable(3553);
        RenderUtil.disable(3042);
        RenderUtil.color(Color.white);
    }

    public static void color(Color color) {
        if (color == null) {
            color = Color.white;
        }
        RenderUtil.color((float) color.getRed() / 255.0f, (float) color.getGreen() / 255.0f, (float) color.getBlue() / 255.0f, (float) color.getAlpha() / 255.0f);
    }

    public static void color(double d, double d2, double d3) {
        RenderUtil.color(d, d2, d3, 1.0);
    }

    public static void color(double d, double d2, double d3, double d4) {
        GL11.glColor4d(d, d2, d3, d4);
    }

    public static int getTextWidth(String text) {
        int width = 0;
        String cleanedText = text.replaceAll("§[0-9a-fk-or]", ""); // Remove Minecraft color and formatting codes

        for (char c : cleanedText.toCharArray()) {
            width += Minecraft.GetFontRendererObj().b(c, Main.idk);
        }

        return width;
    }


    public static void drawRoundedRect2(double x, double y, double endX, double endY, double radius, int color) {
        int n2;
        float f = (float) (color >> 24 & 0xFF) / (float) 255;
        float f2 = (float) (color >> 16 & 0xFF) / (float) 255;
        float f3 = (float) (color >> 8 & 0xFF) / (float) 255;
        float f4 = (float) (color & 0xFF) / (float) 255;
        glPushAttrib(0);
        glScaled(0.5, 0.5, 0.5);
        x *= 2;
        y *= 2;
        endX *= 2;
        endY *= 2;
        glEnable(3042);
        glDisable(3553);
        glColor4f(f2, f3, f4, f);
        glEnable(2848);
        glBegin(9);
        for (n2 = 0; n2 <= 90; n2 += 3) {
            glVertex2d(x + radius + Math.sin((double) n2 * (6.5973445528769465 * 0.4761904776096344) / (double) 180) * (radius * (double) -1), y + radius + Math.cos((double) n2 * (42.5 * 0.07391982714328925) / (double) 180) * (radius * (double) -1));
        }
        for (n2 = 90; n2 <= 180; n2 += 3) {
            glVertex2d(x + 0f + Math.sin((double) n2 * (0.5711986642890533 * 5.5) / (double) 180) * (0f * (double) -1), endY - 0f + Math.cos((double) n2 * (0.21052631735801697 * 14.922564993369743) / (double) 180) * (0f * (double) -1));
        }
        for (n2 = 0; n2 <= 90; n2 += 3) {
            glVertex2d(endX - 0f + Math.sin((double) n2 * (4.466951941998311 * 0.7032967209815979) / (double) 180) * (0f * (double) -1), endY - 0f + Math.cos((double) n2 * (28.33333396911621 * 0.11087973822685955) / (double) 180) * (0f * (double) -1));
        }
        for (n2 = 90; n2 <= 180; n2 += 3) {
            glVertex2d(endX - radius + Math.sin((double) n2 * ((double) 0.6f * 5.2359875479235365) / (double) 180) * radius, y + radius + Math.cos((double) n2 * (2.8529412746429443 * 1.1011767685204017) / (double) 180) * radius);
        }
        GL11.glEnd();
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glDisable(2848);
        GL11.glDisable(3042);
        GL11.glEnable(3553);
        GL11.glScaled(2.0D, 2.0D, 2.0D);
        GL11.glPopAttrib();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }

    public static void drawRoundedRect(double x, double y, double endX, double endY, double radius, int color) {
        int n2;
        float f = (float) (color >> 24 & 0xFF) / (float) 255;
        float f2 = (float) (color >> 16 & 0xFF) / (float) 255;
        float f3 = (float) (color >> 8 & 0xFF) / (float) 255;
        float f4 = (float) (color & 0xFF) / (float) 255;
        glPushAttrib(0);
        glScaled(0.5, 0.5, 0.5);
        x *= 2;
        y *= 2;
        endX *= 2;
        endY *= 2;
        glEnable(3042);
        glDisable(3553);
        glColor4f(f2, f3, f4, f);
        glEnable(2848);
        glBegin(9);
        for (n2 = 0; n2 <= 90; n2 += 3) {
            glVertex2d(x + radius + Math.sin((double) n2 * (6.5973445528769465 * 0.4761904776096344) / (double) 180) * (radius * (double) -1), y + radius + Math.cos((double) n2 * (42.5 * 0.07391982714328925) / (double) 180) * (radius * (double) -1));
        }
        for (n2 = 90; n2 <= 180; n2 += 3) {
            glVertex2d(x + radius + Math.sin((double) n2 * (0.5711986642890533 * 5.5) / (double) 180) * (radius * (double) -1), endY - radius + Math.cos((double) n2 * (0.21052631735801697 * 14.922564993369743) / (double) 180) * (radius * (double) -1));
        }
        for (n2 = 0; n2 <= 90; n2 += 3) {
            glVertex2d(endX - radius + Math.sin((double) n2 * (4.466951941998311 * 0.7032967209815979) / (double) 180) * radius, endY - radius + Math.cos((double) n2 * (28.33333396911621 * 0.11087973822685955) / (double) 180) * radius);
        }
        for (n2 = 90; n2 <= 180; n2 += 3) {
            glVertex2d(endX - radius + Math.sin((double) n2 * ((double) 0.6f * 5.2359875479235365) / (double) 180) * radius, y + radius + Math.cos((double) n2 * (2.8529412746429443 * 1.1011767685204017) / (double) 180) * radius);
        }
        GL11.glEnd();
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glDisable(2848);
        GL11.glDisable(3042);
        GL11.glEnable(3553);
        GL11.glScaled(2.0D, 2.0D, 2.0D);
        GL11.glPopAttrib();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }
    public static void drawRect(double x, double y, double endX, double endY, int color) {
        drawRoundedRect(x, y, endX, endY, 0f, color);
    }


    public static void drawGradientRect(float x, float y, float x1, float y1, int topColor, int bottomColor) {
        enableGL2D();
        GL11.glShadeModel((int) 7425);
        GL11.glBegin((int) 7);
        glColor(topColor);
        GL11.glVertex2f((float) x, (float) y1);
        GL11.glVertex2f((float) x1, (float) y1);
        glColor(bottomColor);
        GL11.glVertex2f((float) x1, (float) y);
        GL11.glVertex2f((float) x, (float) y);
        GL11.glEnd();
        GL11.glShadeModel((int) 7424);
        disableGL2D();
    }

    private static void glColor(int topColor) {
    }

    public static void enableGL2D() {
        GL11.glDisable((int) 2929);
        GL11.glEnable((int) 3042);
        GL11.glDisable((int) 3553);
        GL11.glBlendFunc((int) 770, (int) 771);
        GL11.glDepthMask((boolean) true);
        GL11.glEnable((int) 2848);
        GL11.glHint((int) 3154, (int) 4354);
        GL11.glHint((int) 3155, (int) 4354);
    }

    public static void disableGL2D() {
        GL11.glEnable((int) 3553);
        GL11.glDisable((int) 3042);
        GL11.glEnable((int) 2929);
        GL11.glDisable((int) 2848);
        GL11.glHint((int) 3154, (int) 4352);
        GL11.glHint((int) 3155, (int) 4352);
    }

    public static int[] getIdealRenderingPosForText(int textWidth, double x, double y, double endX, double endY) {
        int[] renderingPos = new int[2];
        renderingPos[0] = (int) ((x + endX) / 2 - textWidth / 2);
        renderingPos[1] = (int) ((y + endY) / 2 - 9 / 2);
        return renderingPos;
    }

    public static boolean basicCollisionCheck(double mouseX, double mouseY, double x, double y, double endX, double endY) {
        return mouseX >= x & mouseX <= endX & mouseY >= y & mouseY <= endY;
    }

    public static int applyOpacity(int color, float opacity) {
        Color old = new Color(color);
        return applyOpacity(old, opacity).getRGB();
    }


    public static Color applyOpacity(Color color, float opacity) {
        opacity = Math.min(1.0f, Math.max(0.0f, opacity));
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int) ((float) color.getAlpha() * opacity));
    }

    public static Color brighter(Color color, float FACTOR) {
        int r = color.getRed();
        int g = color.getGreen();
        int b = color.getBlue();
        int alpha = color.getAlpha();
        int i = (int) (1.0 / (1.0 - FACTOR));
        if (r == 0 && g == 0 && b == 0) {
            return new Color(i, i, i, alpha);
        }
        if (r > 0 && r < i) r = i;
        if (g > 0 && g < i) g = i;
        if (b > 0 && b < i) b = i;

        return new Color(Math.min((int) (r / FACTOR), 255),
                Math.min((int) (g / FACTOR), 255),
                Math.min((int) (b / FACTOR), 255),
                alpha);
    }

    public static void drawCircle(final com.craftrise.m9 entity, final double rad, final boolean shade) {
        try{
            GL11.glPushMatrix();
            GL11.glDisable(3553);
            GL11.glEnable(2848);
            GL11.glEnable(2832);
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            GL11.glHint(3154, 4354);
            GL11.glHint(3155, 4354);
            GL11.glHint(3153, 4354);
            GL11.glDepthMask(false);
            com.craftrise.client.bO.a(GL11.GL_GREATER, 0.0F);
            if (shade) GL11.glShadeModel(GL11.GL_SMOOTH);
            com.craftrise.client.bO.K();
            GL11.glBegin(GL11.GL_TRIANGLE_STRIP);

            final double x = entity.a6 + (entity.bE - entity.a6) * 0.9F - Minecraft.getRenderManager().j;
            final double y = (entity.h + (entity.aY - entity.h) * 0.9F - Minecraft.getRenderManager().t) + Math.sin(System.currentTimeMillis() / 2E+2) + 1;
            final double z = entity.G + (entity.bH - entity.G) * 0.9F - Minecraft.getRenderManager().c;

            Color c;

            for (float i = 0; i < Math.PI * 2; i += Math.PI * 2 / 64.F) {
                final double vecX = x + rad * Math.cos(i);
                final double vecZ = z + rad * Math.sin(i);

                c = new Color(255,255,255,255);

                if (shade) {
                    GL11.glColor4f(c.getRed() / 255.F,
                            c.getGreen() / 255.F,
                            c.getBlue() / 255.F,
                            0
                    );
                    GL11.glVertex3d(vecX, y - Math.cos(System.currentTimeMillis() / 2E+2) / 2.0F, vecZ);
                    GL11.glColor4f(c.getRed() / 255.F,
                            c.getGreen() / 255.F,
                            c.getBlue() / 255.F,
                            0.85F
                    );
                }
                GL11.glVertex3d(vecX, y, vecZ);
            }

            GL11.glEnd();
            if (shade) GL11.glShadeModel(GL11.GL_FLAT);
            GL11.glDepthMask(true);
            GL11.glEnable(2929);
            com.craftrise.client.bO.a(GL11.GL_GREATER, 0.1F);
            com.craftrise.client.bO.q();
            GL11.glDisable(2848);
            GL11.glDisable(2848);
            GL11.glEnable(2832);
            GL11.glEnable(3553);
            GL11.glPopMatrix();
            GL11.glColor3f(255, 255, 255);
        }
        catch (Exception ex){
            Minecraft.addChatMessage(ex.toString());
        }
    }

    public static void renderText(int rgb, double x, double y, double z, String targetName, boolean b, float v) {
    }











    public static void colorx(int color) {
        RenderUtil.colorx(color);
    }

    public static void colorx(int color, float alpha) {
        float r = (float)(color >> 16 & 0xFF) / 255.0f;
        float g = (float)(color >> 8 & 0xFF) / 255.0f;
        float b = (float)(color & 0xFF) / 255.0f;
        GlStateManager.color(r, g, b, alpha);
    }
    public static void colorx(Color color) {
        if (color == null) {
            color = Color.white;
        }
        RenderUtil.colorx((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)color.getAlpha() / 255.0f);
    }

    public static void colorx(double d, double d2, double d3) {
        RenderUtil.colorx(d, d2, d3, 1.0);
    }

    public static void colorx(double d, double d2, double d3, double d4) {
        GL11.glColor4d(d, d2, d3, d4);
    }


}
