package today.net.minecraft.client.renderer;
import com.craftrise.client.gK;

public class Tessellator extends gK{
    public today.net.minecraft.client.renderer.WorldRenderer worldRenderer;
    private static final Tessellator instance = new Tessellator(2097152);
    public Tessellator(int i) {
        super(i);
        this.worldRenderer = new today.net.minecraft.client.renderer.WorldRenderer(i);
    }
    public static Tessellator getInstance()
    {
        return instance;
    }
    public today.net.minecraft.client.renderer.WorldRenderer getWorldRenderer() {
        return this.worldRenderer;
    }
    public void draw(){
        super.a(0L);
    }
}
